﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.IO;

namespace KBHAG.Website
{
    public partial class AjaxMediaManage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string action = Request["action"].ToString();

            switch (action)
            {
                case "uploadPhoto":
                    Response.Write(uploadPhoto());
                    break;
            }
        }

        private string uploadPhoto()
        {
            int imageWidth  = int.Parse(Request["imageWidth"].ToString().Replace("px", ""));
            int imageHeight = int.Parse(Request["imageHeight"].ToString().Replace("px", ""));

            string strReturn = string.Empty;
            string tempFolderPath = Request.Form["tempFolderPath"].ToString();

            Boolean FileOK = false;

            HttpPostedFile PostedFile;
            PostedFile = Request.Files[0];

            string strFileName      = WebsiteHelpers.UniqueFilename(PostedFile.FileName, HttpContext.Current.Server.MapPath("~/" + Constants.TEMP_IMAGE_FOLDER_PATH));
            string strFileExtension = System.IO.Path.GetExtension(PostedFile.FileName).ToLower();

            String[] allowedExtensions = { ".jpg", ".jpeg", ".tiff", ".tif", ".gif", ".png" };


            for (int i = 0; i < allowedExtensions.Length; i++)
            {
                if (strFileExtension == allowedExtensions[i])
                {
                    FileOK = true;
                    break;
                }
            }

            if (FileOK)
            {
                try
                {
                    Bitmap bmpThumbImage    = new Bitmap(PostedFile.InputStream);
                    string isValidAttribute = ((imageWidth >= bmpThumbImage.Width) && (imageHeight >= bmpThumbImage.Height)) ? "true" : "false";
                    string imageFileName    = Server.MapPath("~/" + tempFolderPath) + strFileName;
                    PostedFile.SaveAs(imageFileName);
                    Session["WorkingImage"] = strFileName;
                    strReturn = "success" + "|" + strFileName;
                    strReturn += "|" + bmpThumbImage.Width + "|" + bmpThumbImage.Height + "|" + isValidAttribute;
                    bmpThumbImage.Dispose();

                }
                catch (Exception ex)
                {
                    strReturn = ex.ToString();
                }
            }
            else
            {
                strReturn = "Please upload a jpg,jpeg,tiff,tif,gif,.png image only";
            }
            return strReturn;
        }

        #region WebMethod
        [WebMethod]
        public static string ImageSubmitHandler(SlideShow AlbumDTO, List<SlideShowMedia> ImageMediaDTO)
        {
            try
            {
                int AlbumID = 0;
                string strReturn = string.Empty;
                string ImageName = string.Empty;
                Page page = HttpContext.Current.CurrentHandler as Page;
                

                if (AlbumDTO.ThumbImage.ToLower().IndexOf(Constants.TEMP_IMAGE_FOLDER_PATH) > -1)
                    AlbumDTO.ThumbImage = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH), AlbumDTO.ThumbImage);  

                var repo = new ApplicationRepository();
                AlbumID = repo.AddSlideShow(AlbumDTO);

                foreach (var item in ImageMediaDTO)
                {
                    if (item.FileName == null)
                        continue;

                    int ImageID = 0;
                    ImageName = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH), item.FileName);
                    
                    //Create Thumbnail                                                    
                    string ImageMapPathSource = HttpContext.Current.Server.MapPath("~/" + Constants.IMAGE_FOLDER_PATH);
                    Bitmap bmp = new Bitmap(ImageMapPathSource + ImageName);
                    WebsiteHelpers.SaveJpeg(ImageMapPathSource + "thumb_" + ImageName, bmp, 100);
                    WebsiteHelpers.ResizeImage(Constants.ALBUM_THUMB_WIDTH, Constants.ALBUM_THUMB_HEIGHT, ImageMapPathSource + "thumb_" + ImageName);
                    item.FileName = ImageName;

                    item.SlideShowID = AlbumID;
                    ImageID = repo.AddMedia(item);
                }

                strReturn = Constants.SUCCESS_MESSAGE;
                return strReturn;

            }
            catch (Exception ex)
            {
                return Constants.ERROR_MESSAGE + "|" + ex.ToString();
            }
        }

        [WebMethod]
        public static string DeleteImage(int id)
        {
            string strReturn = string.Empty;

            try
            {
                var repo = new ApplicationRepository();
                var file = repo.GetSlideShowMediaById(id);
                if (file != null)
                {
                    string filepath = HttpContext.Current.Server.MapPath("~/Media/Images/content/" + file.FileName);
                    if (File.Exists(filepath))
                        File.Delete(filepath);
                }   
                repo.DeleteMedia(id);
                strReturn = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {
                strReturn = Constants.ERROR_MESSAGE;
            }            

            return strReturn;
        }

        [WebMethod]
        public static string UpdateImageCaption(int id, string caption)
        {
            string strReturn = Constants.ERROR_MESSAGE;

            try
            {
                var repo = new ApplicationRepository();
                repo.UpdateCaption(id, caption);

                strReturn = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {
                strReturn = Constants.ERROR_MESSAGE;
            }
            return strReturn;
        }

        [WebMethod]
        public static string UpdateImageURL(int id, string url)
        {
            string strReturn = Constants.ERROR_MESSAGE;

            try
            {
                var repo = new ApplicationRepository();
                repo.UpdateURL(id, url);

                strReturn = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {
                strReturn = Constants.ERROR_MESSAGE;
            }
            return strReturn;
        }

        [WebMethod]
        public static string UpdateImageIndex(int id, int index)
        {
            string strReturn = Constants.ERROR_MESSAGE;

            try
            {
                var repo = new ApplicationRepository();
                repo.UpdateIndex(id, index);

                strReturn = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {
                strReturn = Constants.ERROR_MESSAGE;
            }

            return strReturn;
        }


        [WebMethod]
        public static string AddImage(SlideShowMedia mDTO)
        {
            string ImageName = string.Empty;
            List<RowCollection> rows = new List<RowCollection>();
            Page page = HttpContext.Current.CurrentHandler as Page;
            string strReturn = Constants.ERROR_MESSAGE;

            try
            {
                int mediaId = 0;
                //Insert Record in Global Media
                if (mDTO != null)
                {
                    ImageName = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH), mDTO.FileName);
                    mDTO.FileName = ImageName;

                    var repo = new ApplicationRepository();
                    mediaId = repo.AddMedia(mDTO);

                    //Create Thumbnail                                                    
                    string ImageMapPathSource = HttpContext.Current.Server.MapPath("~/" + Constants.IMAGE_FOLDER_PATH);
                    Bitmap bmp = new Bitmap(ImageMapPathSource + ImageName);
                    WebsiteHelpers.SaveJpeg(ImageMapPathSource + "thumb_" + ImageName, bmp, 100);
                    WebsiteHelpers.ResizeImage(Constants.ALBUM_THUMB_WIDTH, Constants.ALBUM_THUMB_HEIGHT, ImageMapPathSource + "thumb_" + ImageName);

                }

                strReturn = Constants.SUCCESS_MESSAGE + "|" + ImageName;

            }
            catch (Exception ex)
            {
                strReturn = Constants.ERROR_MESSAGE + "|" + ex.Message + "," + ex.InnerException;
            }
            return strReturn;
        }

        [WebMethod]
        public static string AlbumData(SlideShow album)
        {
            string strReturn = Constants.ERROR_MESSAGE;
            Page page = HttpContext.Current.CurrentHandler as Page;
            string filename = "";
            var repo = new ApplicationRepository();

            if (album.ThumbImage.ToLower().IndexOf(Constants.TEMP_IMAGE_FOLDER_PATH) > -1)
            {
                filename = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH), album.ThumbImage);
                album.ThumbImage = filename;
                var adata = repo.GetSlideShowByID(album.ID);
                if (adata != null)
                {
                    string filepath = HttpContext.Current.Server.MapPath("~/Media/Images/content/" + adata.ThumbImage);
                    if (File.Exists(filepath))
                        File.Delete(filepath);
                } 
            }
            try
            {
                int id = repo.UpdateSlideShow(album);

                strReturn = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {                
                strReturn = Constants.ERROR_MESSAGE;
            }

            return strReturn;
        }

        [WebMethod]
        public static string UpdatePageImage(int pageDataID, string imageFileName)
        {
            string json = string.Empty;
            List<RowCollection> rows = new List<RowCollection>();

            try
            {
                Page page = HttpContext.Current.CurrentHandler as Page;
                string ImageName = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH),imageFileName);

                var repo = new PageRepository();
                repo.UpdatePageImage(pageDataID, ImageName);
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Image", ColumnValue = ImageName });
                json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
                json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            }

            return json;
        }

        #endregion
    }
}