﻿using System;
using System.Collections.Generic;
using System.Linq;
using KBHAG.Model;

namespace KBHAG.Repository
{
    public interface IApplicationRepository
    {
        List<ViewEvent> GetEventPagination(int startrows, int pagesize, string type, string tense);
        int GetEventCount(string type, string tense);
        ViewEvent GetEventByID(int id);
        List<ViewEvent> GetEventForCalendarControl(int takeRows);
        string GetEventNameByAlias(string etype);
        int GetEventSlideShowId(int id);

        List<Press> GetPressPagination(int startrows, int pagesize);
        int GetPressCount();

        int AddSlideShow(SlideShow AlbumDTO);
        int UpdateSlideShow(SlideShow AlbumDTO);
        SlideShow GetSlideShowByID(int ID);
        SlideShow GetSlideShowByTargetAndTargetID(string target, int targetid);
        List<SlideShow> GetSlideShowPagination(int startrows, int pagesize);
        int GetSlideShowCount();

        int AddMedia(SlideShowMedia ImageMediaDTO);
        int UpdateMedia(SlideShowMedia ImageMediaDTO);
        void DeleteMedia(int ID);
        void UpdateCaption(int ID, string Caption);
        void UpdateURL(int ID, string URL);
        void UpdateIndex(int ID, int Index);
        List<SlideShowMedia> GetMediaByAlbumID(int ID);
        List<SlideShowMedia> GetMediaByAlbumTitle(string title);

        List<Video> GetVideoPagination(int startrows, int pagesize);
        int GetVideoCount();
        Video GetVideoByID(int id);

        void AddInquiry(Inquiry InquiryDTO);
        Inquiry GetInquiryById(int id);
        int GetLastestInquiryID();

        List<Testimonial> GetTestimonialPagination(int startrows, int pagesize);
        int GetTestimonialCount();

        List<News> GetNewsPagination(int startrows, int pagesize);
        int GetNewsCount();
        News GetNewsByID(int id);

        Application GetApplicationByName(string name);

    }
}
