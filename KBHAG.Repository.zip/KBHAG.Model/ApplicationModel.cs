﻿using System;
using System.ComponentModel.DataAnnotations;

namespace KBHAG.Model
{
    public class EventType
    {
        [Key]
        public int  EventTypeID         { get; set; }
        public string EventTypeName     { get; set; }
        public string EventTypeAlias    { get; set; }
        public string Active            { get; set; }
    }

    public class Event
    { 
        [Key]
        public int      EventID         { get; set; }
        public int      EventTypeID     { get; set; }
        public string   Title           { get; set; }
        public string   SubTitle        { get; set; }
        public string   ThumbImage      { get; set; }
        public DateTime StartDate       { get; set; }
        public DateTime EndDate         { get; set; }
        public string   TimeDesc        { get; set; }
        public string   Content         { get; set; }
        public string   MetaTitle       { get; set; }
        public string   MetaDesc        { get; set; }
        public string   MetaKeyWord     { get; set; }
        public string   Active          { get; set; }
    }

    public class ViewEvent
    { 
        [Key]
        public int      EventID         { get; set; }
        public int      EventTypeID     { get; set; }
        public string   EventTypeName   { get; set; }
        public string   EventTypeAlias  { get; set; }
        public string   Title           { get; set; }
        public string   SubTitle        { get; set; }
        public string   ThumbImage      { get; set; }
        public DateTime StartDate       { get; set; }
        public DateTime EndDate         { get; set; }
        public string   TimeDesc        { get; set; }
        public string   Content         { get; set; }
        public string   MetaTitle       { get; set; }
        public string   MetaDesc        { get; set; }
        public string   MetaKeyWord     { get; set; }
        public string   Active          { get; set; }
    }

    public class Featured
    {
        [Key]
        public int      FeaturedID      { get; set; }
        public int      EventID         { get; set; }
        public string   ShortContent    { get; set; }
        public string   FeaturedImage   { get; set; }
        public string   Active          { get; set; }
    }

    public class ViewFeatured
    { 
        [Key]
        public int      FeaturedID		{ get; set; }
        public int      EventID         { get; set; }
        public string   ShortContent    { get; set; }
        public string   FeaturedImage   { get; set; }
        public string   Active          { get; set; }
        public int      EventTypeID     { get; set; }
        public string   EventTypeName   { get; set; }
        public string   EventTypeAlias  { get; set; }
        public string   Title           { get; set; }
        public string   SubTitle        { get; set; }
        public string   ThumbImage      { get; set; }
        public DateTime StartDate       { get; set; }
        public DateTime EndDate         { get; set; }
        public string   TimeDesc        { get; set; }
        public string   Content         { get; set; }
        public string   MetaTitle       { get; set; }
        public string   MetaDesc        { get; set; }
        public string   MetaKeyWord     { get; set; }
    }

    public class SlideShow
    {
        [Key]
        public int      ID              { get; set; }
        public string   Title           { get; set; }
        public string   Desc            { get; set; }
        public string   ThumbImage      { get; set; }
        public string   Target          { get; set; }
        public int      TargetID        { get; set; }
        public string   MetaTitle       { get; set; }
        public string   MetaDesc        { get; set; }
        public string   MetaKeyWord     { get; set; }
        public int      Index           { get; set; }
        public string   ShowInGallery   { get; set; }
        public string   Active          { get; set; }
    }

    public class SlideShowMedia
    {
        [Key]
        public int      MediaID         { get; set; }
        public int      SlideShowID     { get; set; }
        public string   Caption         { get; set; }
        public string   FileName        { get; set; }
        public string   URL             { get; set; }
        public int      Index           { get; set; }
        public string   Active          { get; set; }
    }

    public class Press
    {
        [Key]
        public int      PressID         { get; set; }
        public string   Title           { get; set; }
        public string   PressImage      { get; set; }
        public DateTime PressDate       { get; set; }
        public string   PressURL        { get; set; }
        public string   FileName        { get; set; }
        public string   Active          { get; set; }
    }

    public class Video
    {
        [Key]
        public int ID                   { get; set; }
        public string Title             { get; set; }
        public string Desc              { get; set; }
        public string EmbedCode         { get; set; }
        public string ThumbImage        { get; set; }
        public string MetaTitle         { get; set; }
        public string MetaDesc          { get; set; }
        public string MetaKeyWord       { get; set; }
        public int Index                { get; set; }
        public string Active            { get; set; }
    }

    public class Inquiry
    { 
        [Key]
        public int      ID                  { get; set; }
        public int      TypeID              { get; set; }
        public string   TypeName            { get; set; }
        public string   PartyName           { get; set; }
        public string   ApplicantName       { get; set; }
        public string   MobileNo            { get; set; }
        public string   ContactNo           { get; set; }
        public string   EmailID             { get; set; }
        public string   Address             { get; set; }
        public string   City                { get; set; }
        public string   EventDate           { get; set; }
        public string   Message             { get; set; }
        public Nullable<DateTime> LogDate   { get; set; }
    }

    public class Testimonial
    {
        [Key]
        public int      ID                { get; set; }
        public string   Name              { get; set; }
        public string   Designation       { get; set; }
        public string   Photo             { get; set; }
        public string   Content           { get; set; }
        public int      Index             { get; set; }
        public string   Active            { get; set; }
    }

    public class News
    {
        [Key]
        public int      ID                 { get; set; }
        public string   Title              { get; set; }
        public string   ThumbImage         { get; set; }
        public string   Content            { get; set; }
        public string   MetaTitle          { get; set; }
        public string   MetaDesc           { get; set; }
        public string   MetaKeyWord        { get; set; }
        public int      Index              { get; set; }
        public string   Active             { get; set; }

    }
}
