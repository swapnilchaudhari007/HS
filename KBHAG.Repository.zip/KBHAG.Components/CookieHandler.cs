﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using KBHAG.Model;

namespace KBHAG.Components
{
    public class CookieHandler
    {
        #region Admin
        public static void CreateAdminCookie(AdminUserDTO user, bool remember)
        {
            HttpCookie cookieAdmin = new HttpCookie(Constants.ADMIN_LOGIN_COOKIE);

            cookieAdmin.Values.Add("USER_ID", Encrypt.Encryptstr(Convert.ToString(user.UserID)));            
            cookieAdmin.Values.Add("USER_NAME", Encrypt.Encryptstr(user.UserName));
            if (remember)
                cookieAdmin.Expires = DateTime.Now.AddMonths(1);
            HttpContext.Current.Response.Cookies.Add(cookieAdmin);

            HttpCookie cookie_adminuservalid = new HttpCookie(Constants.ADMIN_LOGIN_VALID);
            cookie_adminuservalid.Value = "Y";
            if (remember)
            {
                cookie_adminuservalid.Expires = DateTime.Now.AddMonths(1);
            }
            HttpContext.Current.Response.Cookies.Add(cookie_adminuservalid);
        }

        public static void KillAdminCookie()
        {
            HttpCookie cookieAdmin = HttpContext.Current.Request.Cookies[Constants.ADMIN_LOGIN_COOKIE];
            if (cookieAdmin != null)
            {
                cookieAdmin.Values.Set("USER_ID", "");
                cookieAdmin.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookieAdmin);
            }
            HttpCookie cookie_adminuservalid = HttpContext.Current.Request.Cookies[Constants.ADMIN_LOGIN_VALID];
            if (cookie_adminuservalid != null)
            {
                cookie_adminuservalid.Value = "";
                cookie_adminuservalid.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie_adminuservalid);
            }
        }

        public static bool VerifyAdminUser()
        {
            bool isValid = false;

            HttpCookie cookieAdmin = HttpContext.Current.Request.Cookies[Constants.ADMIN_LOGIN_COOKIE];
            if (cookieAdmin != null)
            {
                if (!String.IsNullOrEmpty(cookieAdmin.Values.Get("USER_ID")))
                {
                    HttpCookie cookie_adminvalid = HttpContext.Current.Request.Cookies[Constants.ADMIN_LOGIN_VALID];
                    if (cookie_adminvalid != null && cookie_adminvalid.Value == "Y")
                    {
                        isValid = true;
                    }
                }
            }
            return isValid;
        }

        public static AdminUserDTO GetAdminUser()
        {
            if (!VerifyAdminUser())
                return null;

            HttpCookie cookieAdmin = HttpContext.Current.Request.Cookies[Constants.ADMIN_LOGIN_COOKIE];

            AdminUserDTO user = new AdminUserDTO
            {
                UserID      = Convert.ToInt32(Encrypt.DecryptStr(cookieAdmin.Values.Get("USER_ID"))),                
                UserName    = Encrypt.DecryptStr(cookieAdmin.Values.Get("USER_NAME"))
            };

            return user;
        }

        public static AdminUserDTO CreateAdminUser(User user)
        {
            AdminUserDTO adminUser = new AdminUserDTO
            {
                UserID      = Util.Parse<int>(Util.Parse<string>(user.Id)),                
                UserName    = Util.Parse<string>(user.UserName)
            };

            return adminUser;
        }

        public static Boolean IsAuthorized()
        {
            int userid = 0;
            AdminUserDTO user = GetAdminUser();
            if (user != null)
            {
                userid = user.UserID;
                return true;
            }
            else
            {
                userid = 0;
                return false;
            }            
        }

        #endregion        
    }
}
