﻿using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class Header : System.Web.UI.UserControl
    {
        #region Declaration
        public int MenuId { get; set; }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Accessing Header Links
                GetData();

                if (string.IsNullOrEmpty(litMenu.Text))
                    BuildMenu(MenuId, "TopMenu", "jsddm");
            }
        }

        protected void GetData()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<HomePage>();
                repo.UnitOfWork = uow;
                var query = repo.GetMany(i => i.Type == "Header");

                foreach (var item in query)
                {
                    switch (item.Key)
                    {
                        case "HallLink":
                            this.HallLink.HRef = Page.ResolveUrl("~/" + item.Value);
                            break;

                        case "GalleryLink":
                            this.GalleryLink.HRef = Page.ResolveUrl("~/" + item.Value);
                            break;

                        case "WorkshopLink":
                            this.WorkshopLink.HRef = Page.ResolveUrl("~/" + item.Value);
                            break;

                        default:
                            //Not Implemented
                            break;
                    }
                }
            }
        }

        public void BuildMenu(int currentid, string RenderId = "", string RenderClass = "")
        {
            var repo = new MenuRepository();
            List<BreadCrumbDTO> bcList = new List<BreadCrumbDTO>();

            var menuList = repo.GetMenuTree();

            string strMenu = "";

            int totalPar = menuList.Count(i => i.ParentID == 0);

            if (totalPar > 0)
            {
                strMenu = "<ul";
                if (!string.IsNullOrEmpty(RenderId))
                    strMenu += " id='" + RenderId + "'";

                if (!string.IsNullOrEmpty(RenderClass))
                    strMenu += " class='" + RenderClass + "'";

                strMenu += ">";
                var lstMenus = menuList.Where(i => i.ParentID == 0).ToList();

                foreach (var mnuParent in lstMenus) // Loop through List with foreach
                {
                    //string aHref    = RoutingHelpers.GetURL(mnuParent.CMS_SITE_ALLIAS, mnuParent.Level1, mnuParent.Allias, Util.Parse<int>(mnuParent.ApplicationId), LanguageCode, SiteApplicationLanguageList);
                    string aHref = WebsiteHelpers.GetAbsolutePath(mnuParent.ParentUrl);
                    //Handle Target over here dependant on Application
                    //string target = RoutingHelpers.GetAnchorTarget(LanguageCode, Util.Parse<int>(mnuParent.ApplicationId), SiteApplicationLanguageList);

                    strMenu += "<li>";

                    strMenu += "<a id='parent_" + mnuParent.Allias + "' href='" + aHref + "'";
                    
                    
                    if (mnuParent.MenuID == currentid)
                    {
                        strMenu += " class='active'";
                        bcList.Add(new BreadCrumbDTO
                        {
                            LinkName = mnuParent.Title,
                            LinkUrl = WebsiteHelpers.GetAbsolutePath(mnuParent.ParentUrl)

                        });
                    }
                    else
                    {
                        Boolean isActive = false;
                        var findActive = menuList.FirstOrDefault(i => i.ParentID == mnuParent.MenuID && i.MenuID == currentid);
                        if (findActive != null)
                        {
                            strMenu += " class='active'";
                            isActive = true;
                            bcList.Add(new BreadCrumbDTO
                            {
                                LinkName = mnuParent.Title,
                                LinkUrl = WebsiteHelpers.GetAbsolutePath(mnuParent.ParentUrl)

                            });
                            bcList.Add(new BreadCrumbDTO
                            {
                                LinkName = findActive.Title,
                                LinkUrl = RoutingHelpers.GetMenuRouteURL(mnuParent.Allias, findActive.Allias, findActive.AppName)

                            });
                        }

                        //second level check for active menu
                        if (!isActive)
                        {
                            var lstChk = menuList.Where(i => i.ParentID == mnuParent.MenuID).ToList();
                            foreach (var cmnu in lstChk)
                            {
                                var findAct = menuList.FirstOrDefault(i => i.ParentID == cmnu.MenuID && i.MenuID == currentid);
                                if (findAct != null)
                                {
                                    strMenu += " class='active'";
                                    bcList.Add(new BreadCrumbDTO
                                    {
                                        LinkName = mnuParent.Title,
                                        LinkUrl = WebsiteHelpers.GetAbsolutePath(mnuParent.ParentUrl)

                                    });
                                    bcList.Add(new BreadCrumbDTO
                                    {
                                        LinkName = cmnu.Title,
                                        LinkUrl = RoutingHelpers.GetMenuRouteURL(mnuParent.Allias, cmnu.Allias, cmnu.AppName)

                                    });
                                    bcList.Add(new BreadCrumbDTO
                                    {
                                        LinkName = findAct.Title,
                                        LinkUrl = RoutingHelpers.GetMenuRouteURL(mnuParent.Allias, cmnu.Allias, findAct.AppName, findAct.Allias)

                                    });
                                }
                            }
                        }
                    }

                    strMenu += ">" + mnuParent.Title + "</a>";

                    //checking and building drop down
                    var lstSub = menuList.Where(i => i.ParentID == mnuParent.MenuID).ToList();
                    if(lstSub.Count > 0)
                        strMenu += getChildMenus(lstSub);
                    strMenu += "</li>";
                }
                strMenu += "</ul>";
                litMenu.Text = strMenu;

                Page page = HttpContext.Current.Handler as Page;
                BreadCrumb bc = page.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.BCDTO = bcList;
                bc.CreateBreadCrumb();
            }
        }

        protected string getChildMenus(List<ViewMenu> lstSub)
        {
            
            string returnChild = "<ul>";
            foreach (var mnu in lstSub) // Loop through List with foreach
            {
                    returnChild += "<li>";

                    string aHref = RoutingHelpers.GetMenuRouteURL(mnu.ParentAllias, mnu.Allias, mnu.AppName);

                    returnChild += "<a href='" + aHref + "'>" + mnu.Title + "</a></li>"; // add a class here if required.
            }

            returnChild += "</ul>";

            return returnChild;
        }

    }
}