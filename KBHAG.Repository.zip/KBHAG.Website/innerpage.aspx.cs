﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;


namespace KBHAG.Website
{
    public partial class innerpage : System.Web.UI.Page
    {
        #region Declaration
            public  int level0id        = 0;                    
            public  int pageid          = 0;
            public  int currentMenuID   = 0;
            public  int totalDataCount  = 0;
            public  int layoutID        = 0;

            public string level0        = string.Empty;
            public string level1        = string.Empty;
            public string level2        = string.Empty;
            public string isUnpublish   = "false";

            string siteName             = string.Empty;

            public string ControlJson   = "[]";

        #endregion

        #region Method

        private void GetData()
        {

            var repoPage = new PageRepository();
            var pageData = repoPage.GetPageByPageID(pageid);

            if (pageData == null)
                Response.Redirect(Page.ResolveUrl("~/notfound.aspx?level0=" + level0 + "&level1=" + level1 + "&level2=" + level2));

            //Set Page Title
            this.Page.Title = WebsiteHelpers.GetPageTitle(pageData.MetaTitle);

            //Set Meta Tag Keywords                
            this.MetaPlaceHolder.Controls.Add(WebsiteHelpers.GetHtmlMeta("keywords", pageData.MetaKeyWord));

            //Set Meta Tag Description               
            this.MetaPlaceHolder.Controls.Add(WebsiteHelpers.GetHtmlMeta("description", pageData.MetaDesc));

            //Page Data List
            List<PageDataDTO> pageDataList = repoPage.GetPageContentByPageID(pageid)
                                                .Select(n => new PageDataDTO
                                                {
                                                    ID      = n.RenderID,
                                                    Tag     = n.RenderTag,
                                                    Text    = n.Content,
                                                    Type    = n.ControlName
                                                }).ToList();

            List<PageEditDTO> pageDataEditList = repoPage.GetPageContentByPageID(pageid)
                                                .Select(n => new PageEditDTO
                                                {
                                                    PageDataID  = n.PageDataID,
                                                    RenderTag   = n.RenderTag,
                                                    RenderName  = n.RenderID,
                                                    Validation  = n.Validation,
                                                    Control     = n.ControlName
                                                }).ToList();

            layoutID = pageData.LayoutID;
                       
            //Create Layout Html
            string myLayout = WebsiteHelpers.RenderHtml(repoPage.GetLayoutHTML(pageData.LayoutID), pageDataList);
            
            //Looking for page slide show
            var slideShow = WebsiteHelpers.GetPageSlideShowId(pageDataList);
            if (slideShow != null)
            {
                string slideshow = WebsiteHelpers.GenerateSlideShow(Util.Parse<int>(slideShow.Text));
                if (!String.IsNullOrEmpty(slideshow))
                    myLayout = WebsiteHelpers.ModifyHtmlTagById(myLayout, "div", slideShow.ID, slideshow);
            }
            
            this.layoutPlaceHonder.InnerHtml = WebsiteHelpers.RemoveCData(myLayout);

            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                ControlJson = JsonConvert.SerializeObject(pageDataEditList, Formatting.Indented);
            }

            //Run Page Custom Javascript
            runjQueryCode(Util.Parse<string>(pageData.JavaScript));
        }


        private void runjQueryCode(string jsCodetoRun)
        {

            ScriptManager requestSM = ScriptManager.GetCurrent(this);
            if (requestSM != null && requestSM.IsInAsyncPostBack)
            {
                ScriptManager.RegisterClientScriptBlock(this,
                                                        typeof(Page),
                                                        Guid.NewGuid().ToString(),
                                                        WebsiteHelpers.GetjQueryCode(jsCodetoRun),
                                                        true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(typeof(Page),
                                                       Guid.NewGuid().ToString(),
                                                       WebsiteHelpers.GetjQueryCode(jsCodetoRun),
                                                       true);
            }
        }
        
        #endregion

        #region Event
        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var repoMenu = new MenuRepository();
                level0      = (Page.RouteData.Values["level0"] != null) ? (Page.RouteData.Values["level0"] as string).ToLower() : string.Empty;
                level1      = (Page.RouteData.Values["level1"] != null) ? (Page.RouteData.Values["level1"] as string).ToLower() : string.Empty;
                level2      = (Page.RouteData.Values["level2"] != null) ? (Page.RouteData.Values["level2"] as string).ToLower() : string.Empty;

                if (!string.IsNullOrEmpty(level2))
                    currentMenuID = repoMenu.GetMenuIDByAlliasName(level1, level2);
                else if (!string.IsNullOrEmpty(level1))
                    currentMenuID = repoMenu.GetMenuIDByAlliasName(level0, level1);
                else if (!string.IsNullOrEmpty(level0))
                    currentMenuID = repoMenu.GetMenuIDByAlliasName("", level0);
                else
                {
                    if (Request.QueryString["menuid"] != null)
                    {
                        currentMenuID = int.Parse(Request.QueryString["menuid"].ToString());
                    }
                    else
                    {
                        currentMenuID = 0;
                    }
                }

                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = currentMenuID;

                if (Request.QueryString["pageid"] != null)
                {
                    isUnpublish = "true";
                    pageid = int.Parse(Request.QueryString["pageid"].ToString());                    
                }
                else
                {
                    isUnpublish = "false";
                    pageid = repoMenu.GetPublishPageID(currentMenuID);
                }

                this.hidden_level0.Value    = level0;
                this.hidden_level1.Value    = level1;
                this.hidden_level2.Value    = level2;

                this.hidden_currentmenuid.Value = currentMenuID.ToString();
                this.hidden_url.Value = Request.Url.AbsolutePath;

                if (!CookieHandler.IsAuthorized())
                    ucContentEditor.Visible = false;

                GetData();
            }
        }
        #endregion

        #region Web Method

        [WebMethod]
        public static string Ecouter(PageData PageDataDTO)
        {
            string json = string.Empty;            
            List<RowCollection> rows = new List<RowCollection>();

            try
            {
                var repo = new PageRepository();
                repo.UpdatePageData(PageDataDTO);                

                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });              

                json = JsonConvert.SerializeObject(rows, Formatting.Indented);

            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
                json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            }

            return json;
        }

        [WebMethod]
        public static string EcouterPage(CMSPage PageDTO)
        {
            string json = string.Empty;
            int pageid = 0;
            List<RowCollection> rows = new List<RowCollection>();

            try
            {
                //Insert Record in CMS_PAGE 
                var pageRepo = new PageRepository();
                pageid = pageRepo.AddPage(PageDTO);

                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "PageID", ColumnValue = pageid.ToString() });
            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
            }
            json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            return json;
        }

        [WebMethod]
        public static string EcouterPageData(PageContentDTO PageContentDTO)
        {
            string json = string.Empty;
            List<RowCollection> rows = new List<RowCollection>();

            try
            {
                var repo = new PageRepository();

                foreach (var item in repo.GetMapLayoutStructureByLayoutID(PageContentDTO.LayoutID))
                {
                    //Insert Record in CMS_PAGE_DATA
                    PageData pageData = new PageData 
                    { 
                        PageID          = PageContentDTO.PageID,
                        PageStructureID = item.PageStructureID,
                        Content         = item.DefaultContent
                    };
                    repo.AddPageData(pageData);
                }                
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });
            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
            }

            json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            return json;
        }        

        [WebMethod]
        public static string EcouterPageEdit(CMSPage PageDTO)
        {
            string json = string.Empty;

            List<RowCollection> rows = new List<RowCollection>();
            try
            {
                var repo = new PageRepository();
                repo.UpdatePage(PageDTO);                
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "PageID", ColumnValue = PageDTO.PageID.ToString() });
            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
            }
            json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            return json;
        }

        [WebMethod]
        public static string GetSEO(int PageID)
        {
            string json = string.Empty;
            var repo = new PageRepository();
            var page = repo.GetPageByPageID(PageID);

            if (page != null)
            {
                var dto = new CommonDTO
                {
                    DTO1 = page.MetaTitle,
                    DTO2 = page.MetaDesc,
                    DTO3 = page.MetaKeyWord
                };
                return JsonConvert.SerializeObject(dto, Formatting.Indented);
            }
            else
            {
                return string.Empty;
            }
        }

        [WebMethod]
        public static string GetPageListing(int menuid)
        {
            var repo = new PageRepository();
            return JsonConvert.SerializeObject(repo.GetPagesByMenuID(menuid), Formatting.Indented);
        }

        [WebMethod]
        public static string PublishMe(int pageid, int menuid)
        {
            string json = string.Empty;
            try
            {
                var repo = new PageRepository();
                PagePublish DTO = new PagePublish {  PageID = pageid, MenuID = menuid };
                repo.PublishPage(DTO);
                json = Constants.SUCCESS_MESSAGE;
            }
            catch (Exception)
            {
                json = Constants.ERROR_MESSAGE;

            }
            return json;
        }

        [WebMethod]
        public static string GetJavascript(int PageID)
        {
            var repo = new PageRepository();

            var objPage = repo.GetPageByPageID(PageID);
            if (objPage != null)
            {
                var dto = new CommonDTO
                {
                    DTO1 = objPage.JavaScript
                };
                return JsonConvert.SerializeObject(dto, Formatting.Indented);
            }
            else
            {
                return JsonConvert.SerializeObject("[]", Formatting.Indented);
            }
        }

        [WebMethod]
        public static string EcouterJavascriptEdit(int pageid, string javascript)
        {
            string json = string.Empty;

            List<RowCollection> rows = new List<RowCollection>();

            try
            {   
                var repo = new PageRepository();
                repo.UpdateJavaScript(pageid, javascript);                

                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.SUCCESS_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "PageID", ColumnValue = pageid.ToString() });
            }
            catch (Exception ex)
            {
                rows.Add(new RowCollection { ColumnName = "Action", ColumnValue = Constants.ERROR_MESSAGE });
                rows.Add(new RowCollection { ColumnName = "Error", ColumnValue = ex.ToString() });
            }
            json = JsonConvert.SerializeObject(rows, Formatting.Indented);
            return json;
        }
        #endregion
    }
}