﻿using KBHAG.Components;
using KBHAG.Repository;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.Ajax
{
    public partial class ajaxManager : System.Web.UI.Page
    {
        #region Declarations
        #endregion

        #region Method
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region Web Methods
        [WebMethod]
        public static string GetGridData(int? numRows, int? page, string sortField, string sortOrder, bool isSearch, string gridModel, string[] columnName, string primaryKey, string joinQuery, string filters = "")
        {
            string result = null;

            int nRows = numRows ?? Constants.GLOBAL_ITEM_PER_PAGE;
            int iPage = page ?? 1;

            GridManager manage = new GridManager
            {
                nRows           = nRows,
                iPage           = iPage,
                sortColumnName  = sortField,
                sortOrder       = !String.IsNullOrEmpty(sortOrder) && String.Compare(sortOrder, "desc", StringComparison.Ordinal) == 0 ? Constants.SORT_ORDER.Desc.ToString() : Constants.SORT_ORDER.Asc.ToString(),
                isSearch        = isSearch,
                filters         = filters,
                gridModel       = gridModel,
                columnName      = columnName,
                primaryKey      = primaryKey,
                joinQuery       = joinQuery
            };

            result = JsonConvert.SerializeObject(manage.GetGridDataForJqGrid());

            return result;
        }
        #endregion
    }
}