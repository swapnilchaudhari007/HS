﻿using KBHAG.Components;
using KBHAG.Model;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Manage
{
    public partial class ucMediaManage : System.Web.UI.UserControl
    {
        #region Declaration

        public string   MediaAction { get; set; }
        public string   Target      { get; set; }
        public int      TargetId    { get; set; }
        public int      CoverHeight { get; set; }
        public int      CoverWidth  { get; set; }
        public int      IMAGEWIDTH  { get; set; }
        public int      IMAGEHEIGHT { get; set; }
        public int      GRIDWIDTH   { get; set; }
        public int      GRIDHEIGHT  { get; set; }
        public int      AlbumId     { get; set; }


        public string redirectUrl   {get;   set;}
        public string imagefinalfolder  = Constants.IMAGE_FOLDER_PATH;
        public string MediaCall         = "";

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(redirectUrl))
                redirectUrl = Page.ResolveUrl("~/administrator/index.aspx?section=applications&page=slide-show&action=v");            

            if (MediaAction != "e")
                UpdateAlbum.Visible = false;

            if (MediaAction == "p")
                CheckMediaForPage();

            CheckMedia();
        }        

        protected void Cancel_ClickHandler(object sender, EventArgs e)
        {
            Response.Redirect(redirectUrl);
        }
        #endregion

        #region Methods

        private void CheckMediaForPage()
        {
            var repo = new ApplicationRepository();

            var album = repo.GetSlideShowByTargetAndTargetID(Target, TargetId);
            
            if (album == null)
            {

                var repoPage = new PageRepository();

                var pageData = repoPage.GetPageDataByID(TargetId);

                var page = repoPage.GetPageByPageID(pageData.PageID);

                SlideShow slideShow = new SlideShow 
                { 
                    Title           = page.Title,
                    Desc            = page.Title,
                    ThumbImage      = string.Empty,
                    Target          = Target,
                    TargetID        = TargetId,
                    MetaTitle       = page.MetaTitle,
                    MetaKeyWord     = page.MetaKeyWord,
                    MetaDesc        = page.MetaDesc,
                    Index           = 0,
                    ShowInGallery   = "N",
                    Active          = "Y"
                };
                AlbumId =  repo.AddSlideShow(slideShow);

                //Update PageData
                PageData DTO = new PageData{
                    PageDataID = TargetId,
                    Content = Util.Parse<string>(AlbumId) 
                };
                repoPage.UpdatePageData(DTO);
            }
            else
            {
                AlbumId = album.ID;
            }

            Response.Redirect("~/manage/AlbumManage.aspx?section=16&pageid=18&target=page&targetid=" + TargetId + "&imagewidth=" + IMAGEWIDTH + "&imageheight=" + IMAGEHEIGHT + "&action=e&id=" + AlbumId);

        }

        protected void CheckMedia()
        {
            if (AlbumId > 0)
            {
                var repo    = new ApplicationRepository();
                var album   = repo.GetSlideShowByID(AlbumId);
                if (album != null)
                {
                    txtAlbumName.Text           = Convert.ToString(album.Title);
                    txtAlbumDesc.Text           = Convert.ToString(album.Desc);
                    txtAlbumIndex.Text          = Convert.ToString(album.Index);
                    txtAlbumMetaTitle.Text      = Convert.ToString(album.MetaTitle);
                    txtAlbumMetaDesc.Text       = Convert.ToString(album.MetaDesc);
                    txtAlbumMetaKeyword.Text    = Convert.ToString(album.MetaKeyWord);
                    txtAlbumActive.Checked      = (Convert.ToString(album.Active) == "Y") ? true : false;
                    chkIsGallery.Checked        = (Convert.ToString(album.ShowInGallery) == "Y") ? true : false;                    
                    imgAlbumCover.ImageUrl      = Page.ResolveUrl("~/media/images/content/" + Convert.ToString(album.ThumbImage));

                    var lstMedia = repo.GetMediaByAlbumID(AlbumId);
                    lvAlbum.DataSource  = lstMedia;
                    lvAlbum.DataBind();
                    lvAlbum.Visible = true;

                    if (album.ShowInGallery != "Y")
                    {
                        this.ShowInGalleryHolder.Attributes.Add("class", "display-none");
                    }

                }
            }
        }
        #endregion
    }
}