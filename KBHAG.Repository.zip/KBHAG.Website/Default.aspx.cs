﻿using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace KBHAG.Website
{
    public partial class Default : System.Web.UI.Page
    {

        #region Declaration
        string strShowcase = string.Empty;
        #endregion

        #region Method

        protected void fetchData()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<HomePage>();
                repo.UnitOfWork = uow;
                var query = repo.GetMany(i=> i.Type == "HomePage").ToList();

                foreach (var item in query)
                {
                    switch (item.Key)
                    {
                        case "SpotLight.Header":
                            //this.headSpotLight.InnerHtml = item.Value;
                            strShowcase = item.Value;
                            break;
                        case "SpotLight.Text":
                            this.lblSpotLight.Text = item.Value;
                            break;
                        case "SpotLight.Image":
                            this.imgSpotLight.ImageUrl = WebsiteHelpers.GetAbsolutePath(item.Value);
                            this.imgSpotLight.AlternateText = Path.GetFileNameWithoutExtension(this.imgSpotLight.ImageUrl);                            
                            break;
                        case "SpotLight.Url":
                            this.lnkSpotLight.NavigateUrl = item.Value;
                            this.lnkImage.HRef = item.Value;
                            this.headSpotLight.InnerHtml = "<a href='" + item.Value + "'>" + strShowcase + "</a>";
                            break;
                        case "HomePage.CenterImage":
                            this.imgMain.Src = WebsiteHelpers.GetAbsolutePath(item.Value);
                            break;
                        case "HomePage.Content":
                            this.right_content.InnerHtml = item.Value;
                            break;
                        //case "HomePage.LeftUrl":
                        //    this.home_LeftUrl.NavigateUrl = item.Value;
                        //    //this.right_content.InnerHtml = item.Value;
                        //    break;
                        //case "HomePage.CenterUrl":
                        //    this.home_CentreUrl.NavigateUrl = item.Value;
                        //    //this.right_content.InnerHtml = item.Value;
                        //    break;
                        //case "HomePage.RightUrl":
                        //    this.home_RightUrl.NavigateUrl = item.Value;
                        //    //this.right_content.InnerHtml = item.Value;
                        //    break;

                        default:
                            //Not Implemented
                            break;
                    }
                }
            } 
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            //MasterPage mp = this.Master as MasterPage;
            BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
            bc.HideBreadCrumb();
            
            if (!IsPostBack)
            {
                fetchData();
            }
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}