﻿using CKEditor.NET;
using Newtonsoft.Json.Linq;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Components
{
    public class CreateControls
    {
        public static Label GetLabel(string id, string cssClass, string text = "")
        {
            Label lbl = new Label();

            lbl.ID = id;
            lbl.CssClass = cssClass;
            lbl.Text = text;

            return lbl;
        }

        public static HtmlGenericControl GetHtmlGenericControl(string id, string cssClass, string tagName, string innerText, string forName)
        {
            HtmlGenericControl genericControl = new HtmlGenericControl();

            genericControl.TagName = tagName;
            genericControl.InnerText = innerText;

            if (tagName == "label")
            {
                genericControl.Attributes.Add("for", forName);
                genericControl.Attributes.Add("class", cssClass);
            }
            else
            {
                if (!string.IsNullOrEmpty(id))
                {
                    genericControl.Attributes.Add("id", id);    
                }                
                genericControl.Attributes.Add("class", cssClass);
            }

            return genericControl;
        }

        public static TextBox GetTextBox(string id, string cssClass, int maxLength, string text)
        {
            TextBox txt = new TextBox();

            txt.ID = id;
            txt.CssClass = cssClass;
            txt.MaxLength = (maxLength != 0) ? maxLength : 10000;
            txt.Text = (text != string.Empty) ? text : string.Empty;            

            return txt;
        }

        public static TextBox GetTextArea(string id, string cssClass, string text)
        {
            TextBox txtArea = new TextBox();

            txtArea.ID = id;
            txtArea.CssClass = cssClass;
            txtArea.TextMode = TextBoxMode.MultiLine;
            txtArea.Text = (text != string.Empty) ? text : string.Empty;
            txtArea.Rows = 4;

            return txtArea;
        }

        public static CheckBox GetCheckBox(string id, string isCheck, string cssClass)
        {
            CheckBox chk = new CheckBox();

            chk.ID = id;
            chk.Width = 20;
            chk.Checked = (isCheck == "Y") ? true : false;
            chk.CssClass = cssClass;

            return chk;
        }        

        public static DropDownList GetDropdownList(string id, string cssClass, string type, string selectedValue)
        {
            bool autoPostBack = false;
            DropDownList ddl = new DropDownList();
            ddl.ID = id;
            ddl.CssClass = cssClass;

            string parentType = string.Empty;
            JObject genericJsonObject = null;

            if (!String.IsNullOrEmpty(type))
            {
                JObject jsonObject = JObject.Parse(type);
                if (jsonObject["Dropdown"] != null)
                {
                    parentType = (string)jsonObject["Dropdown"]["ParentDataSource"];

                    if (jsonObject["Dropdown"]["Generic"] != null)
                    {
                        genericJsonObject = (JObject)jsonObject["Dropdown"]["Generic"];
                    }

                    if (jsonObject["Dropdown"]["TargetID"] != null)
                    {
                        autoPostBack = true;
                    }
                }
                ddl.AutoPostBack = autoPostBack;
                if (autoPostBack)
                {
                    ddl.SelectedIndexChanged += new EventHandler(dropdownlist_SelectedIndexChanged);
                }
            }

            int dropdownConditionID = 0;

            DropDownManager DropDownManager = new DropDownManager(ddl, parentType, selectedValue, genericJsonObject, dropdownConditionID);

            return DropDownManager.FillDropDownList();
        }

        public static HiddenField CreateHiddenField(string id, string value)
        {
            HiddenField hidden = new HiddenField();
            hidden.ID = id;
            hidden.Value = value;
            return hidden;
        }

        public static void dropdownlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pageid = Convert.ToInt32(HttpContext.Current.Request.QueryString["pageid"]);
            Page page = (Page)HttpContext.Current.Handler;
            DropDownList parentDropDownList;

            if (sender != null)
            {
                parentDropDownList = (DropDownList)sender;
            }
            else
            {
                parentDropDownList = (DropDownList)page.Master.FindControl("ContentPlaceHolderMain").FindControl("ddl");
            }

            //ComponentBridge bridge = new ComponentBridge();
            var uow = new KBHAGUnitOfWork();
            var repoAdminPageStructure = new GenericRepository<FormStructure>();
            repoAdminPageStructure.UnitOfWork = uow;

            var pageStructure = repoAdminPageStructure.Get(i => i.PageID == pageid && i.RenderID == parentDropDownList.ID);

            string callBackString = (pageStructure != null) ? pageStructure.Callback : string.Empty;
            
            JObject jsonObject = JObject.Parse(callBackString);
            string targetid = string.Empty;
            string targetType = string.Empty;

            if (jsonObject["Dropdown"] != null)
            {
                targetid = (string)jsonObject["Dropdown"]["TargetID"];
                targetType = (jsonObject["Dropdown"]["TargetType"] != null) ? (string)jsonObject["Dropdown"]["TargetType"] : string.Empty;
            }

            DropDownList ddl = (DropDownList)page.Master.FindControl("ContentPlaceHolderMain").FindControl(targetid);

            ddl.ClearSelection();
            ddl.Items.Clear();
            ddl.SelectedIndex = -1;
            ddl.DataSource = null;
            ddl.SelectedValue = null;

            string dropdownType = string.Empty;
            int dropdownValue = 0;

            if (targetType != string.Empty)
            {
                dropdownType = targetType;
                int i = 0;
                bool canConvert = int.TryParse(parentDropDownList.SelectedValue, out i);

                if (canConvert == true)
                {
                    dropdownValue = i;
                }
                else
                {
                    dropdownValue = 0;
                    dropdownType = parentDropDownList.SelectedValue;
                }

            }
            else
            {
                dropdownType = parentDropDownList.SelectedValue;
                dropdownValue = 0;
            }

            DropDownManager DropDownManager = new DropDownManager(ddl, dropdownType, string.Empty,null, dropdownValue);
            DropDownManager.FillDropDownList();
        }

        public static Image GetImageControl(string id, string imgURL)
        {
            Image img = new Image();

            img.ID = id;
            img.ImageUrl = imgURL;
            
            return img;
        }

        public static HtmlAnchor GetHtmlAnchor(string id, string cssClass, string href, string innerText, string target)
        {
            HtmlAnchor anchor = new HtmlAnchor();

            anchor.ID = id;
            anchor.Attributes.Add("class", cssClass);
            anchor.HRef = href;
            anchor.InnerText = innerText;

            if (!string.IsNullOrEmpty(target))
            {
                //anchor.Target = "_blank";    
                anchor.Target = target;    
            }           

            return anchor;
        }

        public static HtmlImage GetHtmlImage(string id, string cssClass, string fileName, int width, int height)
        {
            HtmlImage image = new HtmlImage();

            image.ID = id;
            image.Attributes.Add("class", cssClass);
            image.Src = fileName;
            image.Width = width;
            image.Height = height;
            return image;
        }

        public static CKEditorControl GetHTMLTextEditor(string id, string cssClass, string text, string toolbar)
        {
            CKEditorControl ckEditor = new CKEditorControl();

            ckEditor.ID = id;
            ckEditor.CssClass = cssClass;
            ckEditor.Text = (text != string.Empty) ? text : string.Empty;
            ckEditor.Toolbar = (toolbar != string.Empty) ? toolbar : "Basic";

            return ckEditor;
        }

        public static FileUpload GetFileUpload(string id, string cssClass)
        {
            FileUpload fileupload = new FileUpload();
            fileupload.ID = id;
            fileupload.CssClass = cssClass;

            return fileupload;
        }

        public static HtmlMeta GetHtmlMeta(string metaName, string metaContent)
        {
            HtmlMeta meta = new HtmlMeta();
            meta.Name = metaName;
            meta.Content = metaContent;
            return meta;
        }

        public static string GetjQueryCode(string jsCodetoRun)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("$(document).ready(function() {");
            sb.AppendLine(jsCodetoRun);
            sb.AppendLine(" });");

            return sb.ToString();
        }        
               
    }
}
