﻿//Document.Get Ready
var firstLoad = true;
var NavigateObject;
var strPageHash = "";

$(function () {
    $('[id$=hidden_page]').val(pageid);

    if ($('.album_display_div').length > 0) {
        var shareid = "";

        if ($('#image_show_share').length > 0)
            shareid = "image_show_share";

        shareUrl = app.utils.ResolveUrl("~/share/" + $('[id$=hidden_menu]').val() + "/pictures/");

        if ($('.album_display_div').find("div").size() > 1)
        {
            $('.album_display_div').find("div").each(function(index, ele){
                $(this).addClass("slides_container");
            });

            $('.album_display_div').slides({
                effect: 'fade',
                crossfade: true,
                generateNextPrev: false,
                generatePagination: false,
                play: 8000
            });
        } else {
            $('#imageText').html($('[id^=ImagePlaceHolder]').find('img').eq(0).attr('alt'));
            $('#imageText').css('width', $('[id^=ImagePlaceHolder]').width() + 10 + "px");
            $('#imageText').parent().css('width', $('[id^=ImagePlaceHolder]').width() + 10 + "px");
            //$('#imageText').parent().jScrollPane({ showArrows: true, scrollbarWidth: 13, horizontalGutter: 10, arrowSize: 16 });
        }
    }

    bearbeiten();//Create Edit Controls    

    if (isUnpublish === "true") {
        ShowPublish();
    }


    //-------------------------Content Editor---------------------------------------------------
    var obj;
    var updateControl;

    $('#EditContainer_Cancel').click(function (e) {
        $('[id$=layoutPlaceHonder]').show();
        $('[id$=ContentEditorlayoutPlaceHonder]').hide();
    });

    $('.btnContentEditor').click(function (e) {
        e.preventDefault();
        $('[id$=layoutPlaceHonder]').hide();
        $('[id$=ContentEditorlayoutPlaceHonder]').show();

        var instance = CKEDITOR.instances['EditContainerContent'];
        if (instance) {
            instance.destroy();
        }

        var param = $(this).prop('rel').split("|");
        CKEDITOR.replace('EditContainerContent',
        {
            width: param[0],
            height: param[1],
            toolbar: param[2]
        });

        updateControl = param[3];
        
        $('[id$=hidden_ContentEditorControlID]').val(updateControl);
        $('[id$=hidden_ContentEditorPageDataID]').val(param[4]);
        
        obj = $('#' + updateControl).find('#' + updateControl.split('_', 1) + '_More');
        $(obj).remove();

        CKEDITOR.instances.EditContainerContent.setData($('#' + updateControl).html());
    });


    $('#EditContainer_Save').click(function (e) {
        e.preventDefault();
        var control = $('[id$=hidden_ContentEditorControlID]').val();
        $('#' + control).html(CKEDITOR.instances.EditContainerContent.getData());

        if ($('#' + updateControl).length > 0)
            $('#' + updateControl).html(CKEDITOR.instances.EditContainerContent.getData());
        
        ReadyToCommunicate(CKEDITOR.instances.EditContainerContent.getData(), $('[id$=hidden_ContentEditorPageDataID]').val(), null);
        $('[id$=layoutPlaceHonder]').show();
        $('[id$=ContentEditorlayoutPlaceHonder]').hide();
    });
    //-------------------------Content Editor---------------------------------------------------

    $('.imageButton').click(function () {
        var rel = $(this).prop('rel').split('|');        
        var url = app.utils.ResolveUrl("~/Manage/photoupload.aspx");
        $.fancybox.open({
            href: url + "?iswebsite=true&mediatype=image&mediascript=SavePageImage&isalbum=n&gridheight=550&gridwidth=1000&imagewidth=" + rel[1].replace('px', '') + "&&imageheight=" + rel[2].replace('px', '') + "&mediaid=" + rel[0] + "&mediafield=" + rel[3],
            type: 'ajax',
            padding: 5
        });
    });    

});
//Document.Get Ready


function bearbeiten() {
    
    $.each(ControlJson, function (index, domEle) {
        
        var obj;
        if ($("[id$='" + this['RenderName'] + "']").length > 0) {
            obj = $("[id$='" + this['RenderName'] + "']");
        }

        var Validation = jQuery.parseJSON(this['Validation']);
        
        switch (this['Control'].toLowerCase()) {
            
            case "text"://Text Field
                CreateButtonForText(this['PageDataID'], this['RenderName'], Validation);
                break;

            case "image"://Image
                CreateButtonForImage(this['PageDataID'], this['RenderName'], Validation);
                break;

            case "link"://Link
                CreateButtonForLink(this['PageDataID'], this['RenderName'], Validation);
                break;

            case "slideshow"://Page Media
                CreateButtonForMedia(this['PageDataID'], this['RenderName'], Validation);
                break;
        }

    });

}

function CreateButtonForMedia(pagedataid, controlid, Validation) {

    var url         = app.utils.ResolveUrl("~/manage/AlbumManage.aspx?section=16&pageid=18");
    var imageWidth = "&imagewidth=" + Validation.Image.Width.replace('px', '');
    var imageHeidht = "&imageheight=" + Validation.Image.Height.replace('px', '');
    var target      = "&target=page";
    var targetid    = "&targetid=" + pagedataid;
    var redirecturl = "&redirecturl=" + window.location.pathname;
    var href        = url + target + targetid + imageWidth + imageHeidht + redirecturl + "&action=p";

    var createATag = "<a href='" + href + "' id='" + controlid + "_EditMedia' class='editstyle' target='_blank' rel='" + pagedataid + "'>Edit Media</a>";
    $("[id$=" + controlid + "]").after("<div id='" + controlid + '_EditMedia' + "' class='divAddEdit'>" + createATag + "</div>");
}

function CreateButtonForLink(pagedataid, controlid, Validation) {
    var url = app.utils.ResolveUrl("~/ajax/linkGenerator.aspx");
    width = Validation.Window.Width;
    height = Validation.Window.Height;
    var createATag = "<a href='" + url + "?modal=false&width=" + width + "&height=" + height + "&control=" + controlid + "&action=" + action + "' id='" + controlid + "_Edit' class='thickboxs editstyle' rel='" + pagedataid + "'>" + textATag + " Link</a>";
    //$("[id$='" + controlid + "']").after(createATag);
}

function CreateButtonForText(pagedataid, controlid, Validation) {
    width = Validation.Window.Width;
    height = Validation.Window.Height;
    toolbar = Validation.Editor.toolbar;
    
    if ($('#' + controlid + '_Edit').length == 0) {
        var rel = width.replace('px', '') + "|" + height.replace('px', '') + "|" + toolbar + "|" + controlid + "|" + pagedataid;
        var createATag = "<a id='" + controlid + "_Edit' class='editstyle btnContentEditor' rel='" + rel + "'>" + textATag + " Text</a>";
        var dwidth = $("[id$='" + controlid + "']").css('width');
        $("[id$='" + controlid + "']").after("<div id='" + controlid + "_Editlink' class='divAddEdit' style='width:" + dwidth + ";'>" + createATag + "</div>");
    }
    else {
        var rel = width.replace('px', '') + "|" + height.replace('px', '') + "|" + toolbar + "|" + controlid + "|" + pagedataid;
        $('#' + controlid + '_Edit').attr('rel', rel);
    }
}

function CreateButtonForImage(pagedataid, controlid, Validation) {
    ImageWidth = Validation.Image.Width;
    ImageHeight = Validation.Image.Height;   
    
    var createATag = "<a href='#' id='" + controlid + "_Edit' class='editstyle imageButton' rel='" + pagedataid + "|" + ImageWidth + "|" + ImageHeight + "|" + controlid +"'>" + textATag + " Image</a>";
    if ($('#' + controlid + '_Edit').length > 0) {
        $('#' + controlid + '_Edit').prop('rel', pagedataid);
    }
    else {
        $("[id$=" + controlid + "]").before("<div id='" + controlid + '_Edit' + "' class='divAddEdit'>" + createATag + "</div>");
    }
}

function CreateButtonForVideo(pagedataid, controlid) {
    var url = app.utils.ResolveUrl("~/pages/mediaManage.aspx");
    var createATag = "<a href='" + url + "?mediatype=video&mediaReference=Page&mediaReferenceId=" + pageid + "' id='" + controlid + "_Edit' class='editstyle' rel='" + pagedataid + "'>" + textATag + " Video</a>";
    if ($('#' + controlid + '_Edit').length > 0) {
        $('#' + controlid + '_Edit').prop('rel', pagedataid);
    }
    else {
        $("[id$='" + controlid + "']").before("<div>" + createATag + "</div>");
    }

}

function ShowPublish() {
    if ($('[id$=publishPage]').length == 0) {
        var publishURL = app.utils.ResolveUrl("~/Ajax/pagePublish.aspx?menuid=" + $('[id$=hidden_currentmenuid]').val() + "&pageid=" + $('[id$=hidden_page]').val());
        $('.adminUser').find(':last-Child').after('<a href="' + publishURL + '" class="fancybox fancybox.ajax" id="publishPage">PUBLISH</a>');
    }
}

function SavePageImage(control, mediaid, imageSource) {
    
    var DTO = { 'pageDataID': mediaid, 'imageFileName': imageSource }

    $.ajax({
        type: "POST",
        url: app.utils.ResolveUrl("~/Manage/AjaxMediaManage.aspx/UpdatePageImage"),
        data: JSON.stringify(DTO),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (response) {
            var content = (typeof response.d) == 'string' ? eval('(' + response.d + ')') : response.d;

            $.each(content, function (index, domEle) {
                switch (this['ColumnName']) {
                    case "Action":
                        if (this['ColumnValue'] == 'success') {
                            $.msgGrowl({ type: 'success', title: 'Success', text: 'Image Updated Successfully' });
                        }
                        else {
                            $.msgGrowl({ type: 'error', title: 'Error', text: 'There was an error processing your request.' });
                        }
                        break;
                    case "Image":                        
                        if (this['ColumnValue'] != "") {                            
                            $("[id$='" + control + "']").prop('src', app.utils.ResolveUrl('~/media/images/content/' + this['ColumnValue']));
                        }
                        break;
                }
            });

        }
    });
}

function ReadyToCommunicate(text, pagedataid) {
    var PageDataDTO = {};    
    PageDataDTO.PageDataID  = pagedataid;
    PageDataDTO.Content     = text;

    var DTO = { 'PageDataDTO': PageDataDTO }

    $.ajax({
        type: 'POST',
        url: app.utils.ResolveUrl("~/innerpage.aspx/Ecouter"),
        data: JSON.stringify(DTO),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (response) {
            var content = (typeof response.d) == 'string' ? eval('(' + response.d + ')') : response.d;

            $.each(content, function (index, domEle) {
                switch (this['ColumnName']) {
                    case "Action":
                        if (this['ColumnValue'] == 'success') {
                            $.msgGrowl({ type: 'success', title: 'Success', text: 'Content Updated Successfully' });
                        }
                        else {
                            $.msgGrowl({ type: 'error', title: 'Error', text: 'There was an error processing your request.' });
                        }
                        break;
                    case "Image":
                        if (this['ColumnValue'] != "") {
                            $("[id$='" + control + "']").find('img').prop('src', ResolveUrl('~/media/images/' + this['ColumnValue']));
                        }
                        break;
                    default:

                }
            });
        },
        error: function (xhr, ajaxOptions, thrownError) {
            var err = eval("(" + xhr.responseText + ")");
            $.msgGrowl({ type: 'error', title: 'Error', text: 'There was an error processing your request.' });            
        }
    });
}

