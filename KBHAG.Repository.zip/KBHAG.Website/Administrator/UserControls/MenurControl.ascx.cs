﻿using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.UserControls
{
    public partial class MenurControl : System.Web.UI.UserControl
    {
        #region Declaration

        #endregion

        #region Method
        private void GetMenu()
        {
            using (KBHAGUnitOfWork uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<AdminMenu>();
                repo.UnitOfWork = uow;

                this.lvMenu.DataSource = repo.GetMany(i => i.ParentMenuID == 0 && i.Level == 0 && i.Active == "Y").OrderBy(o => o.Index);
                this.lvMenu.DataBind();
            }
        }

        protected void Menu_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            using (KBHAGUnitOfWork uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewAdminMenu>();
                repo.UnitOfWork = uow;

                HiddenField hiddenID        = (HiddenField)e.Item.FindControl("hiddenID");
                var listViewSubMenu         = (ListView)e.Item.FindControl("lvSubMenu");
                int tempLevelId             = Convert.ToInt32(hiddenID.Value);
                listViewSubMenu.DataSource  = repo.GetMany(i => i.ParentMenuID == tempLevelId && i.Level == 1 && i.Active == "Y").OrderBy(o => o.Index);
                listViewSubMenu.DataBind();
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetMenu();
            }
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}