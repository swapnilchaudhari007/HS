﻿using System;
using System.ComponentModel.DataAnnotations;

namespace KBHAG.Model
{
    public class Application
    {
        [Key]
        public int      AppID       { get; set; }
        public string   Name        { get; set; }
        public string   PageText    { get; set; }
        public string   MetaTitle   { get; set; }
        public string   MetaDesc    { get; set; }
        public string   MetaKeyWord { get; set; }
        public string   PinImage    { get; set; }
        public string   Url         { get; set; }
        public string   Active      { get; set; }
    }

    public class Layout
    {
        [Key]
        public int      LayoutID    { get; set; }
        public string   Name        { get; set; }
        public string   HtmlContent { get; set; }
        public string   Image       { get; set; }
        public string   Type        { get; set; }
        public string   Active      { get; set; }
    }

    public class CMSMenu
    {
        [Key]
        public int      MenuID      { get; set; }
        public int      AppID       { get; set; }
        public string   Title       { get; set; }
        public string   Allias      { get; set; }
        public int      ParentID    { get; set; }
        public int      Level       { get; set; }
        public int      Index       { get; set; }
        public string   Active      { get; set; } 
    }

    public class ViewMenu
    {
        [Key]
        public int      MenuID      { get; set; }
        public int      AppID       { get; set; }
        public string   AppName     { get; set; }
        public string   Title       { get; set; }
        public string   Allias      { get; set; }
        public int      ParentID    { get; set; }
        public int      Level       { get; set; }
        public int      Index       { get; set; }
        public string   Active      { get; set; }
        public string   ParentName  { get; set; }
        public string   ParentAllias{ get; set; }
        public string   ParentUrl   { get; set; }
    }

    public class PageStructure
    {
        [Key]
        public int      PageStructureID { get; set; }
        public string   ControlName     { get; set; }
        public string   Title           { get; set; }
        public string   RenderTag       { get; set; }
        public string   RenderID        { get; set; }
        public string   Validation      { get; set; }
        public string   DefaultContent  { get; set; }
        public string   Active          { get; set; }
    }

    public class CMSPage 
    {
        [Key]
        public int      PageID      { get; set; }
        public int      LayoutID    { get; set; }
        public int      MenuID      { get; set; }
        public string   Title       { get; set; }
        public string   MetaTitle   { get; set; }
        public string   MetaDesc    { get; set; }
        public string   MetaKeyWord { get; set; }
        public string   JavaScript  { get; set; }
    }

    public class ViewPage
    {
        [Key]
        public int      PageID      { get; set; }
        public int      LayoutID    { get; set; }
        public int      MenuID      { get; set; }
        public string   Title       { get; set; }
        public string   MetaTitle   { get; set; }
        public string   MetaDesc    { get; set; }
        public string   MetaKeyWord { get; set; }
        public string   Layout      { get; set; }
        public string   Menu        { get; set; }
    }

    public class PageData
    {
        [Key]
        public int      PageDataID      { get; set; }
        public int      PageID          { get; set; }
        public int      PageStructureID { get; set; }
        public string   Content         { get; set; }
    }

    public class ViewPageData
    {         
        [Key]
        public int PageDataID       { get; set; }
        public int PageID           { get; set; }
        public int PageStructureID  { get; set; }
        public string Content       { get; set; }
        public string PageTitle     { get; set; }
        public string Structure     { get; set; }
        public string ControlName   { get; set; }
        public string RenderTag     { get; set; }
        public string RenderID      { get; set; }
        public string Validation    { get; set; }
        public string DefaultContent{ get; set; }
        public string Active        { get; set; }
    }

    public class PagePublish
    {
        [Key]
        public int ID               { get; set; }
        public int MenuID           { get; set; }
        public int PageID           { get; set; }        
    }

    public class ViewPagePublish
    {
        [Key]
        public int      ID          { get; set; }
        public int      MenuID      { get; set; }
        public int      PageID      { get; set; }      
        public string   Menu        { get; set; }
        public string   Page        { get; set; }
    }

    public class HomePage
    {
        [Key]
        public int      ID          { get; set; }
        public string   Key         { get; set; }
        public string   Value       { get; set; }
        public string   Type        { get; set; }
    }

    public class MapLayoutStructure
    {
        [Key]
        public int ID               { get; set; }
        public int LayoutID         { get; set; }
        public int PageStructureID  { get; set; }
        public string Active        { get; set; }
    }

    public class ViewMapLayoutStructure
    {
        [Key]
        public int ID               { get; set; }
        public int LayoutID         { get; set; }
        public int PageStructureID  { get; set; }
        public string Active        { get; set; }
        public string Name          { get; set; }
        public string Title         { get; set; }
        public string RenderTag     { get; set; }
        public string RenderID      { get; set; }
        public string DefaultContent { get; set; }
    }
}
