﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KBHAG.Model;
using KBHAG.Data;
using System.Data.Objects;

namespace KBHAG.Repository
{
    public class ApplicationRepository:IApplicationRepository
    {
        #region Event 
       
        public List<ViewEvent> GetEventPagination(int startrows, int pagesize, string type, string tense)
        {
            List<ViewEvent> dset = new List<ViewEvent>();
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewEvent>();
                repo.UnitOfWork = uow;
                if (type.ToLower() == "all")
                {
                    if (tense == RepositoryConstants.EVENT_FEATURED)
                    {
                        int dcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                        if (dcount > 0)
                            tense = RepositoryConstants.EVENT_UPCOMING;
                        else
                            tense = RepositoryConstants.EVENT_PAST;
                    }

                    switch (tense)
                    {
                        case RepositoryConstants.EVENT_PAST:
                            dset = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today)
                                            .OrderByDescending(o => o.StartDate)
                                            .Skip(startrows)
                                            .Take(pagesize)
                                            .ToList();
                            break;
                        case RepositoryConstants.EVENT_UPCOMING:
                            dset = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today)
                                            .OrderBy(o => o.StartDate)
                                            .Skip(startrows)
                                            .Take(pagesize)
                                            .ToList();
                            break;
                    }
                }
                else
                {
                    if (tense == RepositoryConstants.EVENT_FEATURED)
                    {
                        int dcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                        if (dcount > 0)
                            tense = RepositoryConstants.EVENT_UPCOMING;
                        else
                            tense = RepositoryConstants.EVENT_PAST;
                    }

                    switch (tense)
                    {
                        case RepositoryConstants.EVENT_PAST:
                            dset = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today)
                                            .OrderByDescending(o => o.StartDate)
                                            .Skip(startrows)
                                            .Take(pagesize)
                                            .ToList();
                            break;
                        case RepositoryConstants.EVENT_UPCOMING:
                            dset = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today)
                                            .OrderBy(o => o.StartDate)
                                            .Skip(startrows)
                                            .Take(pagesize)
                                            .ToList();
                            break;
                    }
                }
            }
            return dset;
        }
        
        public int GetEventCount(string type, string tense)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewEvent>();
                repo.UnitOfWork = uow;
                int rcount = 0;
                if (type.ToLower() == "all")
                {
                    switch (tense)
                    {
                        case RepositoryConstants.EVENT_FEATURED:
                            rcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                            if (rcount == 0)
                                rcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today).Count();
                            break;
                        case RepositoryConstants.EVENT_PAST:
                            rcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today).Count();
                            break;
                        case RepositoryConstants.EVENT_UPCOMING:
                            rcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                            break;
                    }
                }
                else
                {
                    switch (tense)
                    {
                        case RepositoryConstants.EVENT_FEATURED:
                            rcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                            if (rcount == 0)
                                rcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today).Count();
                            break;
                        case RepositoryConstants.EVENT_PAST:
                            rcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) < DateTime.Today).Count();
                            break;
                        case RepositoryConstants.EVENT_UPCOMING:
                            rcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                            break;
                    }
                }
                return rcount;
            }
        }

        public string GetEventFinalTense(string type)
        {
            string ret = RepositoryConstants.EVENT_PAST;
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewEvent>();
                repo.UnitOfWork = uow;
                int dcount = 0;
                if (type.ToLower() == "all")
                    dcount = repo.GetMany(i => i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();
                else
                    dcount = repo.GetMany(i => i.EventTypeAlias == type && i.Active == "Y" && EntityFunctions.TruncateTime(i.EndDate) >= DateTime.Today).Count();

                if (dcount > 0)
                    ret = RepositoryConstants.EVENT_UPCOMING;
                else
                    ret = RepositoryConstants.EVENT_PAST;

            }

            return ret;
        }

        public string GetEventNameByAlias(string etype)
        {
            string ret = "";
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<EventType>();
                repo.UnitOfWork = uow;
                var data = repo.Get(i => i.EventTypeAlias == etype);
                if (data != null)
                    ret = data.EventTypeName;
            }
            return ret;
        }
        
        public ViewEvent GetEventByID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewEvent>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }

        public ViewFeatured GetFeaturedEventByAlias(string alias)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewFeatured>();
                repo.UnitOfWork = uow;
                return repo.Get(i=> i.EventTypeAlias == alias);
            }
        }

        public List<ViewEvent> GetEventForCalendarControl(int takeRows)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewEvent>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y")
                                .OrderByDescending(o => o.StartDate)                                
                                .Take(takeRows)
                                .ToList();
            }  
        }

        public int GetEventSlideShowId(int id)
        {
            int ret = 0;
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                var slides = repo.Get(i=> i.TargetID == id && i.Target == RepositoryConstants.SLIDESHOW_TARGET_EVENT && i.Active=="Y");
                if (slides != null)
                    ret = slides.ID;
            }
            return ret;
        }


        public SlideShowMedia GetSlideShowMediaById(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.MediaID == id && i.Active == "Y");
            }
        }
        #endregion

        #region Press 
       
        public List<Press> GetPressPagination(int startrows, int pagesize)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Press>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y")
                                .OrderBy(o => o.PressDate)
                                .Skip(startrows)
                                .Take(pagesize)
                                .ToList();
            }  
        }

        public int GetPressCount()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Press>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y").Count();
            }
        }

        #endregion

        #region SlideShow

        public SlideShow GetSlideShowByID(int ID)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                return repo.GetById(ID);
            }
        }

        public SlideShow GetSlideShowByTargetAndTargetID(string target, int targetid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.Target == target && i.TargetID == targetid);
            }
        }

        public int AddSlideShow(SlideShow AlbumDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                repo.Add(AlbumDTO);
                uow.Commit();
                return AlbumDTO.ID;
            }
        }

        public int UpdateSlideShow(SlideShow AlbumDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(AlbumDTO.ID);

                if (data != null)
                {
                    data.Title          = AlbumDTO.Title;
                    data.Desc           = AlbumDTO.Desc;
                    data.ThumbImage     = AlbumDTO.ThumbImage;
                    data.MetaTitle      = AlbumDTO.MetaTitle;
                    data.MetaDesc       = AlbumDTO.MetaDesc;
                    data.MetaKeyWord    = AlbumDTO.MetaKeyWord;
                    data.Index          = AlbumDTO.Index;
                    data.ShowInGallery  = AlbumDTO.ShowInGallery;
                    data.Active         = AlbumDTO.Active;
                }
                repo.Update(data);
                uow.Commit();
                return AlbumDTO.ID;
            }
        }        

        public int AddMedia(SlideShowMedia ImageMediaDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;
                repo.Add(ImageMediaDTO);
                uow.Commit();
                return ImageMediaDTO.MediaID;
            }
        }

        public int UpdateMedia(SlideShowMedia ImageMediaDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(ImageMediaDTO.MediaID);

                if (data != null)
                {
                    data.Caption = ImageMediaDTO.Caption;
                    data.FileName = ImageMediaDTO.FileName;
                    data.Index = ImageMediaDTO.Index;                    
                }
                repo.Update(data);
                uow.Commit();
                return ImageMediaDTO.MediaID;
            }
        }

        public void DeleteMedia(int ID)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;
                var data = repo.GetById(ID);
                repo.Delete(data);
                uow.Commit();                
            }
        }

        public void UpdateCaption(int ID, string Caption)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(ID);

                if (data != null)
                {
                    data.Caption = Caption;                    
                }
                repo.Update(data);
                uow.Commit();                
            }
        }

        public void UpdateURL(int ID, string URL)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(ID);

                if (data != null)
                {
                    data.URL = URL;
                }
                repo.Update(data);
                uow.Commit();
            }
        }

        public void UpdateIndex(int ID, int Index)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(ID);

                if (data != null)
                {  
                    data.Index = Index;
                }
                repo.Update(data);
                uow.Commit();                
            }
        }

        public List<SlideShowMedia> GetMediaByAlbumID(int ID)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.SlideShowID == ID).ToList();
            }
        }

        public List<SlideShowMedia> GetMediaByAlbumTitle(string title)
        {            
            using (var uow = new KBHAGUnitOfWork())
            {
                var repoSlideShow = new GenericRepository<SlideShow>();
                repoSlideShow.UnitOfWork = uow;
                int ID = repoSlideShow.Get(i => i.Title == title).ID;

                var repo = new GenericRepository<SlideShowMedia>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.SlideShowID == ID).ToList();
            }
        }

        public List<SlideShow> GetSlideShowPagination(int startrows, int pagesize)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y" && i.ShowInGallery == "Y")
                                .OrderBy(o => o.Index)
                                .Skip(startrows)
                                .Take(pagesize)
                                .ToList();
            }  
        }

        public int GetSlideShowCount()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y" && i.ShowInGallery == "Y").Count();
            }
        }

        #endregion        
    
        #region Video
        public List<Video> GetVideoPagination(int startrows, int pagesize)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Video>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y")
                                .OrderBy(o => o.Index)
                                .Skip(startrows)
                                .Take(pagesize)
                                .ToList();
            }  
        }

        public int GetVideoCount()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Video>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y").Count();
            }
        }

        public Video GetVideoByID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Video>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }
        #endregion
        
        #region Inquiry
        public void AddInquiry(Inquiry InquiryDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Inquiry>();
                repo.UnitOfWork = uow;
                repo.Add(InquiryDTO);
                uow.Commit();                
            }
        }

        public Inquiry GetInquiryById(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Inquiry>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }

        public int GetLastestInquiryID()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Inquiry>();
                repo.UnitOfWork = uow;
                return repo.GetAll().OrderByDescending(o => o.ID).FirstOrDefault().ID;
            }
        }

        #endregion        
    
        #region Testimonial
        public List<Testimonial> GetTestimonialPagination(int startrows, int pagesize)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Testimonial>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y")
                                .OrderBy(o => o.Index)
                                .Skip(startrows)
                                .Take(pagesize)
                                .ToList();
            }  
        }

        public int GetTestimonialCount()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Testimonial>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y").Count();
            }
        }
        #endregion

        #region Application
        public Application GetApplicationByName(string name)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<Application>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.Name == name);
            }
        }
        #endregion

        #region News
        public List<News> GetNewsPagination(int startrows, int pagesize)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<News>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y")
                                .OrderBy(o => o.Index)
                                .Skip(startrows)
                                .Take(pagesize)
                                .ToList();
            }  
        }

        public int GetNewsCount()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<News>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y").Count();
            }
        }

        public News GetNewsByID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<News>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }
        #endregion
    }
}
