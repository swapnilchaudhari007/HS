﻿using KBHAG.Components;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class Testimonial : System.Web.UI.Page
    {
        #region Declaration
            bool isAuthorized = false;
        #endregion

        #region Method
        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                isAuthorized = true;
                this.AddTestimonial.Visible = true;
                this.AddTestimonial.NavigateUrl = Page.ResolveUrl("~/administrator/index.aspx?action=a&section=applications&page=testimonial");
            }
        }

        public string ShowEditButton(string id)
        {
            string strReturn = "";
            if (isAuthorized)
            {
                strReturn = "<div class='divAddEdit'>";
                strReturn += "<a href='" + Page.ResolveUrl("~/administrator/index.aspx") + "?action=e&section=applications&page=testimonial&id=" + id + "' target='_blank' class='submit'>Edit</a>";
                strReturn += "</div>";
            }
            return strReturn;
        }

        public string ShowImage(string image, string name)
        {
            string ret = string.Empty;
            if (!string.IsNullOrEmpty(image))
                ret = "<img src='" + Page.ResolveUrl("~/Media/Images/content/" + image) + "' alt='" + name + "' />";
            else
                ret = "<img src='" + Page.ResolveUrl("~/Media/Images/content/default_testimonial.jpg") + "' alt='" + name + "' />";
            return ret;
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var repo = new ApplicationRepository();
                WebsiteHelpers.GenerateMetaTags(repo.GetApplicationByName(Constants.APP_TESTIMONIAL), this.MetaPlaceHolder);

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_TESTIMONIAL);

                Authorized();
            }            
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}