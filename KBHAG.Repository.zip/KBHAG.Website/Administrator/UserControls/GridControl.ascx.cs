﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.UserControls
{
    public partial class GridControl : System.Web.UI.UserControl
    {

        /*            
            {
	            "Model"         :"User",
	            "PKID"          :"UserId",
	            "ColumnName"    :"[''UserId'', ''DisplayName'', ''Email'', ''Active'']",
	            "ColumnHeading" :"[''Id'', ''Display Name'', ''Email'', ''Active'']",
	            "ColumnModel"   :"[ 
                                   { name: 'UserId',      index: ''UserId'',      searchoptions: { sopt: [''eq'', ''ne'', ''lt'', ''le'', ''gt'', ''ge'']}}, 
                                   { name: 'DisplayName', index: ''DisplayName'', searchoptions: { sopt: [''cn'', ''eq'', ''ne'']}}, 
                                   { name: 'Email',       index: ''Email'',       searchoptions: { sopt: [''cn'', ''eq'', ''ne'']}}, 
                                   { name: 'Active',      index: ''Active'',      searchoptions: { sopt: [''eq'', ''ne'']}} 
                                 ]",
                "JoinTableQuery" : "INNER JOIN AdminPages AS a ON a.PageID = it.PageID"     
            }
         
         *************************** IMPORTANT THING TO REMEMBER ***************************
         *If JoinTableQuery is applicable make sure 
         *  (a.) ColumnName should have allias for example:
         *           "ColumnName":"['it.StructureID','a.Title', 'it.StructureControl', 'it.StructureName','it.Index', 'it.Active']"
         * 
         *  (b.) In "JoinTableQuery" INNER JOIN table name should be pluralize for example:
         *           if table name is AdminPage add 's' at the end of the name final name should be AdminPages
         *  
         *************************** IMPORTANT THING TO REMEMBER ***************************
         
        */


        #region Declaration
            public static string GridHeading        { get; set; }
            public static string GridModel          { get; set; }
            public static string GridPKID           { get; set; }
            public static string GridColumnName     { get; set; }
            public static string GridColumnHeading  { get; set; }
            public static string GridColumnModel    { get; set; }
            public static string GridJoinQuery      { get; set; }
            public static string GridRedirectURL    { get; set; }

            
        #endregion

        #region Method

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {            
        }

        #endregion

        #region WebMethod

        #endregion
                
    }
}