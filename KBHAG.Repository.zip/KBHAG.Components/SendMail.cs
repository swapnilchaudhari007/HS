﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;

namespace KBHAG.Components
{
    public class SendMail
    {        
        public string SenderName    { get; set; }
        public string SenderEmail   { get; set; }
        public string ToName        { get; set; }
        public string ToEmail       { get; set; }
        public string CCEmail       { get; set; }             

        public string MailSubject { get; set; }
        public string MailBody { get; set; }

        List<MailAddress> recipients = new List<MailAddress>();
                
        public void MailSend()
        {           
                MailMessage mailMessage = new MailMessage();
                
                mailMessage.From = new MailAddress(SenderEmail, SenderName);

                foreach (MailAddress item in recipients)
                {
                    mailMessage.To.Add(item);
                }

                if (!String.IsNullOrEmpty(CCEmail))
                {
                    MailAddress cc = new MailAddress(CCEmail);
                    mailMessage.CC.Add(cc);
                }

                mailMessage.IsBodyHtml  = true;
                mailMessage.Subject     = MailSubject;
                mailMessage.Body        = MailBody;

                SmtpClient emailClient = new SmtpClient("smtp.kamalnayanbajajartgallery.com");
                System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential("webmaster@kamalnayanbajajartgallery.com", "kbhag@123");
                //emailClient.UseDefaultCredentials = true;
                emailClient.Credentials = SMTPUserInfo;
                emailClient.Send(mailMessage);
            
        }

        public string InquiryThanksMail()
        {
            try
            {
                SenderEmail = "webmaster@kamalnayanbajajartgallery.com";
                SenderName  = "Webmaster";

                MailBody = System.IO.File.ReadAllText(HttpContext.Current.Server.MapPath("~/Media/Text/inquiry-thanks.txt"));

                MailBody = MailBody.Replace("#contact#", ToName);

                recipients.Add(new MailAddress(ToEmail,ToName));

                //MailSubject = "Thank you for your enquiry";
                MailSubject = "Thank you, Kamalnayan Bajaj Hall & Art Gallery";

                MailSend();

                return "success";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        public string InquiryAdminMail(Dictionary<string,string> enquiryFormData, string inquiryType)
        {
            try
            {

                SenderEmail = "webmaster@kamalnayanbajajartgallery.com";
                SenderName  = "Webmaster";

                ToEmail     = "inquiry@kamalnayanbajajartgallery.com";
                ToName      = "Webmaster";

                MailBody = System.IO.File.ReadAllText(HttpContext.Current.Server.MapPath("~/Media/Text/inquiry-admin.txt"));               
                recipients.Add(new MailAddress(ToEmail, ToName));

                foreach (var item in enquiryFormData)
                {
                    MailBody = MailBody.Replace(item.Key, item.Value);    
                }                
                
                MailSubject = "Inquiry for " + inquiryType;

                MailSend();

                return "success";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

    }
}
