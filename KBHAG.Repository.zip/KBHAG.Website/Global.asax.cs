﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace KBHAG.Website
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes(RouteTable.Routes);
        }

        private void RegisterRoutes(RouteCollection routes)
        {
            routes.Ignore("{*allaspx}", new { allaspx = @".*\.aspx(/.*)?" });

            routes.Ignore("{resource}.axd/{*pathInfo}");
            routes.Ignore("{*allcss}", new { allcss = @".*\.css(/.*)?" });
            routes.Ignore("{*alljpg}", new { alljpg = @".*\.jpg(/.*)?" });
            routes.Ignore("{*allpng}", new { allpng = @".*\.png(/.*)?" });
            routes.Ignore("{*allpdf}", new { allpdf = @".*\.pdf(/.*)?" });
            routes.Ignore("{*alldoc}", new { alldoc = @".*\.doc(/.*)?" });
            routes.Ignore("{*alljs}",  new { alljs = @".*\.js(/.*)?"   });

            //Register a route for Inquiry Form
            routes.MapPageRoute(
                "form",
                "form/{type}",
                "~/Pages/form.aspx"
            );

            //Register a route for All Listing of Events
            routes.MapPageRoute(
                "Press-All",
                "press/all",
                "~/Pages/Press-All.aspx"
            );

            //Register a route for All Listing of Events
            routes.MapPageRoute(
                "Testimonial",
                "about-us/testimonial",
                "~/Pages/Testimonial.aspx"
            );

            //Register a route for All Listing of News
            routes.MapPageRoute(
                "News-All",
                "updates/news",
                "~/Pages/NewsListing.aspx"
            );

            //Register a route for Single News Listing
            routes.MapPageRoute(
                "News-Single",                            //Route Name
                "updates/news/{id}/{allias}",             //Route URL
                "~/pages/News.aspx"                       //Web page to handle route
            );

            //Register a route for All Listing of Events
            routes.MapPageRoute(
                "Event-All",
                "events/{type}/{tense}",
                "~/Pages/Event-All.aspx"
            );

            //Register a route for Single Event Listing
            routes.MapPageRoute(
                "Events-Single",                            //Route Name
                "events/{type}/{id}/{allias}",                     //Route URL
                "~/pages/Events.aspx"                       //Web page to handle route
            );

            //Register a route for All Images Gallery
            routes.MapPageRoute(
                "Album-All",                                //Route Name
                "gallery/albums/all",                       //Route URL
                "~/Pages/AlbumListing.aspx"                 //Web page to handle route
            );

            //Register a route for Single Album
            routes.MapPageRoute(
                "Album-Single",                             //Route Name
                "gallery/albums/{id}/{title}",              //Route URL
                "~/Pages/AlbumView.aspx"                    //Web page to handle route
            );

            //Register a route for All Video Gallery
            routes.MapPageRoute(
                "Video-All",                                //Route Name
                "gallery/video/all",                       //Route URL
                "~/Pages/VideoListing.aspx"                 //Web page to handle route
            );

            //Register a route for Single Video
            routes.MapPageRoute(
                "Video-Single",                            //Route Name
                "gallery/video/{id}/{title}",              //Route URL
                "~/Pages/VideoView.aspx"                   //Web page to handle route
            );

            //Register a route for Single Level Page
            routes.MapPageRoute(
                "CMS-Zero-Level",                           //Route Name
                "{level0}",                                 //Route URL
                "~/innerpage.aspx"                          //Web page to handle route
            );

            //Register a route for Single Level Page
            routes.MapPageRoute(
                "CMS-One-Level",                    //Route Name
                "{level0}/{level1}",                  //Route URL
                "~/innerpage.aspx",                  //Web page to handle route
                false,
                new RouteValueDictionary { { "parent", string.Empty } }
            );

            //Register a route for Two Level Page
            routes.MapPageRoute(
                "CMS-Two-Level",                    //Route Name
                "{level0}/{level1}/{level2}",         //Route URL
                "~/innerpage.aspx",                  //Web page to handle route
                false,
                new RouteValueDictionary { { "menu", string.Empty } }
            );         
        }
        
    }
}