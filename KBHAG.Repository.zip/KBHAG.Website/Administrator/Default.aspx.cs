﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;

namespace KBHAG.Website.Administrator
{
    public partial class Default : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CookieHandler.VerifyAdminUser())
                {
                    Response.Redirect(Constants.ADMIN_DEFAULT_PAGE + "?section=content-management&page=menu&action=v");
                }
            }
        }

        protected void Login_ClickHandler(object sender, EventArgs e)
        {
            using (KBHAGUnitOfWork uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<User>();
                repo.UnitOfWork = uow;
                var user = repo.Get(i => i.UserName == this.username.Value.Trim() && i.Password == this.password.Value.Trim() && i.Active == "Y");

                if (user != null)
                {
                    CookieHandler.CreateAdminCookie(CookieHandler.CreateAdminUser(user), Field.Checked);
                    this.errorholder.Visible = false;
                    Response.Redirect(Constants.ADMIN_DEFAULT_PAGE + "?section=content-management&page=menu&action=v");
                }
                else
                {
                    this.errorholder.Visible = true;
                }
            }
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}