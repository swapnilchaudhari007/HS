﻿using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.UserControls
{
    public partial class ResponseMessageControl : System.Web.UI.UserControl, IResponseMessage
    {
        public Constants.MESSAGE_TYPE MessageType { get; set; }

        public string Message { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            string cssClass = string.Empty;

            switch (MessageType)
            {
                case Constants.MESSAGE_TYPE.block:
                    this.lblMessageHeading.Text = "Alert";                    
                    break;
                
                case Constants.MESSAGE_TYPE.error:
                    this.lblMessageHeading.Text = "Error";                    
                    break;

                case Constants.MESSAGE_TYPE.success:
                    this.lblMessageHeading.Text = "Success";
                    break;                

                case Constants.MESSAGE_TYPE.info:
                    this.lblMessageHeading.Text = "Information";                    
                    break;               
            }

            this.lblMessage.Text = Message;
            this.MessageHolder.Attributes.Add("class", "alert alert-" + MessageType);
        }
    }
}