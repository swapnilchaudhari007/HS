﻿using System.ComponentModel.DataAnnotations;

namespace KBHAG.Model
{
    public class AdminMenu
    {
        [Key]
        public int  MenuID          { get; set; }
        public int  ParentMenuID    { get; set; }

        public int PageID           { get; set; }
        public FormPage Page        { get; set; }

        public string Name          { get; set; }
        public string Url           { get; set; }
        public int Level            { get; set; }
        public int Index            { get; set; }
        public string Active        { get; set; }
    }

    public class FormPage
    {
        [Key]
        public int PageID           { get; set; }
        public string Title         { get; set; }
        public string Desc          { get; set; }
        public string Grid          { get; set; }
        public string Callback      { get; set; }
        public string Model         { get; set; }
        public string Active        { get; set; }
    }

    public class FormStructure
    {
        [Key]
        public int StructureID          { get; set; }

        public int PageID               { get; set; }
        public FormPage AdminPage       { get; set; }
        
        public string StructureControl  { get; set; }
        public string StructureName     { get; set; }
        public string RenderID          { get; set; }
        public string EntityFieldName   { get; set; }
        public string StyleName         { get; set; }
        public string Mandatory         { get; set; }
        public int MaxLength            { get; set; }
        public string Callback          { get; set; }
        public string Tooltip           { get; set; }
        public int Index                { get; set; }
        public string Active            { get; set; }
    }

    public class User
    {
        [Key]
        public int      Id              { get; set; }
        public string   UserName        { get; set; }
        public string   Password        { get; set; }
        public string   Active          { get; set; }
    }

    public class ViewAdminMenu
    { 
        [Key]
        public int      MenuID          { get; set; }
        public int      ParentMenuID    { get; set; }
        public int      PageID          { get; set; }
        public FormPage Page            { get; set; }
        public string   Name            { get; set; }
        public string   Url             { get; set; }
        public int      Level           { get; set; }
        public int      Index           { get; set; }
        public string   Active          { get; set; }
        public string   Section         { get; set; }
    }
}
