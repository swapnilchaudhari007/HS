﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Manage
{
    public partial class CropImageControl : System.Web.UI.UserControl
    {
        #region Declaration

            public string INTGLOBALWIDTH    { get; set; }
            public string INTGLOBALHEIGHT   { get; set; }
            public string INTFRAMEWIDTH     { get; set; }
            public string INTFRAMEHEIGHT    { get; set; }
            public string AjaxAspxPath      { get; set; }
            public string TempFolderPath    { get; set; }
            public string ActualImgPath     { get; set; }
            public string ProcessAshxPath   { get; set; }
            public string ValidateFunction  { get; set; }
            public string ImageCompression  { get; set; }
            public string ImageResult       { get; set; }
            public Boolean ForceMinSize     { get; set; }

            enum compressionRatios { maximum = 100, high = 80, medium = 65, low = 50 };

        #endregion

        #region Method
            public static void GetListItemsFromEnum(DropDownList ddl, Type enumType)
            {
                string[] names = Enum.GetNames(enumType);
                int[] values = Enum.GetValues(enumType).Cast<int>().ToArray();

                for (int i = 0; i <= names.Length - 1; i++)
                {
                    ddl.Items.Insert(i, names[i]);
                    ddl.Items[i].Value = values[i].ToString();
                }
            }

            public string GetCroppedImage()
            {
                if (hdnHasFile.Value == "0")
                    return "";

                string oldfile = Path.GetFileName(hdnOriginalImg.Value);
                string newfile = Path.GetFileName(hdnNewFile.Value);

                if (string.IsNullOrEmpty(newfile))
                    return Path.GetFileName(oldfile);

                if (newfile != oldfile)
                    return hdnNewFile.Value;
                else
                    return oldfile;
            }

            public string GetOldImage()
            {
                string oldfile = hdnOriginalImg.Value;
                return Path.GetFileName(oldfile);
            }

            public Boolean CroppedImageIsNew()
            {
                if (hdnHasFile.Value == "0")
                    return false;

                string oldfile = Path.GetFileName(hdnOriginalImg.Value);
                string newfile = Path.GetFileName(hdnNewFile.Value);

                if (string.IsNullOrEmpty(newfile))
                    return false;

                if (newfile != oldfile)
                    return true;
                else
                    return false;
            }

            public void Reset()
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "resetCropImage();");
            }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.lblDimension.Text = "(" + INTGLOBALWIDTH + " W x " + INTGLOBALHEIGHT + " H) pixels";
                GetListItemsFromEnum(this.ddlRatio, typeof(compressionRatios));
                this.ddlRatio.SelectedValue = compressionRatios.medium.GetHashCode().ToString();
                if (string.IsNullOrEmpty(ImageResult))
                {
                    this.resultImg.Src = ImageResult;
                    hdnOriginalImg.Value = Path.GetFileName(ImageResult);
                    hdnHasFile.Value = "1";
                }
            }
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}