﻿using CKEditor.NET;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Components
{
    public class DynamicForm
    {   
        Page page = HttpContext.Current.Handler as Page;        

        public Panel FormHolder    { get; set; }
        public HtmlGenericControl ControlHolder { get; set; }
        public Button SubmitButton { get; set; }
        public HiddenField HiddenCallBackFunction { get; set; }

        public FormDTO FormDTO { get; set; }
        public string ControlUniqueID { get; set; }

        public string CallbackString = string.Empty;

        public DynamicForm()
        {
            
        }

        public void CreateForm()
        {            
            if (FormHolder == null)
            {
                ShowResponseMessage(Constants.MESSAGE_TYPE.error, "Form Holder Control not found.");
                return;
            }

            KBHAGUnitOfWork uow = new KBHAGUnitOfWork();

            var repo = new GenericRepository<FormPage>();
            repo.UnitOfWork = uow;
            var pageDTO = repo.GetById(FormDTO.PageID);

            if (pageDTO == null)
            {
                FormHolder.Visible = false;
                ShowResponseMessage(Constants.MESSAGE_TYPE.error, "Page does not exists!");
                return;
            }

            FormDTO.Model   = pageDTO.Model;
            CallbackString  = pageDTO.Callback;

            if (HiddenCallBackFunction != null)
                HiddenCallBackFunction.Value = pageDTO.Callback;


            var repoAdminStructure = new GenericRepository<FormStructure>();
            repoAdminStructure.UnitOfWork = uow;
            var pageStructure = repoAdminStructure.GetMany(i => i.PageID == pageDTO.PageID && i.Active == "Y").OrderBy(o => o.Index);

            RenderControl(pageStructure.ToList());

        }

        public void RenderControl(List<FormStructure> pageStructure)
        {
            StringBuilder sbjQueryCode = new StringBuilder();
            JObject validationRules = new JObject();

            List<RowCollection> rows = new List<RowCollection>();
            if (FormDTO.Action == "e")
            {
                rows = DynamicHelpers.GetRowCollectionList(FormDTO.Model, FormDTO.ReferenceID);
            }


            foreach (var item in pageStructure)
            {
                string text = string.Empty;

                if (FormDTO.Action == "e")
                    text = Util.Parse<string>(rows.FirstOrDefault(i => i.ColumnName == item.EntityFieldName).ColumnValue);

                HtmlGenericControl parentDiv = new HtmlGenericControl();
                parentDiv.TagName = "div";
                parentDiv.Attributes.Add("class", "control-group");
                 
                parentDiv.Controls.Add(GetHtmlGenericControl("", "control-label", "label",item.StructureName,item.RenderID));

                if (item.Mandatory == "Y")
                    parentDiv.Controls.Add(CreateControls.GetHtmlGenericControl("", "span-required", "span", "*", ""));

                HtmlGenericControl HtmlLabel = new HtmlGenericControl();

                if (!IsControlApplicable(item.Callback))
                    continue;

                switch (item.StructureControl)
                {
                    case "Textbox":

                        if (item.Callback.ToLower().Contains("datefield"))
                        {
                            text = (!String.IsNullOrEmpty(text)) ? String.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(text)) : string.Empty;
                        }

                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        TextBox txt = GetTextBox(item.RenderID, item.StyleName, int.Parse(item.MaxLength.ToString()), text, item.Tooltip);
                        HtmlLabel.Controls.Add(txt);
                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "Textarea":
                        
                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        HtmlLabel.Controls.Add(GetTextArea(item.RenderID, item.StyleName, text, item.Tooltip));
                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "Checkbox":
                        
                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        HtmlLabel.Controls.Add(GetCheckBox(item.RenderID, text, item.StyleName, item.Tooltip));
                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "DropdownList":
                        
                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        HtmlLabel.Controls.Add(GetDropdownList(item.RenderID, "", item.Callback, text, item.Tooltip));
                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "HtmlEditor":

                        string toolbar = string.Empty;
                        if (!String.IsNullOrEmpty(item.Callback))
                        {
                            JObject jsonObject = JObject.Parse(item.Callback);

                            toolbar = (string)jsonObject["Editor"]["toolbar"];
                        }
                        
                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        HtmlLabel.Controls.Add(GetHTMLTextEditor(item.RenderID, item.StyleName, text, toolbar));
                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "ImageUpload":

                        string ImageFolderName = Constants.IMAGE_FOLDER_PATH;

                        JObject jsonImageObject = JObject.Parse(item.Callback);
                        if (jsonImageObject["Callback"]["ImageUpload"]["Folder"] != null)
                            ImageFolderName = (string)jsonImageObject["Callback"]["ImageUpload"]["Folder"];

                        string width = (string)jsonImageObject["Callback"]["ImageUpload"]["ImageWidth"];
                        string height = (string)jsonImageObject["Callback"]["ImageUpload"]["ImageHeight"];

                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");                        
                        HtmlGenericControl HtmlSubControl = GetHtmlGenericControl("", "", "p", "", "");
                        HtmlSubControl.Controls.Add(GetImageControl(item.RenderID, page.ResolveUrl("~/" + ImageFolderName + text)));
                        HtmlLabel.Controls.Add(HtmlSubControl);

                        HtmlGenericControl HtmlControl = GetHtmlGenericControl("", "", "p", "", "");
                        HtmlControl.Controls.Add(GetHtmlAnchor(String.Concat("btn_", item.RenderID), "btn btn-tertiary", "#", "Upload Image", ""));
                        HtmlControl.Controls.Add(GetHtmlGenericControl("", "", "p", "(" + width + " W x " + height + " H pixels)", ""));
                        HtmlControl.Controls.Add(CreateHiddenField(String.Concat("hidden_", item.RenderID), text));
                        HtmlLabel.Controls.Add(HtmlControl);

                        parentDiv.Controls.Add(HtmlLabel);

                        break;

                    case "FileUpload":
                        
                        HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                        HtmlLabel.Controls.Add(GetFileUpload(item.RenderID, string.Empty));
                        parentDiv.Controls.Add(HtmlLabel);

                        JObject jsonObjectFile = JObject.Parse(item.Callback);
                        string filetype = (string)jsonObjectFile["FileUpload"]["FileType"];

                        if (text != string.Empty)
                        {
                            string fileName = string.Empty;
                            fileName = text;

                            if (filetype == "file")
                            {
                                HtmlAnchor Anchor = new HtmlAnchor();
                                Anchor = GetHtmlAnchor("", "", page.ResolveUrl("~/" + Constants.FILE_FOLDER_PATH + fileName), fileName, "_blank");

                                HtmlLabel = GetHtmlGenericControl("", "control-label", "label", "", "");
                                parentDiv.Controls.Add(HtmlLabel);
                                HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                                HtmlLabel.Controls.Add(Anchor);
                                parentDiv.Controls.Add(HtmlLabel);
                            }
                            else
                            {
                                HtmlImage Image = new HtmlImage();
                                Image = GetHtmlImage("", "", page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH + fileName), 150, 150);

                                HtmlLabel = GetHtmlGenericControl("", "control-label", "label", "", "");
                                parentDiv.Controls.Add(HtmlLabel);
                                HtmlLabel = GetHtmlGenericControl("", "controls", "div", "", "");
                                HtmlLabel.Controls.Add(Image);
                                parentDiv.Controls.Add(HtmlLabel);
                            }

                            Label FileID = new Label();
                            FileID = GetLabel("label_" + item.RenderID, "displaynone", text);
                            HtmlLabel.Controls.Add(FileID);
                        }

                        break;

                    default:
                        break;
                }


                // Add Created Control to Page
                if (ControlHolder == null)
                {
                    ShowResponseMessage(Constants.MESSAGE_TYPE.error, "ControlHolder control not found");
                    return;
                }
                ControlHolder.Controls.Add(parentDiv);

                //Callback Function 
                if (!String.IsNullOrEmpty(item.Callback))
                {
                    sbjQueryCode.Append(CallBackFunction(item.Callback));
                }

                //Validation Check
                JObject validationObject = new JObject();

                if (item.Mandatory == "Y")
                {
                    validationObject.Add("required", true);
                }

                foreach (var validateItem in GetValidationRuleForIndividualControl(item.Callback))
                {
                    validationObject.Add(validateItem.Key, validateItem.Value);
                }

                validationRules.Add(ControlUniqueID + item.RenderID, validationObject);

            }//foreach end


            //After All Controls are Rendered
            if (!String.IsNullOrEmpty(CallbackString))
            {
                AfterRenderControl(CallbackString);
            }

            //Register JQuery Function
            if (sbjQueryCode.ToString() != string.Empty)
            {
                runjQueryCode(sbjQueryCode.ToString());
            }           

            //Validation Rules
            JObject rules = new JObject();
            rules.Add("rules", validationRules);
            StringBuilder sb = new StringBuilder();
            sb.Append(WebsiteHelpers.Validation(rules.ToString()));
            runjQueryCode(sb.ToString());

        }        

        #region Create Control
        private Label GetLabel(string id, string cssClass, string text = "")
        {
            Label lbl = new Label();

            lbl.ID = id;
            lbl.CssClass = cssClass;
            lbl.Text = text;

            return lbl;
        }

        private HtmlGenericControl GetHtmlGenericControl(string id, string cssClass, string tagName, string innerText, string forName)
        {
            HtmlGenericControl genericControl = new HtmlGenericControl();

            genericControl.TagName = tagName;
            genericControl.InnerText = innerText;

            if (tagName == "label")
            {
                genericControl.Attributes.Add("for", forName);
                genericControl.Attributes.Add("class", cssClass);
            }
            else
            {
                if (!string.IsNullOrEmpty(id))
                {
                    genericControl.Attributes.Add("id", id);
                }
                genericControl.Attributes.Add("class", cssClass);
            }

            return genericControl;
        }

        private TextBox GetTextBox(string id, string cssClass, int maxLength, string text, string tooltip)
        {
            TextBox txt = new TextBox();

            txt.ID = id;
            txt.CssClass = cssClass;
            txt.MaxLength = (maxLength != 0) ? maxLength : 10000;
            txt.Text = (text != string.Empty) ? text : string.Empty;

            if (!String.IsNullOrEmpty(tooltip))
            {
                txt.Attributes.Add("data-toggle", "tooltip");
                txt.Attributes.Add("data-placement", "right");
                txt.Attributes.Add("data-trigger", "focus");
                txt.Attributes.Add("data-original-title", tooltip);                
            }   
            
            return txt;
        }

        private TextBox GetTextArea(string id, string cssClass, string text, string tooltip)
        {
            TextBox txtArea = new TextBox();

            txtArea.ID = id;
            txtArea.CssClass = cssClass;
            txtArea.TextMode = TextBoxMode.MultiLine;
            txtArea.Text = (text != string.Empty) ? text : string.Empty;
            txtArea.Rows = 4;

            if (!String.IsNullOrEmpty(tooltip))
            {
                txtArea.Attributes.Add("data-toggle", "tooltip");
                txtArea.Attributes.Add("data-placement", "right");
                txtArea.Attributes.Add("data-trigger", "focus");
                txtArea.Attributes.Add("data-original-title", tooltip);
            } 

            return txtArea;
        }

        private CheckBox GetCheckBox(string id, string isCheck, string cssClass, string tooltip)
        {
            CheckBox chk = new CheckBox();

            chk.ID = id;
            chk.Width = 20;
            chk.Checked = (isCheck == "Y") ? true : false;
            chk.CssClass = cssClass;

            if (!String.IsNullOrEmpty(tooltip))
            {
                chk.Attributes.Add("data-toggle", "tooltip");
                chk.Attributes.Add("data-placement", "right");
                chk.Attributes.Add("data-trigger", "hover");
                chk.Attributes.Add("data-original-title", tooltip);
            } 

            return chk;
        }

        private DropDownList GetDropdownList(string id, string cssClass, string type, string selectedValue, string tooltip)
        {
            bool autoPostBack = false;
            DropDownList ddl = new DropDownList();
            ddl.ID = id;
            ddl.CssClass = cssClass;

            string parentType = string.Empty;
            JObject genericJsonObject = null;

            if (!String.IsNullOrEmpty(type))
            {
                JObject jsonObject = JObject.Parse(type);
                if (jsonObject["Dropdown"] != null)
                {
                    parentType = (string)jsonObject["Dropdown"]["ParentDataSource"];

                    if (jsonObject["Dropdown"]["Generic"] != null)
                    {
                        genericJsonObject = (JObject)jsonObject["Dropdown"]["Generic"];
                    }

                    if (jsonObject["Dropdown"]["TargetID"] != null)
                    {
                        autoPostBack = true;
                    }
                }
                ddl.AutoPostBack = autoPostBack;
                if (autoPostBack)
                {
                    ddl.SelectedIndexChanged += new EventHandler(dropdownlist_SelectedIndexChanged);
                }
            }

            int dropdownConditionID = 0;

            DropDownManager DropDownManager = new DropDownManager(ddl, parentType, selectedValue, genericJsonObject, dropdownConditionID);

            if (!String.IsNullOrEmpty(tooltip))
            {
                ddl.Attributes.Add("data-toggle", "tooltip");
                ddl.Attributes.Add("data-placement", "right");
                ddl.Attributes.Add("data-trigger", "hover");
                ddl.Attributes.Add("data-original-title", tooltip);
            } 

            return DropDownManager.FillDropDownList();
        }

        private void dropdownlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pageid = Convert.ToInt32(HttpContext.Current.Request.QueryString["pageid"]);            
            DropDownList parentDropDownList;

            if (sender != null)
            {
                parentDropDownList = (DropDownList)sender;
            }
            else
            {
                parentDropDownList = (DropDownList)page.Master.FindControl("ContentPlaceHolderMain").FindControl("ddl");
            }

            //ComponentBridge bridge = new ComponentBridge();
            var uow = new KBHAGUnitOfWork();
            var repoAdminPageStructure = new GenericRepository<FormStructure>();
            repoAdminPageStructure.UnitOfWork = uow;

            var pageStructure = repoAdminPageStructure.Get(i => i.PageID == pageid && i.RenderID == parentDropDownList.ID);

            string callBackString = (pageStructure != null) ? pageStructure.Callback : string.Empty;

            JObject jsonObject = JObject.Parse(callBackString);
            string targetid = string.Empty;
            string targetType = string.Empty;

            if (jsonObject["Dropdown"] != null)
            {
                targetid = (string)jsonObject["Dropdown"]["TargetID"];
                targetType = (jsonObject["Dropdown"]["TargetType"] != null) ? (string)jsonObject["Dropdown"]["TargetType"] : string.Empty;
            }

            DropDownList ddl = (DropDownList)page.Master.FindControl("ContentPlaceHolderMain").FindControl(targetid);

            ddl.ClearSelection();
            ddl.Items.Clear();
            ddl.SelectedIndex = -1;
            ddl.DataSource = null;
            ddl.SelectedValue = null;

            string dropdownType = string.Empty;
            int dropdownValue = 0;

            if (targetType != string.Empty)
            {
                dropdownType = targetType;
                int i = 0;
                bool canConvert = int.TryParse(parentDropDownList.SelectedValue, out i);

                if (canConvert == true)
                {
                    dropdownValue = i;
                }
                else
                {
                    dropdownValue = 0;
                    dropdownType = parentDropDownList.SelectedValue;
                }

            }
            else
            {
                dropdownType = parentDropDownList.SelectedValue;
                dropdownValue = 0;
            }

            DropDownManager DropDownManager = new DropDownManager(ddl, dropdownType, string.Empty, null, dropdownValue);
            DropDownManager.FillDropDownList();
        }

        private HiddenField CreateHiddenField(string id, string value)
        {
            HiddenField hidden = new HiddenField();
            hidden.ID = id;
            hidden.Value = value;
            return hidden;
        }

        private Image GetImageControl(string id, string imgURL)
        {
            Image img = new Image();

            img.ID = id;
            img.ImageUrl = imgURL;

            return img;
        }

        private HtmlAnchor GetHtmlAnchor(string id, string cssClass, string href, string innerText, string target)
        {
            HtmlAnchor anchor = new HtmlAnchor();

            anchor.ID = id;
            anchor.Attributes.Add("class", cssClass);
            anchor.HRef = href;
            anchor.InnerText = innerText;

            if (!string.IsNullOrEmpty(target))
            {                
                anchor.Target = target;
            }

            return anchor;
        }

        private HtmlImage GetHtmlImage(string id, string cssClass, string fileName, int width, int height)
        {
            HtmlImage image = new HtmlImage();

            image.ID = id;
            image.Attributes.Add("class", cssClass);
            image.Src = fileName;
            image.Width = width;
            image.Height = height;
            return image;
        }

        private CKEditorControl GetHTMLTextEditor(string id, string cssClass, string text, string toolbar)
        {
            CKEditorControl ckEditor = new CKEditorControl();

            ckEditor.ID = id;
            ckEditor.CssClass = cssClass;
            ckEditor.Text = (text != string.Empty) ? text : string.Empty;
            ckEditor.Toolbar = (toolbar != string.Empty) ? toolbar : "Basic";

            return ckEditor;
        }

        private FileUpload GetFileUpload(string id, string cssClass)
        {
            FileUpload fileupload = new FileUpload();
            fileupload.ID = id;
            fileupload.CssClass = cssClass;

            return fileupload;
        }

        private HtmlMeta GetHtmlMeta(string metaName, string metaContent)
        {
            HtmlMeta meta = new HtmlMeta();
            meta.Name = metaName;
            meta.Content = metaContent;
            return meta;
        }

        private string GetjQueryCode(string jsCodetoRun)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("$(document).ready(function() {");
            sb.AppendLine(jsCodetoRun);
            sb.AppendLine(" });");

            return sb.ToString();
        } 

        #endregion
        
        #region SubmitHandler
        public Dictionary<string, string> GetModelStructureList()
        {
            KBHAGUnitOfWork uow     = new KBHAGUnitOfWork();
            var repoAdminStructure  = new GenericRepository<FormStructure>();
            repoAdminStructure.UnitOfWork = uow;
            var pageStructure = repoAdminStructure.GetMany(i => i.PageID == FormDTO.PageID && i.Active == "Y").OrderBy(o => o.Index);

            Dictionary<string, string> ModelStructureList = new Dictionary<string, string>();

            foreach (var item in pageStructure)
            {
                if (!IsControlApplicable(item.Callback))
                    continue;

                switch (item.StructureControl)
                {
                    case "Textbox":
                        TextBox txt = (TextBox)this.ControlHolder.FindControl(item.RenderID);
                        ModelStructureList.Add(item.EntityFieldName, (item.Callback.ToLower().Contains("datefield")) ? WebsiteHelpers.GetMMDDYYYY(txt.Text, "dd/MM/yyyy").ToString() : txt.Text);
                        break;

                    case "Textarea":
                        TextBox txtArea = (TextBox)this.ControlHolder.FindControl(item.RenderID);
                        ModelStructureList.Add(item.EntityFieldName, txtArea.Text);
                        break;

                    case "Checkbox":
                        CheckBox chk = (CheckBox)this.ControlHolder.FindControl(item.RenderID);
                        ModelStructureList.Add(item.EntityFieldName, (chk.Checked) ? "Y" : "N");
                        break;

                    case "DropdownList":
                        DropDownList ddl = (DropDownList)this.ControlHolder.FindControl(item.RenderID);
                        ModelStructureList.Add(item.EntityFieldName, ddl.SelectedValue);
                        break;

                    case "HtmlEditor":
                        CKEditorControl ckEditor = (CKEditorControl)this.ControlHolder.FindControl(item.RenderID);
                        ModelStructureList.Add(item.EntityFieldName, ckEditor.Text);
                        break;

                    case "ImageUpload":

                        string ImageName = string.Empty;

                        string ImageFolderName = Constants.IMAGE_FOLDER_PATH;
                        JObject jsonImageObject = JObject.Parse(item.Callback);
                        if (jsonImageObject["Callback"]["ImageUpload"]["Folder"] != null)
                            ImageFolderName = (string)jsonImageObject["Callback"]["ImageUpload"]["Folder"];

                        HiddenField hiddenField = (HiddenField)this.ControlHolder.FindControl(String.Concat("hidden_", item.RenderID));

                        if (hiddenField.Value.ToLower().IndexOf(Constants.TEMP_IMAGE_FOLDER_PATH) > -1)
                            ImageName = WebsiteHelpers.croppedImageUpload(page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), page.ResolveUrl("~/" + ImageFolderName), hiddenField.Value);
                        else
                            ImageName = hiddenField.Value;
                        ModelStructureList.Add(item.EntityFieldName, ImageName);


                        break;

                    case "FileUpload":
                        //Upload File
                        FileUpload fileupload = (FileUpload)this.ControlHolder.FindControl(item.RenderID);
                        JObject jsonObjectFile = JObject.Parse(item.Callback);
                        string fileType = (string)jsonObjectFile["FileUpload"]["FileType"];

                        if (fileupload.HasFile)
                        {
                            string newfilename = fileupload.FileName;
                            string folderPath = (fileType.ToLower() == "file") ? "/" + Constants.FILE_FOLDER_PATH : Constants.IMAGE_FOLDER_PATH;
                            string FileFolder = HttpContext.Current.Server.MapPath("~/") + folderPath;

                            for (int i = 1; System.IO.File.Exists(FileFolder + newfilename); i++)
                            {
                                newfilename = fileupload.FileName.Insert(fileupload.FileName.LastIndexOf('.'), "(" + i + ")");
                            }
                            fileupload.SaveAs(FileFolder + newfilename);

                            ModelStructureList.Add(item.EntityFieldName, newfilename);
                        }
                        else
                        {
                            if (FormDTO.Action == "e")
                            {
                                Label label = (Label)this.ControlHolder.FindControl("label_" + item.RenderID);
                                ModelStructureList.Add(item.EntityFieldName, (label != null) ? label.Text : string.Empty);
                            }
                            else
                            {
                                ModelStructureList.Add(item.EntityFieldName, "0");
                            }
                        }
                        break;
                }
            }

            return ModelStructureList;

        }

        private bool IsControlApplicable(string callBackFunction)
        {
            var control = JsonConvert.DeserializeObject<dynamic>(callBackFunction);
            if (control != null)
            {
                return (control.Website != null) ? false : true;
            }
            else
            {
                return true;
            }
        }

        #endregion

        #region Clear Control
        public void ClearControl()
        {
            KBHAGUnitOfWork uow = new KBHAGUnitOfWork();
            var repoAdminStructure = new GenericRepository<FormStructure>();
            repoAdminStructure.UnitOfWork = uow;
            var pageStructure = repoAdminStructure.GetMany(i => i.PageID == FormDTO.PageID && i.Active == "Y").OrderBy(o => o.Index);
            foreach (var item in pageStructure)
            {
                if (!IsControlApplicable(item.Callback))
                    continue;

                switch (item.StructureControl)
                {
                    case "Textbox":
                        TextBox txt = (TextBox)this.ControlHolder.FindControl(item.RenderID);
                        txt.Text = string.Empty;
                        break;

                    case "Textarea":
                        TextBox txtArea = (TextBox)this.ControlHolder.FindControl(item.RenderID);
                        txtArea.Text = string.Empty;
                        break;

                    case "Checkbox":
                        CheckBox chk = (CheckBox)this.ControlHolder.FindControl(item.RenderID);
                        chk.Checked = false;
                        break;

                    case "DropdownList":
                        DropDownList ddl = (DropDownList)this.ControlHolder.FindControl(item.RenderID);
                        ddl.SelectedIndex = 0;
                        break;

                    case "HtmlEditor":
                        CKEditorControl ckEditor = (CKEditorControl)this.ControlHolder.FindControl(item.RenderID);
                        ckEditor.Text = string.Empty;
                        break;
                }
            }
        }
        #endregion

        #region Message

        public void ShowResponseMessage(Constants.MESSAGE_TYPE type, string message)
        {
            HtmlGenericControl ResponseMessageHolder = (HtmlGenericControl)page.Master.FindControl("ResponseMessageHolder");

            System.Web.UI.UserControl messageControl = (System.Web.UI.UserControl)page.LoadControl(@"~/Administrator/UserControls/ResponseMessageControl.ascx");
            messageControl.ID = "UserControlResponseMessage";
            ResponseMessageHolder.Controls.Clear();

            IResponseMessage responseMessage = messageControl as IResponseMessage;
            if (responseMessage != null)
            {
                responseMessage.MessageType = type;
                responseMessage.Message     = message;
            }

            ResponseMessageHolder.Controls.Add(messageControl);
        }

        public void ShowGrowlMessage()
        {
            if (!String.IsNullOrEmpty(FormDTO.Message))
            {
                string messageText = string.Empty;

                if (FormDTO.Message == "a")
                {
                    messageText = Constants.INSERT_MESSAGE;
                }
                else if (FormDTO.Message == "u")
                {
                    messageText = Constants.UPDATE_MESSAGE;
                }
                else if (FormDTO.Message == "d")
                {
                    messageText = Constants.DELETE_MESSAGE;
                }

                runjQueryCode("$.msgGrowl ({type: 'success', title: 'Success', text: '" + messageText + "'})");

            }
        }

        public void ShowResponseMessage
            (
                HtmlGenericControl MessageHolder,
                HtmlGenericControl messageBox,
                Label lblMessageHeading,
                Label lblMessage,
                Constants.MESSAGE_TYPE type, 
                string message
            )
        {
            MessageHolder.Visible = true;

            string cssClass = string.Empty;

            switch (type)
            {
                case Constants.MESSAGE_TYPE.block:
                    lblMessageHeading.Text = "Alert";
                    break;

                case Constants.MESSAGE_TYPE.error:
                    lblMessageHeading.Text = "Error";
                    break;

                case Constants.MESSAGE_TYPE.success:
                    lblMessageHeading.Text = "Success";
                    break;

                case Constants.MESSAGE_TYPE.info:
                    lblMessageHeading.Text = "Information";
                    break;
            }

            lblMessage.Text = message;
            messageBox.Attributes.Add("class", "alert alert-" + type);
        }   
        #endregion

        #region Helpers

        private Dictionary<string, string> GetValidationRuleForIndividualControl(string callBackFunction)
        {
            Dictionary<string, string> dic = new Dictionary<string, string> { };

            if (!String.IsNullOrEmpty(callBackFunction))
            {
                JObject jsonObject = JObject.Parse(callBackFunction);

                if (jsonObject["Callback"] != null)
                {
                    //AcceptNumber
                    if (jsonObject["Callback"]["AcceptNumber"] != null)
                    {
                        dic.Add("number", "true");
                    }

                    //Email Validation
                    if (jsonObject["Callback"]["ValidateEmail"] != null)
                    {
                        dic.Add("email", "true");
                    }

                }
            }

            return dic;
        }

        private string CallBackFunction(string callBackFunction)
        {
            StringBuilder sb = new StringBuilder();

            if (!String.IsNullOrEmpty(callBackFunction))
            {
                JObject jsonObjectAnchor = JObject.Parse(callBackFunction);

                if (jsonObjectAnchor["Callback"] != null)
                {
                    //Date Field
                    if (jsonObjectAnchor["Callback"]["DateField"] != null)
                    {
                        sb.Append(WebsiteHelpers.DateField((string)jsonObjectAnchor["Callback"]["DateField"]));
                    }

                    //Clear Control
                    if (jsonObjectAnchor["Callback"]["Delete"] != null)
                    {
                        sb.Append(WebsiteHelpers.ClearControl((string)jsonObjectAnchor["Callback"]["Delete"]));
                    }

                    //ImageUpload Control
                    if (jsonObjectAnchor["Callback"]["ImageUpload"] != null)
                    {
                        string width = (string)jsonObjectAnchor["Callback"]["ImageUpload"]["ImageWidth"];
                        string height = (string)jsonObjectAnchor["Callback"]["ImageUpload"]["ImageHeight"];
                        string control = (string)jsonObjectAnchor["Callback"]["ImageUpload"]["ControlID"];
                        string url = page.ResolveUrl("~/Manage/photoupload.aspx?gridheight=550&gridwidth=1000&imageheight=" + height + "&imagewidth=" + width + "&mediascript=fnImageUpload&isalbum=n&mediafield=" + control);
                        sb.Append(WebsiteHelpers.ImageUploadControlScript(control, url));
                    }
                }
            }

            return sb.ToString();
        }

        private void AfterRenderControl(string json)
        {
            try
            {

                JObject jsonObject = JObject.Parse(json);

                //Disable Submit
                if (jsonObject["AllowSubmit"] != null)
                {
                    if (this.SubmitButton != null)
                    {
                        this.SubmitButton.Visible = Convert.ToBoolean((string)jsonObject["AllowSubmit"]["Submit"]);    
                    }                    
                }


                //Cascading Dropdown List
                if (jsonObject["AfterRenderControl"] != null && jsonObject["AfterRenderControl"]["Dropdown"] != null)
                {
                    if (FormDTO.Action == "e")
                    {                        
                        var rows = DynamicHelpers.GetRowCollectionList(FormDTO.Model, FormDTO.ReferenceID);

                        if (jsonObject["AfterRenderControl"]["Dropdown"] != null)
                        {
                            for (int j = 0; j < jsonObject["AfterRenderControl"]["Dropdown"].Count(); j++)
                            {
                                int current = j + 1;
                                DropDownList ddl = (DropDownList)this.ControlHolder.FindControl((string)jsonObject["AfterRenderControl"]["Dropdown"]["Level" + current]["TargetID"]);
                                CreateControls.dropdownlist_SelectedIndexChanged(ddl, null);
                                string text = rows.Single(i => i.ColumnName == (string)jsonObject["AfterRenderControl"]["Dropdown"]["Level" + current]["ChildColumnName"]).ColumnValue;
                                DropDownList ddlChild = (DropDownList)this.ControlHolder.FindControl((string)jsonObject["AfterRenderControl"]["Dropdown"]["Level" + current]["ChildRenderId"]);
                                ddlChild.SelectedValue = text;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowResponseMessage(Constants.MESSAGE_TYPE.error, String.Concat(Constants.ERROR_LONG_MESSAGE, ex.ToString()));
            }
        }

        private void runjQueryCode(string jsCodetoRun)
        {
            

            ScriptManager requestSM = ScriptManager.GetCurrent(page);
            if (requestSM != null && requestSM.IsInAsyncPostBack)
            {
                ScriptManager.RegisterClientScriptBlock(page,
                                                        typeof(Page),
                                                        Guid.NewGuid().ToString(),
                                                        WebsiteHelpers.GetjQueryCode(jsCodetoRun),
                                                        true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(page, 
                                                        page.GetType(),
                                                        Guid.NewGuid().ToString(),
                                                        WebsiteHelpers.GetjQueryCode(jsCodetoRun), 
                                                        true);                
            }
        }
        #endregion
    }
}
