﻿using KBHAG.Data;
using KBHAG.Model;
using System.Collections.Generic;
using System.Linq;

namespace KBHAG.Repository
{
    public class PageRepository:IPageRepository
    {
        #region Page
        public CMSPage GetPageByPageID(int pageid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<CMSPage>();
                repo.UnitOfWork = uow;
                return repo.GetById(pageid);
            }
        }

        public List<CommonDTO> GetPagesByMenuID(int menuid)
        {
            List<CommonDTO> PageList = new List<CommonDTO>();
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<CMSPage>();
                repo.UnitOfWork = uow;
                foreach (var item in repo.GetMany(i => i.MenuID == menuid))
                {
                    var repoPublish = new GenericRepository<PagePublish>();
                    repoPublish.UnitOfWork = uow;
                    var query = repoPublish.Get(i => i.MenuID == menuid && i.PageID == item.PageID);
                    string publish = (query != null) ? "Publish" : "Unpublish";

                    CommonDTO page = new CommonDTO {
                        DTO1 = item.Title,
                        DTO2 = publish,
                        DTO4 = item.PageID
                    };

                    PageList.Add(page);
                }
            }
            return PageList;
        }

        public int AddPage(CMSPage PageDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<CMSPage>();
                repo.UnitOfWork = uow;

                CMSPage page = new CMSPage
                {
                    LayoutID    = PageDTO.LayoutID,
                    MenuID      = PageDTO.MenuID,
                    Title       = PageDTO.Title,
                    MetaTitle   = PageDTO.MetaTitle,
                    MetaDesc    = PageDTO.MetaDesc,
                    MetaKeyWord = PageDTO.MetaKeyWord
                };
                repo.Add(page);
                uow.Commit();
                return page.PageID;
            }
        }

        public void UpdatePage(CMSPage PageDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<CMSPage>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(PageDTO.PageID);

                if (data != null)
                {
                    data.Title       = PageDTO.MetaTitle;
                    data.MetaTitle   = PageDTO.MetaTitle;
                    data.MetaDesc    = PageDTO.MetaDesc;
                    data.MetaKeyWord = PageDTO.MetaKeyWord;
                }                
                repo.Update(data);
                uow.Commit();                
            }
        }

        public void UpdateJavaScript(int pageid, string javascript)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<CMSPage>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(pageid);

                if (data != null)
                {
                    data.JavaScript = javascript;                   
                }
                repo.Update(data);
                uow.Commit();
            }
        }

        public string GetTitleByIDAndType(int id, string type)
        {
            string title = string.Empty;

            switch (type)
            {
                case "page":
                    using (var uow = new KBHAGUnitOfWork())
                    {
                        var repo = new GenericRepository<CMSPage>();
                        repo.UnitOfWork = uow;
                        title = repo.GetById(id).Title;
                    }
                    break;
                default:
                    title = string.Empty;
                    break;
            }
            return title;
        }

        #endregion

        #region Layout
        
        public List<Layout> GetLayout()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo        = new GenericRepository<Layout>();
                repo.UnitOfWork = uow;
                return repo.GetAll().OrderBy(o => o.Name).ToList();
            }  
        }

        public string GetLayoutHTML(int layoutid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo        = new GenericRepository<Layout>();
                repo.UnitOfWork = uow;
                return repo.GetById(layoutid).HtmlContent;
            }
        }

        #endregion

        #region PageData

        public PageData GetPageDataByID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PageData>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }

        public List<ViewPageData> GetPageContentByPageID(int pageid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo        = new GenericRepository<ViewPageData>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.PageID == pageid).ToList();
            }   
        }

        public void AddPageData(PageData PageDataDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PageData>();
                repo.UnitOfWork = uow;

                PageData pageData = new PageData {                     
                    PageID          = PageDataDTO.PageID,
                    PageStructureID = PageDataDTO.PageStructureID,
                    Content         = PageDataDTO.Content
                };
                repo.Add(pageData);
                uow.Commit();
            }
        }

        public void UpdatePageData(PageData PageDataDTO)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PageData>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(PageDataDTO.PageDataID);
                if (data != null)
                {
                    data.Content = PageDataDTO.Content;
                }

                repo.Update(data);
                uow.Commit();
            }
        }

        public void UpdatePageImage(int pageDataId, string imageFileName)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PageData>();
                repo.UnitOfWork = uow;

                var data = repo.GetById(pageDataId);
                if (data != null)
                {
                    data.Content = imageFileName;
                }

                repo.Update(data);
                uow.Commit();
            }
        }

        #endregion
        
        #region MapLayoutStructure
        public List<ViewMapLayoutStructure> GetMapLayoutStructureByLayoutID(int layoutid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMapLayoutStructure>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.LayoutID == layoutid).ToList();
            }
        }
        #endregion                 

        #region Page Publish
        public void PublishPage(PagePublish PagePublish)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PagePublish>();
                repo.UnitOfWork = uow;

                var exsits = repo.Get(i => i.MenuID == PagePublish.MenuID);

                if (exsits != null)
                {
                    exsits.PageID = PagePublish.PageID;
                    repo.Update(exsits);
                }
                else
                {
                    repo.Add(PagePublish);
                }
                uow.Commit();
            }
        }

        public PagePublish GetPublishPageByMenuID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PagePublish>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.MenuID == id);
            }
        }
        #endregion

        #region FormPage
        public FormPage GetFormPageByAllias(string allias)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<FormPage>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.Title == allias);
            }
        }
        #endregion        
           
    }
}
