﻿var app = {

    BaseUrl: "",
    PageDTO: {},
    utils: {},
    constants: {}

};

app.constants.TopMenuId         = 'TopMenu';
app.constants.PaginationObj     = '.pagination';
app.constants.DropDownPrefix    = 'jsddm_';
app.constants.FooterPrefix      = 'fm_';

app.init = function () {
    $(function () {
        if ($('#' + app.constants.TopMenuId).length > 0)
            Display.CreateDropDown(app.constants.TopMenuId);

        app.utils.checkPager(app.constants.PaginationObj);
    });
}


app.utils.checkPager = function (jqobj) {
    if ($(jqobj + '>span').eq(0).length > 0 && $(jqobj + '>span').eq(0).children().size() < 4)
        $(jqobj).hide();
}

app.utils.ResolveUrl = function (url) {
    if (url.indexOf("~/") == 0) {
        url = app.BaseUrl + url.substring(2);
    }
    return url;
}

app.utils.ShowResponsiveMessage = function (divID, messageType, message) {
    var messageClass = "";
    switch (messageType.toLowerCase()) {
        case "alert":
            messageClass = "alert-block";
            break;
        case "error":
            messageClass = "alert-error";
            break;
        case "success":
            messageClass = "alert-success";
            break;
        default:
    }

    $("#" + divID).show();
    $("#" + divID).html("<div class='alert " + messageClass + "'><h4>" + messageType + "!</h4>" + message);    
    $('#back-to-top').click();
}

app.utils.ShowResponsiveProcessMessage = function (divID) {
    $('#back-to-top').click();
    $("#" + divID).html("<div class='alert alert-info'><h4>Processing!</h4><div id='ResponsiveProcessMessage'></div>");
    i = 0;
    text = "Processing your request ";
    setInterval(function () {
        $("#ResponsiveProcessMessage").html(text + Array((++i % 10) + 1).join("."));
    }, 500);
}

app.utils.hideErrorDiv = function (divID) {
    $("#" + divID).hide();
    $("#" + divID).empty();
    $("#" + divID).removeClass('error').removeClass('information').removeClass('success').removeClass('process');
}

//Error in input field
app.utils.showErrorInput = function (inputID) {
    $("#" + inputID).addClass('error');
    $("#" + inputID).focus();
}

app.utils.removeErrorInput = function (inputID) {
    $("#" + inputID).removeClass('error');
}

app.utils.removeListener = function (controlID) {
    $('#' + controlID).hide();
}

app.utils.StringIsBlank = function (stringVal) {
    if (stringVal == null)
        return false;

    if (stringVal == 'null')
        return false;

    if (stringVal == undefined)
        return false;

    if (stringVal == 'undefined')
        return false;

    if ($.trim(stringVal).length > 0)
        return false;
    else
        return true;
}

app.utils.executeFunctionByName = function(functionName, context /*, args */) {
    var args = Array.prototype.slice.call(arguments, 2);
    var namespaces = functionName.split(".");
    var func = namespaces.pop();
    for (var i = 0; i < namespaces.length; i++) {
        context = context[namespaces[i]];
    }
    return context[func].apply(this, args);
}

var Display = function () {
    //Exposing Properties and Methods
    return {
        CreateDropDown: CreateDropDown, //Create Simple Drop Down Menus
        HilightMenu: hilightMenu, // Hilight Active Menus
        CreateCropControl: CreateImageCropField, //Creates the crop control on an image
        GetCropImage: GetCropImage
    };

    function CreateDropDown(menuid) {
        //Style Dependancy to be included in css file.

        var ddmenuitem;
        var timeout = 500;
        var closetimer = 0;
        var ddmenuitem = 0;

        CreateMenu(menuid)

        function CreateMenu(menuid) {
            //$('#' + menuid + ' li:last').remove();
            $('#' + menuid + ' > li:last').find('ul').css('left', '');
            $('#' + menuid + ' > li:last').find('ul').css('right', '0');
            $('#' + menuid + ' > li').bind('mouseover', jsddm_open);
            $('#' + menuid + ' > li').bind('mouseout', jsddm_timer);

            $('#' + menuid + ' li').each(function (index, ele) {
                if ($(this).find('ul').length > 0) {
                    ino = $(this).find('ul li').length;
                    $(this).find('ul li').eq(ino - 1).find('a').css('border-bottom', '0');
                }
            });

            document.onclick = jsddm_close;
        }

        function jsddm_open() {
            jsddm_canceltimer();
            jsddm_close();
            ddmenuitem = $(this).find('ul').eq(0).css('visibility', 'visible');
        }

        function jsddm_close()
        { if (ddmenuitem) ddmenuitem.css('visibility', 'hidden'); }

        function jsddm_timer()
        { closetimer = window.setTimeout(jsddm_close, timeout); }

        function jsddm_canceltimer() {
            if (closetimer) {
                window.clearTimeout(closetimer);
                closetimer = null;
            }
        }

    };

    function hilightMenu(alias) {
        if ($('#' + app.constants.DropDownPrefix + alias).length > 0)
            $('#' + app.constants.DropDownPrefix + alias).addClass('active');

        if ($('#' + app.constants.FooterPrefix + alias).length > 0)
            $('#' + app.constants.FooterPrefix + alias).addClass('active');
    }


    /*-------------------------------------------------Crop Control Handlers----------------------------------------------*/

    function CreateImageCropField(obj) {
        var GLOBAL_GRID_HEIGHT = 550;
        var GLOBAL_GRID_WIDTH = 1000;
        var GLOBAL_CROP_URL = "photoUpload.aspx";

        cid = obj.Control.attr('id');

        var strHtmlCrop = '';
        var strUpUrl = ''

        if (obj.WrapHtml != undefined && !app.utils.StringIsBlank(obj.WrapHtml))
            strHtmlCrop += '<' + obj.WrapHtml + '>';

        strHtmlCrop += '<a id="btn' + cid + '" href="#" ';

        
        if (obj.Style != undefined && !app.utils.StringIsBlank(obj.Style))
            strHtmlCrop += 'style="' + obj.Style + '" ';

        if (obj.ControlClass != undefined && !app.utils.StringIsBlank(obj.ControlClass))
            strHtmlCrop += 'class="' + obj.ControlClass + '" ';
        
        strHtmlCrop += '>Upload Image</a>';

        if (obj.IsAlbum == undefined && !obj.IsAlbum)
            strHtmlCrop += '<input type="hidden" ID="hdn' + cid + '_0" Value="' + obj.Control.attr('src') + '"/>';

        if (obj.WrapHtml != undefined && !app.utils.StringIsBlank(obj.WrapHtml))
            strHtmlCrop += '</' + obj.WrapHtml + '>';
        
        if (obj.WrapHtml != undefined && !app.utils.StringIsBlank(obj.WrapHtml)) {
            obj.Control.wrap('<' + obj.WrapHtml + ' />');
            obj.Control.parent().after(strHtmlCrop);
        } else {
            obj.Control.after(strHtmlCrop);
        }

        if (obj.Href != undefined && !app.utils.StringIsBlank(obj.Href))
            strUpUrl += obj.Href + '?';
        else
            strUpUrl += GLOBAL_CROP_URL + '?';

        if (obj.GridWidth != undefined && !app.utils.StringIsBlank(obj.GridHeight))
            strUpUrl += 'gridwidth=' + obj.GridWidth;
        else
            strUpUrl += 'gridwidth=' + GLOBAL_GRID_WIDTH;

        if (obj.GridHeight != undefined && !app.utils.StringIsBlank(obj.GridHeight))
            strUpUrl += '&gridheight=' + obj.GridHeight;
        else
            strUpUrl += '&gridheight=' + GLOBAL_GRID_HEIGHT;

        strUpUrl += '&imagewidth=' + obj.ImageWidth;
        strUpUrl += '&imageheight=' + obj.ImageHeight;

        if (obj.IsAlbum != undefined && obj.IsAlbum)
            strUpUrl += '&isalbum=y';

        if (obj.MediaScript != undefined && !app.utils.StringIsBlank(obj.MediaScript))
            strUpUrl += '&mediascript=' + obj.MediaScript;

        if (obj.MediaField != undefined && !app.utils.StringIsBlank(obj.MediaField))
            strUpUrl += '&mediafield=' + obj.MediaField;
        else
            strUpUrl += '&mediafield=' + cid;

        //---Final Step, creating Fancybox click.
        $('#btn' + cid).click(function () {
            var strURL = app.utils.ResolveUrl('~/' + strUpUrl);
            $.fancybox.open({
                href: strURL,
                type: 'ajax',
                padding: 5
            });
        });

    }

    function GetCropImage(obj) {
        cid = obj.attr('id');
        oldfile = $('[id$=hdn' + cid + '_0]').val();

        newfile = obj.attr('src');

        if (newfile != oldfile)
            return newfile;
        else
            return oldfile.substr(oldfile.lastIndexOf('/') + 1, oldfile.length - (oldfile.lastIndexOf('/') + 1));
    }

    /*-------------------------------------------------Crop Control Handlers End----------------------------------------------*/

}();

/* Growl Message Pluging */
(function ($) {
    $.msgGrowl = function (config) {

        var defaults, options, container, msgGrowl, content, title, text, close;

        defaults = {
            type: ''
			, title: ''
			, text: ''
			, lifetime: 6500
			, sticky: false
			, position: 'bottom-right'
			, closeTrigger: true
			, onOpen: function () { }
			, onClose: function () { }
        };

        options = $.extend(defaults, config);

        container = $('.msgGrowl-container.' + options.position);

        if (!container.length) {
            container = $('<div>', {
                'class': 'msgGrowl-container ' + options.position
            }).appendTo('body');
        }

        msgGrowl = $('<div>', {
            'class': 'msgGrowl ' + options.type
        });

        content = $('<div>', {
            'class': 'msgGrowl-content'
        }).appendTo(msgGrowl);

        text = $('<span>', {
            text: options.text
        }).appendTo(content);

        if (options.closeTrigger) {
            close = $('<div>', {
                'class': 'msgGrowl-close'
				, 'click': function (e) {
				    e.preventDefault();
				    $(this).parent().fadeOut('medium', function () {
				        $(this).remove();
				        if (typeof options.onClose === 'function') {
				            options.onClose();
				        }
				    });
				}
            }).appendTo(msgGrowl);
        }

        if (options.title != '') {
            title = $('<h4>', {
                text: options.title
            }).prependTo(content);
        }

        if (options.lifetime > 0 && !options.sticky) {
            setTimeout(function () {
                if (typeof options.onClose === 'function') {
                    options.onClose();
                }
                msgGrowl.fadeOut('medium', function () { $(this).remove(); });
            }, options.lifetime);
        }

        container.addClass(options.position);

        if (options.position.split('-')[0] == 'top') {
            msgGrowl.prependTo(container).hide().fadeIn('slow');
        } else {
            msgGrowl.appendTo(container).hide().fadeIn('slow');
        }

        if (typeof options.onOpen === 'function') {
            options.onOpen();
        }
    }
})(jQuery);
/* Growl Message Pluging */