﻿$.extend($.jgrid.defaults, {    
    hidegrid    : false,
    height      : "100%",
    altRows     : true,
    altclass    : "AltRowClass",
    shrinkToFit : true,
    autowidth   : true,
    gridview    : true,
    rownumbers  : false,
    viewrecords : true,
    datatype    : "json",
    sortable    : true,
    scrollrows  : true,
    headertitles: true,
    loadui      : "block",
    viewsortcols: [false, "vertical", true],
    prmNames    : { nd: null, page: "pageIndex", rows: "rowsPerPage", sort: "sortByColumn", order: "sortOrder", search: "isSearching" },
    ajaxGridOptions: { contentType: "application/json" },
    ajaxRowOptions: { contentType: "application/json", type: "PUT", async: true },
    ajaxSelectOptions: { contentType: "application/json", dataType: "JSON" },
    serializeRowData: function (data) {
        var propertyName, propertyValue, dataToSend = {};
        for (propertyName in data) {
            if (data.hasOwnProperty(propertyName)) {
                propertyValue = data[propertyName];
                if ($.isFunction(propertyValue)) {
                    dataToSend[propertyName] = propertyValue();
                } else {
                    dataToSend[propertyName] = propertyValue;
                }
            }
        }
        return JSON.stringify(dataToSend);
    },
    resizeStop: function () {
        var $grid = $(this.bDiv).find('>:first-child>.ui-jqgrid-btable:last-child'),
            shrinkToFit = $grid.jqGrid('getGridParam', 'shrinkToFit'),
            saveState = $grid.jqGrid('getGridParam', 'saveState');

        $grid.jqGrid('setGridWidth', this.newWidth, shrinkToFit);
        if ($.isFunction(saveState)) {
            saveState.call($grid[0]);
        }
    },
    gridComplete: function () {
        $("#" + this.id + "_err").remove();
    },
    loadError: function (xhr) {
        var response = xhr.responseText, errorDetail, errorHtml, i, l, errorDescription;
        if (response.charAt(0) === '[' && response.charAt(response.length - 1) === ']') {
            errorDetail = $.parseJSON(xhr.responseText);
            var errorText = "";
            for (i = 0, l = errorDetail.length; i < l; i++) {
                if (errorText.length !== 0) {
                    errorText += "<hr/>";
                }
                errorDescription = errorDetail[i];
                errorText += "<strong>" + errorDescription.Source + "</strong>";
                if (errorDescription.ErrorCode) {
                    errorText += " (ErrorCode: " + errorDescription.ErrorCode + ")";
                }
                errorText += ": " + errorDescription.Message;
            }
            errorHtml = '<div id="errdiv" class="ui-state-error ui-corner-all" style="padding-left: 10px; padding-right: 10px; max-width:' +
                ($(this).closest(".ui-jqgrid").width() - 20) +
                'px;"><p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span><span>' +
                errorText + '</span></p></div>';
            $("#" + this.id + "_err").remove();
            $(this).closest(".ui-jqgrid").before(errorHtml);
        }
    }
});

$.extend($.jgrid.search, {
    multipleSearch: true,
    recreateFilter: true,
    closeOnEscape: true,
    searchOnEnter: true,
    overlay: 0
});