﻿using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.SessionState;

namespace KBHAG.Website
{
    public class ProcessImage : IHttpHandler, IReadOnlySessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            Thread.CurrentThread.CurrentUICulture   = new System.Globalization.CultureInfo("en-US");
            Thread.CurrentThread.CurrentCulture     = new System.Globalization.CultureInfo("en-US");

            context.Response.ContentType = "text/plain";
            int ID = Convert.ToInt32(context.Request["ID"]);
            float imageH = float.Parse(context.Request["imageH"]);
            float imageW = float.Parse(context.Request["imageW"]);            
            long imageCompression = long.Parse(context.Request["imageCompression"]);
            float angle = float.Parse(context.Request["imageRotate"]);
            string img_source = context.Request["imageSource"];
            float imageX = float.Parse(context.Request["imageX"]);
            float imageY = float.Parse(context.Request["imageY"]);
            float selectorH = float.Parse(context.Request["selectorH"].ToString().Replace("px", ""));
            float selectorW = float.Parse(context.Request["selectorW"].ToString().Replace("px", ""));
            float selectorX = float.Parse(context.Request["selectorX"].ToString().Replace("px", ""));
            float selectorY = float.Parse(context.Request["selectorY"].ToString().Replace("px", ""));
            float viewPortH = float.Parse(context.Request["viewPortH"].ToString().Replace("px", ""));
            float viewPortW = float.Parse(context.Request["viewPortW"].ToString().Replace("px", ""));

            //To Values
            float pWidth = imageW;
            float pHeight = imageH;

            img_source = img_source.Replace("../../", "~/");
            Bitmap img = (Bitmap)Bitmap.FromFile(context.Server.MapPath(img_source));
            //Original Values
            int _width = img.Width;
            int _height = img.Height;


            //Resize
            Bitmap image_p = ResizeImage(img, Convert.ToInt32(pWidth), Convert.ToInt32(pHeight));

            int widthR = image_p.Width;
            int heightR = image_p.Height;
            //Rotate if angle is not 0.00 or 360
            if (angle > 0.0F && angle < 360.00F)
            {
                image_p = (Bitmap)RotateImage(image_p, (double)angle);
                pWidth = image_p.Width;
                pHeight = image_p.Height;
            }

            //Calculate Coords of the Image into the ViewPort
            float src_x = 0;
            float dst_x = 0;
            float src_y = 0;
            float dst_y = 0;

            if (pWidth > viewPortW)
            {
                src_x = (float)Math.Abs(imageX - Math.Abs((imageW - pWidth) / 2));
                dst_x = 0;
            }
            else
            {
                src_x = 0;
                dst_x = (float)(imageX + ((imageW - pWidth) / 2));
            }
            if (pHeight > viewPortH)
            {
                src_y = (float)Math.Abs(imageY - Math.Abs((imageH - pHeight) / 2));
                dst_y = 0;
            }
            else
            {
                src_y = 0;
                dst_y = (float)(imageY + ((imageH - pHeight) / 2));
            }


            //Get Image viewed into the ViewPort
            image_p = ImageCopy(image_p, dst_x, dst_y, src_x, src_y, viewPortW, viewPortH, pWidth, pHeight);
            //image_p.Save(context.Server.MapPath("test_viewport.jpg"));
            //Get Selector Portion
            image_p = ImageCopy(image_p, 0, 0, selectorX, selectorY, selectorW, selectorH, viewPortW, viewPortH);

            string strFileName = String.Format("crop{0}", img_source.Substring(img_source.LastIndexOf('/') + 1, img_source.Length - img_source.LastIndexOf('/') - 1));
            string FileName = WebsiteHelpers.UniqueFilename(strFileName, HttpContext.Current.Server.MapPath("~/" + Constants.TEMP_IMAGE_FOLDER_PATH));
            //context.Session["WorkingImage"] = FileName;
            //using function to save as a jpeg with compression imageCompression has been added as the dynamic compression factor on top.
            SaveJPGWithCompressionSetting(image_p, context.Server.MapPath(img_source.Substring(0, img_source.LastIndexOf('/') + 1) + FileName), imageCompression);
            //image_p.Save(context.Server.MapPath(img_source.Substring(0, img_source.LastIndexOf('/')+1) + FileName));            
            image_p.Dispose();
            img.Dispose();

            //deleting original uploaded file here!
            FileInfo theFile = new FileInfo(context.Server.MapPath(img_source));
            if (theFile.Exists)
            {
                File.Delete(context.Server.MapPath(img_source));
            }

            //imgSelector.Dispose();
            context.Response.Write(FileName);
        }

        private Bitmap ImageCopy(Bitmap srcBitmap, float dst_x, float dst_y, float src_x, float src_y, float dst_width, float dst_height, float src_width, float src_height)
        {
            // Create the new bitmap and associated graphics object
            RectangleF SourceRec = new RectangleF(src_x, src_y, dst_width, dst_height);
            RectangleF DestRec = new RectangleF(dst_x, dst_y, dst_width, dst_height);
            Color color = Color.FromArgb(255, 255, 255);

            Bitmap bmp = new Bitmap(Convert.ToInt32(dst_width), Convert.ToInt32(dst_height));

            Graphics g = Graphics.FromImage(bmp);

            // Create a Brush object for coloring.

            SolidBrush colorBrush = new SolidBrush(Color.FromArgb(255, 255, 255)); // color of the certificate as default back for all images.
            g.FillRectangle(colorBrush, DestRec);

            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            // Draw the specified section of the source bitmap to the new one
            g.DrawImage(srcBitmap, DestRec, SourceRec, GraphicsUnit.Pixel);
            // Clean up
            g.Dispose();

            // Return the bitmap
            return bmp;

        }

        public bool GetThumbAbort()
        {
            return false;
        }

        private Bitmap ResizeImage(Bitmap img, int width, int height)
        {
            int sourceWidth = img.Width;
            int sourceHeight = img.Height;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            nPercentW = ((float)width / (float)sourceWidth);
            nPercentH = ((float)height / (float)sourceHeight);

            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(img, 0, 0, destWidth, destHeight);
            g.Dispose();

            return b;
        }

        /// <summary>
        /// method to rotate an image either clockwise or counter-clockwise
        /// </summary>
        /// <param name="img">the image to be rotated</param>
        /// <param name="rotationAngle">the angle (in degrees).
        /// NOTE: 
        /// Positive values will rotate clockwise
        /// negative values will rotate counter-clockwise
        /// </param>
        /// <returns></returns>
        private Image RotateImage(Bitmap img, double rotationAngle)
        {
            //create an empty Bitmap image
            Bitmap bmp = new Bitmap(img.Width, img.Height);

            //turn the Bitmap into a Graphics object
            Graphics gfx = Graphics.FromImage(bmp);

            //now we set the rotation point to the center of our image
            gfx.TranslateTransform((float)bmp.Width / 2, (float)bmp.Height / 2);

            //now rotate the image
            gfx.RotateTransform((float)rotationAngle);

            gfx.TranslateTransform(-(float)bmp.Width / 2, -(float)bmp.Height / 2);

            //set the InterpolationMode to HighQualityBicubic so to ensure a high
            //quality image once it is transformed to the specified size
            gfx.InterpolationMode = InterpolationMode.HighQualityBicubic;

            //now draw our new image onto the graphics object
            gfx.DrawImage(img, new Point(0, 0));

            //dispose of our Graphics object
            gfx.Dispose();

            //return the image
            return bmp;
        }
        //method to retrieve encoder information.
        private static ImageCodecInfo GetEncoderInfo(String mimeType)
        {
            int j;
            ImageCodecInfo[] encoders;
            encoders = ImageCodecInfo.GetImageEncoders();
            for (j = 0; j < encoders.Length; ++j)
            {
                if (encoders[j].MimeType == mimeType)
                    return encoders[j];
            }
            return null;
        }
        //method to save final with required jpeg compression
        private void SaveJPGWithCompressionSetting(Image image, string szFileName, long lCompression)
        {
            EncoderParameters eps = new EncoderParameters(1);
            eps.Param[0] = new EncoderParameter(Encoder.Quality, lCompression);
            ImageCodecInfo ici = GetEncoderInfo("image/jpeg");
            image.Save(szFileName, ici, eps);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}