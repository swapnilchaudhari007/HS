﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace KBHAG.Repository
{
    public class ClassWrapper : DynamicObject
    {
        //static BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public;

        public static dynamic FromType(Assembly asm, string type, Dictionary<string, string> dataDic)
        {
            var allt = asm.GetTypes();
            var t = allt.First(item => item.Name == type);
            RecursiveLoad(t, dataDic);
            return allt;
        }

        private static void RecursiveLoad(Type instance, Dictionary<string, string> dataDic)
        {
            foreach (var item in dataDic)
            {
                PropertyInfo pInfo = instance.GetProperty(item.Key);
                var value = Convert.ChangeType(item.Value, pInfo.PropertyType);
                pInfo.SetValue(instance, value, null);
            }   
        }

    }
}
