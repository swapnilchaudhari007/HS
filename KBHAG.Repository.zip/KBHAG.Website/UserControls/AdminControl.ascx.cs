﻿using KBHAG.Components;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class AdminControl : System.Web.UI.UserControl
    {
        #region Declaration

            int userid      = 0;            

        public string action = string.Empty;

        #endregion

        #region Method
        private void PageAdministration()
        {
            //Verify Website Edit 
            AdminUserDTO user = CookieHandler.GetAdminUser();
            if (user != null)
            {
                userid = user.UserID;                
            }
            else
            {
                this.Visible = false;
                userid = 0;                
            }

            if (userid == 0)
            {
                //Admin User Not Logged In
                this.Visible = false;
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PageAdministration();
            }
        }
        #endregion
    }
}