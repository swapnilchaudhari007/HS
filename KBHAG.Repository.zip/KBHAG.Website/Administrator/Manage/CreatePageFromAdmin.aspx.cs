﻿using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.Manage
{
    public partial class CreatePageFromAdmin : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method
        
        #endregion

        #region Event
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //renderControls();
            DynamicForm dynamicPage = new DynamicForm
            {
                FormHolder              = this.FormHolder,
                ControlHolder           = this.ControlHolder,
                ControlUniqueID         = "ctl00$MainPlaceHolder$",
                HiddenCallBackFunction  = this.hidden_CallBackFunction,
                FormDTO = Admin.FormDTO

            };
            dynamicPage.CreateForm();
        }

        protected void SubmitHandler(object sender, EventArgs e)
        {
            try
            {

                String title = "", metaTitle = "", metaDesc = "", metaKey = "", javaScript = "";
                int layoutID = 0, menuID = 0;

                List<String> dropdownList = new List<string>{ "ddl_Layout", "ddl_Menu" };
                foreach (var item in dropdownList)
                {
                    DropDownList ddl = (DropDownList)this.ControlHolder.FindControl(item);
                    switch (item)
                    {
                        case "ddl_Layout":
                            layoutID = Util.Parse<int>(ddl.SelectedValue);
                            break;

                        case "ddl_Menu":
                            menuID = Util.Parse<int>(ddl.SelectedValue);
                            break;
                    }                   
                    
                }

                TextBox txt = (TextBox)this.ControlHolder.FindControl("txt_Title");
                title = txt.Text;

                List<String> textAreaList = new List<string> { "txt_MetaTitle", "txt_MetaDesc", "txt_MetaKeyWord", "txt_JavaScript" };
                foreach (var item in textAreaList)
                {
                    TextBox txtArea = (TextBox)this.ControlHolder.FindControl(item);
                    switch (item)
                    {
                        case "txt_MetaTitle":
                            metaTitle = txtArea.Text;
                            break;

                        case "txt_MetaDesc":
                            metaDesc = txtArea.Text;
                            break;

                        case "txt_MetaKeyWord":
                            metaKey = txtArea.Text;
                            break;

                        case "txt_JavaScript":
                            javaScript = txtArea.Text;
                            break;
                    }
                }

                CMSPage pageDTO = new CMSPage                 
                {   
                    LayoutID        = layoutID,
                    MenuID          = menuID,
                    Title           = title,
                    MetaTitle       = metaTitle,
                    MetaDesc        = metaDesc,
                    MetaKeyWord     = metaKey,
                    JavaScript      = javaScript 
                };

                var repo = new PageRepository();
                int pageID = repo.AddPage(pageDTO);

                //Insert Data for Page Structure
                foreach (var item in repo.GetMapLayoutStructureByLayoutID(pageDTO.LayoutID))
                {
                    //Insert Record in CMS_PAGE_DATA
                    PageData pageData = new PageData
                    {
                        PageID          = pageID,
                        PageStructureID = item.PageStructureID,
                        Content         = item.DefaultContent
                    };
                    repo.AddPageData(pageData);
                }

                //Insert Data for Page Publish
                var pagePublish = repo.GetPublishPageByMenuID(pageDTO.MenuID);
                if (pagePublish == null)
                {
                    PagePublish pagePublishDTO = new PagePublish 
                    { 
                        MenuID = pageDTO.MenuID,
                        PageID  = pageID
                    };
                    repo.PublishPage(pagePublishDTO);
                }

                Response.Redirect(Page.ResolveUrl(Constants.ADMIN_DEFAULT_PAGE + "?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageID + "&action=v&message=a"));

            }
            catch (Exception ex)
            {
                DynamicForm dynamicPageForSubmit = new DynamicForm
                {
                    FormDTO         = Admin.FormDTO,
                    ControlHolder   = this.ControlHolder
                };

                dynamicPageForSubmit.ShowResponseMessage(Constants.MESSAGE_TYPE.error, "<br/>" + ex.ToString());
            }
        }

        protected void CancelHandler(object sender, EventArgs e)
        {
            Response.Redirect("~/administrator/index.aspx?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=v");
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}