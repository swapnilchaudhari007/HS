﻿using KBHAG.Components;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class AlbumListing : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method
        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.AddAlbum.Visible = true;
                //this.AddAlbum.HRef = Page.ResolveUrl("~/manage/AlbumManage.aspx?action=a&section=16&pageid=18&target=" + Constants.SLIDESHOW_TARGET_ALBUM + "&targetid=0&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT);
                this.AddAlbum.HRef = Page.ResolveUrl("~/manage/AlbumManage.aspx?action=a&section=applications&page=slide-show&target=" + Constants.SLIDESHOW_TARGET_ALBUM + "&targetid=0&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT);
            }
            else
            {
                this.AddAlbum.Visible = true;
                this.AddAlbum.HRef = "#";
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var repo = new ApplicationRepository();
                WebsiteHelpers.GenerateMetaTags(repo.GetApplicationByName(Constants.APP_Albums), this.MetaPlaceHolder);
                Authorized();

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_Albums);
            }
        }
        #endregion

        #region WebMethod

        #endregion
    }
}