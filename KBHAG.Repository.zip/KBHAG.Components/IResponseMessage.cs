﻿
namespace KBHAG.Components
{
    public interface IResponseMessage
    {
        Constants.MESSAGE_TYPE MessageType { get; set; }
        string Message { get; set; }
    }
}
