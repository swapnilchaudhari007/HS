﻿using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class photoupload : System.Web.UI.Page
    {
        #region Declaration
            public int ImageHeight          = 0;
            public int ImageWidth           = 0;
            public int GridWidth            = 0;
            public int GridHeight           = 0;
            public int MediaId              = 0;
            public string MediaField        = "";
            public string MediaScript       = "";
            public string MediaIsAlbum      = "n";
            public string FinalImageFolder  = Constants.IMAGE_FOLDER_PATH;
        #endregion

        #region Method
            private void AddBackEndCssFile()
            {
                List<string> CssFileList = new List<string> { "~/Style/bootstrap.min.css", "~/Style/bootstrap-responsive.min.css", "~/Style/ui-lightness/jquery-ui-1.10.0.custom.min.css", "~/Style/admin.css", "~/Style/admin-custom.css" };

                foreach (var item in CssFileList)
                {
                    Literal cssFile = new Literal() { Text = @"<link href=""" + Page.ResolveClientUrl(item) + @""" type=""text/css"" rel=""stylesheet"" />" };
                    this.MetaPlaceHolder.Controls.Add(cssFile);
                }
            }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            bool isWebsite = (Request.QueryString["iswebsite"] == null) ? false : Util.Parse<bool>(Request.QueryString["iswebsite"].ToString().ToLower());
            if (isWebsite)
            {
                AddBackEndCssFile();
            }


            MediaId = (Request.QueryString["mediaid"] == null) ? 0 : Util.Parse<int>(Request.QueryString["mediaid"].ToString().ToLower());
            MediaIsAlbum    = (String.IsNullOrEmpty(Request.QueryString["isalbum"])) ? "n" : Request.QueryString["isalbum"].ToString().ToLower();
            MediaField      = (String.IsNullOrEmpty(Request.QueryString["mediafield"])) ? "" : Request.QueryString["mediafield"].ToString();
            MediaScript     = (String.IsNullOrEmpty(Request.QueryString["mediascript"])) ? "" : Request.QueryString["mediascript"].ToString();

            this.cropimage.INTFRAMEHEIGHT   = Request.QueryString["gridheight"].ToString();
            this.cropimage.INTFRAMEWIDTH    = Request.QueryString["gridwidth"].ToString();
            this.cropimage.INTGLOBALHEIGHT  = Request.QueryString["imageheight"].ToString();
            this.cropimage.INTGLOBALWIDTH   = Request.QueryString["imagewidth"].ToString();

            if (MediaIsAlbum == "y")
                this.cropimage.ForceMinSize = false;
            else
                this.cropimage.ForceMinSize = true;

            this.cropimage.ActualImgPath    = Page.ResolveUrl("~/" + Constants.IMAGE_FOLDER_PATH);
            this.cropimage.TempFolderPath   = Page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH);
            this.cropimage.AjaxAspxPath     = Page.ResolveUrl("~/" + Constants.MEDIA_MANAGE_AJAX);
            this.cropimage.ProcessAshxPath  = Page.ResolveUrl("~/" + Constants.MEDIA_MANAGE_PROCESS);

            if (MediaIsAlbum != "y")
            {
                AlbumForm.Visible = false;
            }
        }
        #endregion

        #region WebMethod

        #endregion
    }
}