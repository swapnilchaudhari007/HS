﻿using KBHAG.Model;
using System.Collections.Generic;

namespace KBHAG.Repository
{
    public interface IMenuRepository
    {
        int GetMenuIDByAlliasName(string parent, string allias);
        int GetMenuIDForApp(string app, string allias);
        List<ViewMenu> GetLevel1Menu(int ParentMenu);
        List<ViewMenu> GetMenuByParentID(int parentid);
        int GetPublishPageID(int menuid);
    }
}
