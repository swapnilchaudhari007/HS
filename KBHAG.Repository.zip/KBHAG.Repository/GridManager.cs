﻿using KBHAG.Data;
using KBHAG.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data.Common;

namespace KBHAG.Repository
{
    public class GridManager
    {
        public int      nRows           { get; set; }
        public int      iPage           { get; set; }
        public string   sortColumnName  { get; set; }
        public string   sortOrder       { get; set; }
        public bool     isSearch        { get; set; }
        public string   filters         { get; set; }

        public string   gridModel       { get; set; }
        public string   primaryKey      { get; set; }
        public string[] columnName      { get; set; }
        public string   joinQuery       { get; set; }
        
        private List<string> ColumnNameList;
        private string SQLQuery = string.Empty;
        private bool isJoin = false;

        private readonly KBHAGContext context;

        public GridManager()
        {
            context = new KBHAGContext();
        }
        

        public Object GetGridDataForJqGrid()
        {
            ColumnNameList = new List<string>(columnName);

            isJoin = (!string.IsNullOrEmpty(joinQuery)) ? true : false;

            SQLQuery = "SELECT ";

            if (!isJoin)
            {
                SQLQuery += string.Join(", ", from item in ColumnNameList.AsEnumerable() select string.Concat("it.", item));              
            }
            else
            {
                SQLQuery += string.Join(", ", from item in ColumnNameList.AsEnumerable() select item);            
            }            
            
            SQLQuery += " FROM " + gridModel + "s AS it";

            var f = (!isSearch || string.IsNullOrEmpty(filters)) ? null : JsonConvert.DeserializeObject<Filters>(filters);
            
            var objectContext       = ((IObjectContextAdapter)context).ObjectContext;
            dynamic dynamicModel    = DynamicHelpers.GetTypeFromName(RepositoryConstants.MODEL_ASSEMBLY_NAME, gridModel);
            var type                = DynamicHelpers.GetTypeFromName(RepositoryConstants.MODEL_ASSEMBLY_NAME, gridModel);
            var method              = objectContext.GetType().GetMethod("CreateObjectSet", Type.EmptyTypes);
            var generic             = method.MakeGenericMethod(type);
            dynamic set             = generic.Invoke(objectContext, null);

            ObjectQuery<DbDataRecord> filteredQuery = null;

            if (f == null)
            {
                filteredQuery = objectContext.CreateQuery<DbDataRecord>(SQLQuery);

                if (isJoin)
                {
                    var queryJoin = filteredQuery.CommandText + " " + joinQuery;
                    filteredQuery = objectContext.CreateQuery<DbDataRecord>(queryJoin);    
                }                
            }
            else
            {
                filteredQuery = f.FilterObjectSet(set, objectContext, SQLQuery, isJoin, joinQuery);
            }                          
            
            
            filteredQuery.MergeOption = MergeOption.NoTracking;

            var totalRecords = filteredQuery.Count();
            
                       
            var pagedQuery =
                                filteredQuery.Skip(
                                    (!isJoin) ? "it." + (String.IsNullOrEmpty(sortColumnName) ? "Id" : sortColumnName) + " " + sortOrder : (String.IsNullOrEmpty(sortColumnName) ? "it.Id" : sortColumnName) + " " + sortOrder,
                                    "@skip",
                                    new ObjectParameter("skip", (iPage - 1) * nRows))
                                    .Top("@limit", new ObjectParameter("limit", nRows));            

            return new
            {
                totalpages      = (totalRecords + nRows - 1) / nRows,
                page            = iPage,
                totalrecords    = totalRecords,
                rows            = (
                                    from row in pagedQuery.AsEnumerable()
                                    select new
                                    {
                                        i = GetPrimaryKeyValue(row),
                                        cell = GetRowCellArray(row)
                                    }
                                  ).ToArray()
            };

            
        }

        private int GetPrimaryKeyValue(DbDataRecord row)
        {
            int primaryKeyValue = 0;

            string columnName = (isJoin) ? Convert.ToString(primaryKey.Split('.')[1]) : primaryKey;

            Type ClassType = DynamicHelpers.GetTypeFromName(RepositoryConstants.MODEL_ASSEMBLY_NAME, gridModel);
            PropertyInfo pInfo = ClassType.GetProperty(columnName);
            switch (pInfo.PropertyType.FullName)
            {
                case "System.Decimal": //numeric(18,2)
                    primaryKeyValue = Convert.ToInt32(row.GetDecimal(row.GetOrdinal(columnName)));
                    break;

                case "System.Int32":  // int
                    primaryKeyValue = row.GetInt32(row.GetOrdinal(columnName));
                    break;

                default:
                    primaryKeyValue = 0;
                    break;
            }

            return primaryKeyValue;
        }

        private string[] GetRowCellArray(DbDataRecord row)
        {
            List<string> strList = new List<string>();

            Type ClassType = DynamicHelpers.GetTypeFromName(RepositoryConstants.MODEL_ASSEMBLY_NAME, gridModel);

            foreach (var item in ColumnNameList)
            {

                string columnName = (isJoin) ? Convert.ToString(item.Split('.')[1]) : item;

                PropertyInfo pInfo = ClassType.GetProperty(columnName);
                
                if (pInfo ==  null)
                {
                    strList.Add(row.GetString(row.GetOrdinal(columnName)).ToString());
                    continue;
                }

                switch (pInfo.PropertyType.FullName)
                {
                    case "System.Int32":  // int
                        strList.Add(row.GetInt32(row.GetOrdinal(columnName)).ToString());                        
                        break;
                    case "System.Int64":  // bigint
                        strList.Add(row.GetInt64(row.GetOrdinal(columnName)).ToString());                                                
                        break;
                    case "System.Int16":  // smallint
                        strList.Add(row.GetInt16(row.GetOrdinal(columnName)).ToString());                        
                        break;
                    case "System.SByte":  // tinyint
                        strList.Add(row.GetInt32(row.GetOrdinal(columnName)).ToString());                  
                        break;
                    case "System.Single": // Edm.Single, in SQL: float
                        strList.Add(row.GetFloat(row.GetOrdinal(columnName)).ToString());                                          
                        break;
                    case "System.Double": // float(53), double precision
                        strList.Add(row.GetDouble(row.GetOrdinal(columnName)).ToString());    
                        break;
                    case "System.Decimal": //numeric(18,2)
                        strList.Add(row.GetDecimal(row.GetOrdinal(columnName)).ToString());  
                        break;
                    case "System.Boolean": // Edm.Boolean, in SQL: bit
                        strList.Add(row.GetBoolean(row.GetOrdinal(columnName)).ToString());                          
                        break;
                    case "System.Nullable`1[[System.DateTime, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]":
                        strList.Add(row.GetDateTime(row.GetOrdinal(columnName)).ToString());                                                  
                        break;
                    default:
                        // TODO: Extend to other data types
                        // binary, date, datetimeoffset,
                        // decimal, numeric,
                        // money, smallmoney
                        // and so on
                        if (String.Compare(pInfo.PropertyType.FullName, typeof(DateTime?).FullName, StringComparison.Ordinal) == 0 ||
                            String.Compare(pInfo.PropertyType.FullName, typeof(DateTime).FullName, StringComparison.Ordinal) == 0)
                        {
                            // we use below en-US locale directly
                            strList.Add(row.GetDateTime(row.GetOrdinal(columnName)).ToString());     
                        }
                        else
                        {
                            strList.Add(row.GetString(row.GetOrdinal(columnName)).ToString());     
                        }
                        break;                    
                }
            }
            return strList.ToArray();
        }
    }

    public class Filters
    {
        // ReSharper disable InconsistentNaming
        public enum GroupOp
        {
            AND,
            OR
        }
        public enum Operations
        {
            eq, // "equal"
            ne, // "not equal"
            lt, // "less"
            le, // "less or equal"
            gt, // "greater"
            ge, // "greater or equal"
            bw, // "begins with"
            bn, // "does not begin with"
            //in, // "in"
            //ni, // "not in"
            ew, // "ends with"
            en, // "does not end with"
            cn, // "contains"
            nc  // "does not contain"
        }
        public class Rule
        {
            public string field { get; set; }
            public Operations op { get; set; }
            public string data { get; set; }
        }

        public GroupOp groupOp { get; set; }
        public List<Rule> rules { get; set; }
        // ReSharper restore InconsistentNaming
        private static readonly string[] FormatMapping = {
                "(it.{0} = @p{1})",                 // "eq" - equal
                "(it.{0} <> @p{1})",                // "ne" - not equal
                "(it.{0} < @p{1})",                 // "lt" - less than
                "(it.{0} <= @p{1})",                // "le" - less than or equal to
                "(it.{0} > @p{1})",                 // "gt" - greater than
                "(it.{0} >= @p{1})",                // "ge" - greater than or equal to
                "(it.{0} LIKE (@p{1}+'%'))",        // "bw" - begins with
                "(it.{0} NOT LIKE (@p{1}+'%'))",    // "bn" - does not begin with
                "(it.{0} LIKE ('%'+@p{1}))",        // "ew" - ends with
                "(it.{0} NOT LIKE ('%'+@p{1}))",    // "en" - does not end with
                "(it.{0} LIKE ('%'+@p{1}+'%'))",    // "cn" - contains
                "(it.{0} NOT LIKE ('%'+@p{1}+'%'))" //" nc" - does not contain
            };

        private static readonly string[] FormatMappingWithoutAllias = {
                "({0} = @p{1})",                 // "eq" - equal
                "({0} <> @p{1})",                // "ne" - not equal
                "({0} < @p{1})",                 // "lt" - less than
                "({0} <= @p{1})",                // "le" - less than or equal to
                "({0} > @p{1})",                 // "gt" - greater than
                "({0} >= @p{1})",                // "ge" - greater than or equal to
                "({0} LIKE (@p{1}+'%'))",        // "bw" - begins with
                "({0} NOT LIKE (@p{1}+'%'))",    // "bn" - does not begin with
                "({0} LIKE ('%'+@p{1}))",        // "ew" - ends with
                "({0} NOT LIKE ('%'+@p{1}))",    // "en" - does not end with
                "({0} LIKE ('%'+@p{1}+'%'))",    // "cn" - contains
                "({0} NOT LIKE ('%'+@p{1}+'%'))" //" nc" - does not contain
            };

        internal ObjectQuery<DbDataRecord> FilterObjectSet<T>(ObjectQuery<T> inputQuery, ObjectContext objectContext, string query, bool isJoin, string joinQuery) where T : class
        {
            var sb = new StringBuilder();
            var objParams = new List<ObjectParameter>(rules.Count);

            foreach (var rule in rules)
            {
                string field = (!isJoin) ? rule.field : rule.field.Split('.')[1];
                var propertyInfo = typeof(T).GetProperty(field);                

                if (sb.Length != 0)
                    sb.Append(groupOp);

                var iParam = objParams.Count;

                if (!isJoin)
                {
                    sb.AppendFormat(FormatMapping[(int)rule.op], rule.field, iParam);                      
                }
                else
                {                     
                    sb.AppendFormat(FormatMappingWithoutAllias[(int)rule.op], rule.field, iParam);
                }
                

                ObjectParameter param;

                if (propertyInfo == null)
                {
                    param = new ObjectParameter("p" + iParam, rule.data);
                    
                }
                else
                {
                    switch (propertyInfo.PropertyType.FullName)
                    {
                        case "System.Int32":  // int
                            param = new ObjectParameter("p" + iParam, Int32.Parse(rule.data));
                            break;
                        case "System.Int64":  // bigint
                            param = new ObjectParameter("p" + iParam, Int64.Parse(rule.data));
                            break;
                        case "System.Int16":  // smallint
                            param = new ObjectParameter("p" + iParam, Int16.Parse(rule.data));
                            break;
                        case "System.SByte":  // tinyint
                            param = new ObjectParameter("p" + iParam, SByte.Parse(rule.data));
                            break;
                        case "System.Single": // Edm.Single, in SQL: float
                            param = new ObjectParameter("p" + iParam, Single.Parse(rule.data));
                            break;
                        case "System.Double": // float(53), double precision
                            param = new ObjectParameter("p" + iParam, Double.Parse(rule.data));
                            break;
                        case "System.Decimal": //numeric(18,2)
                            param = new ObjectParameter("p" + iParam, Decimal.Parse(rule.data));
                            break;
                        case "System.Boolean": // Edm.Boolean, in SQL: bit
                            param = new ObjectParameter("p" + iParam,
                                String.Compare(rule.data, "1", StringComparison.Ordinal) == 0 ||
                                String.Compare(rule.data, "yes", StringComparison.OrdinalIgnoreCase) == 0 ||
                                String.Compare(rule.data, "true", StringComparison.OrdinalIgnoreCase) == 0);
                            break;
                        case "System.Nullable`1[[System.DateTime, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]":
                            var dt = DateTime.Parse(rule.data, new CultureInfo("en-US"), DateTimeStyles.None);
                            param = new ObjectParameter("p" + iParam, dt);
                            break;
                        default:
                            // TODO: Extend to other data types
                            // binary, date, datetimeoffset,
                            // decimal, numeric,
                            // money, smallmoney
                            // and so on
                            if (String.Compare(propertyInfo.PropertyType.FullName, typeof(DateTime?).FullName, StringComparison.Ordinal) == 0 ||
                                String.Compare(propertyInfo.PropertyType.FullName, typeof(DateTime).FullName, StringComparison.Ordinal) == 0)
                            {
                                // we use below en-US locale directly
                                param = new ObjectParameter("p" + iParam, DateTime.Parse(rule.data, new CultureInfo("en-US"), DateTimeStyles.None));
                            }
                            else
                            {
                                param = new ObjectParameter("p" + iParam, rule.data);
                            }
                            break;
                    }
                }
                
                objParams.Add(param);
            }

            string SqlQuery = (!isJoin) ? query + " WHERE " + sb.ToString() : query;

            var filteredQuery = objectContext.CreateQuery<DbDataRecord>(SqlQuery);

            if (isJoin)
            {
                var queryJoin = filteredQuery.CommandText + " " + joinQuery;
                filteredQuery = objectContext.CreateQuery<DbDataRecord>(queryJoin + " WHERE " + sb.ToString());
            }            

            foreach (var objParam in objParams)
                filteredQuery.Parameters.Add(objParam);

            return filteredQuery;
        }
    }
}
