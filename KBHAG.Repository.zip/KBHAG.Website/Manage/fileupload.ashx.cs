﻿using KBHAG.Components;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;

namespace KBHAG.Website.Manage
{
    /// <summary>
    /// Summary description for fileupload
    /// </summary>
    public class fileupload : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            String filename = (HttpContext.Current.Request.Headers["X-File-Name"] == null) ? "" : HttpContext.Current.Request.Headers["X-File-Name"];
            String ResponseString = "";

            if (string.IsNullOrEmpty(filename) && HttpContext.Current.Request.Files.Count <= 0)
            {
                context.Response.Write("{success:false}");
            }
            else
            {
                try
                {
                    string mapPath = HttpContext.Current.Server.MapPath("~/" + Constants.TEMP_IMAGE_FOLDER_PATH);
                    string physicalFilePath = string.Empty;
                    //string newFlv = "";
                    string physicalFile = string.Empty;
                    string AddToReponse = string.Empty;

                    if (!Directory.Exists(mapPath))
                        Directory.CreateDirectory(mapPath);

                    if (string.IsNullOrEmpty(filename))//This work for IE
                    {
                        HttpPostedFile uploadedfile = context.Request.Files[0];
                        filename = WebsiteHelpers.FormatUploadedFile(uploadedfile.FileName);
                        physicalFile = WebsiteHelpers.UniqueFilename(filename, mapPath);
                        physicalFilePath = mapPath + physicalFile;
                        AddToReponse = CheckImage(uploadedfile.InputStream);
                        uploadedfile.SaveAs(physicalFilePath);

                        if (File.Exists(physicalFilePath))
                        {
                            ResponseString = "{success:true, name:\"" + physicalFile + "\","
                                    + "path:\"" + "/" + Constants.TEMP_IMAGE_FOLDER_PATH + physicalFile + "\""
                                    + "," + AddToReponse
                                    + "}";
                        }
                        else
                        {
                            ResponseString = "{success:false, message:\" File did not upload correctly on the server, please try again.\"}";
                        }
                    }
                    else //this work for firefox and chrome.
                    {
                        physicalFile = WebsiteHelpers.UniqueFilename(filename, mapPath);
                        physicalFilePath = mapPath + physicalFile;
                        //phyicalFilePath = mapPath + "\\" + filename;
                        //FileStream filestream = new FileStream(physicalFilePath, FileMode.OpenOrCreate);

                        Stream inputstream = HttpContext.Current.Request.InputStream;
                        AddToReponse = CheckImage(inputstream);
                        WebsiteHelpers.SaveStreamAsBitmap(inputstream, physicalFilePath);

                        //filestream.Close();

                        if (File.Exists(physicalFilePath))
                        {
                            ResponseString = "{success:true, name:\"" + physicalFile + "\","
                                    + "path:\"" + "/" +  Constants.TEMP_IMAGE_FOLDER_PATH + physicalFile + "\""
                                    + "," + AddToReponse
                                    + "}";
                        }
                        else
                        {
                            ResponseString = "{success:false, message:\" file did not upload correctly on the server, please try again.\"}";
                        }
                    }

                }
                catch (Exception e)
                {
                    ResponseString = "{success:false, message:\"" + e.Message + "," + e.InnerException + "\"}";
                }

                context.Response.Write(ResponseString);
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private string CheckImage(Stream FileStream)
        {
            Bitmap bmpThumbImage = new Bitmap(FileStream);
            //string isValidAttribute = ((imageWidth >= bmpThumbImage.Width) && (imageHeight >= bmpThumbImage.Height)) ? "true" : "false";
            string strReturn = "ImageWidth:\"" + bmpThumbImage.Width + "\", ImageHeight:\"" + bmpThumbImage.Height + "\"";
            bmpThumbImage.Dispose();
            return strReturn;
        }

    }
}