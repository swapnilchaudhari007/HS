﻿using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class Inquiry : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method
        private void PrepareForm()
        {
            var uow = new KBHAGUnitOfWork();
            dynamic repo = DynamicHelpers.GetGenericRepository(RepositoryConstants.MODEL_ASSEMBLY_NAME, "EventType");
            repo.UnitOfWork = uow;
            dynamic data = repo.GetAll();

            this.ddlType.DataSource     = data;
            this.ddlType.DataTextField = "EventTypeName";
            this.ddlType.DataValueField = "EventTypeID";
            this.ddlType.DataBind();
            this.ddlType.Items.Insert(0, "---- Select ----");
            this.ddlType.Items[0].Value = "0";
        }

        protected void ShowMessage(string message,string type = "")
        {
            this.MessageHolder.Visible = true;
            this.MessageHolder.InnerHtml = message;

            if (!String.IsNullOrEmpty(type))
            {
                //success
            }
            else
            {
                //error
            }
        }

        protected void Clear()
        { 
            
        }
        

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PrepareForm();
            }
        }

        protected void SubmitHandler(object sender, EventArgs e)
        {
            if (this.ddlType.SelectedIndex == 0)
            {
                ShowMessage("Inquiry Type is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtPartyName.Text))
            {
                ShowMessage("Party Name is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtApplicantName.Text))
            {
                ShowMessage("Applicant Name is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtMobilNo.Text))
            {
                ShowMessage("Mobile No. is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtEmail.Text))
            {
                ShowMessage("Email is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtCity.Text))
            {
                ShowMessage("City Name is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtDate.Text))
            {
                ShowMessage("Event Date is required");
                return;
            }

            if (String.IsNullOrEmpty(this.txtMessage.Text))
            {
                ShowMessage("Event Details is required");
                return;
            }

            try
            {
                var repo = new ApplicationRepository();

               Model.Inquiry inquiry = new Model.Inquiry {
                   TypeID           = Util.Parse<int>(this.ddlType.SelectedValue),
                   TypeName         = this.ddlType.SelectedItem.Text,
                   PartyName        = this.txtPartyName.Text,
                   ApplicantName    = this.txtApplicantName.Text,
                   MobileNo         = this.txtMobilNo.Text,
                   ContactNo        = this.txtContactNo.Text,
                   EmailID          = this.txtEmail.Text,
                   Address          = this.txtAddress.Text,
                   City             = this.txtCity.Text,
                   EventDate        = this.txtDate.Text,
                   Message          = this.txtMessage.Text,
                   LogDate          = DateTime.Now
                };

               repo.AddInquiry(inquiry);

               ShowMessage(Constants.SUCCESS_MESSAGE, "success");

            }
            catch (Exception ex)
            {
                ShowMessage(Constants.ERROR_LONG_MESSAGE + "<br/>" + ex.ToString());
            }

        }

        protected void CancelHandler(object sender, EventArgs e) 
        { }
        #endregion

        #region WebMethod

        #endregion
                
    }
}