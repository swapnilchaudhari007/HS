﻿using KBHAG.Components;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        
        #region Declaration
            public static AdminUserDTO UserDTO { get; set; }
            public static FormDTO FormDTO { get; set; }
        #endregion

        #region Method

        #endregion

        #region Event

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            UserDTO = CookieHandler.GetAdminUser();

            if (UserDTO == null)
                Response.Redirect(Page.ResolveUrl(Constants.ADMIN_LOGIN_PAGE));

            this.lblUserName.Text = UserDTO.UserName;

            //QueryString
            FormDTO = new FormDTO();
            if (Request.QueryString["page"] != null)
            {
                FormDTO.PageAllias = (!String.IsNullOrEmpty(Request.QueryString["page"])) ? Util.Parse<string>(Request.QueryString["page"]) : string.Empty;
                var repo = new Repository.PageRepository();
                var page = repo.GetFormPageByAllias(WebsiteHelpers.GetStringFromSanitizeURL(FormDTO.PageAllias));
                if (page != null)
                {
                    FormDTO.PageID = page.PageID;
                }
            }                

            if (Request.QueryString["action"] != null)
                FormDTO.Action = (!String.IsNullOrEmpty(Request.QueryString["action"])) ? Util.Parse<string>(Request.QueryString["action"]).ToLower() : string.Empty;

            if (Request.QueryString["section"] != null)
                FormDTO.Section = (!String.IsNullOrEmpty(Request.QueryString["section"])) ? Util.Parse<string>(Request.QueryString["section"]).ToLower() : string.Empty;

            if (Request.QueryString["message"] != null)
                FormDTO.Message = (!String.IsNullOrEmpty(Request.QueryString["message"])) ? Util.Parse<string>(Request.QueryString["message"]).ToLower() : string.Empty;

            if (Request.QueryString["id"] != null)
                FormDTO.ReferenceID = (!String.IsNullOrEmpty(Request.QueryString["id"])) ? Util.Parse<int>(Request.QueryString["id"]) : 0;
            
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LogOut(object sender, EventArgs e)
        {
            CookieHandler.KillAdminCookie();
            Response.Redirect(Constants.ABSOLUTE_PATH + "default.aspx");
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}