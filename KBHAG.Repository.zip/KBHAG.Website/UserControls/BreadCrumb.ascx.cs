﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using KBHAG.Model;
using KBHAG.Components;

namespace KBHAG.Website
{
    public partial class BreadCrumb : System.Web.UI.UserControl
    {
        #region Declaration
        public List<BreadCrumbDTO> BCDTO {get; set;}
        public List<BreadCrumbDTO> AddToEnd { get; set; }
        #endregion

        #region Method
            public void CreateBreadCrumb()
            {
                string strBc = "";
                if (BCDTO == null)
                    return;

                strBc += "<a href='" + Page.ResolveUrl("~/") + "'>Home</a>";
                foreach (BreadCrumbDTO item in BCDTO)
                {
                    if (!string.IsNullOrEmpty(item.LinkUrl))
                    {
                        strBc += "&nbsp;>>&nbsp;";
                        strBc += "<a href='" + item.LinkUrl + "'>" + item.LinkName + "</a>";
                    }
                    else
                    {
                        strBc += item.LinkUrl;
                    }
                }

                if (AddToEnd != null && AddToEnd.Count > 0)
                {
                    foreach (BreadCrumbDTO aitem in AddToEnd)
                    {
                        strBc += "&nbsp;>>&nbsp;";
                        strBc += "<a href='" + aitem.LinkUrl + "'>" + aitem.LinkName + "</a>";
                    }
                }

                bread_crumb.InnerHtml = strBc;

                //cmenu       = repoMenu.GetMenuByAlliasName(0, level0);
                //if (cmenu != null)
                //{
                //    bcList.Add(new BreadCrumbDTO
                //    {
                //        LinkName = cmenu.Title,
                //        LinkUrl = Page.ResolveUrl("~/" + cmenu.ParentUrl)
                //    });
                //    level0id = cmenu.MenuID;
                //}

            }

            public void HideBreadCrumb()
            {
                bread_crumb.Visible = false;
            }
        #endregion

        #region Events
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                CreateBreadCrumb();
        }
        #endregion
        
    }
}