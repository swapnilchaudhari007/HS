﻿using KBHAG.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Reflection;
using System.Text;

namespace KBHAG.Repository
{
    public class DataManager
    {
        public Dictionary<string, string> ColumnsList { get; set; }
        public int ID           { get; set; }
        public string Action    { get; set; }
        public string Model     { get; set; }

        public List<string> ValidateColumn { get; set; }
        public string PrimaryKeyColumnName { get; set; }

        protected enum Message
        {
            success,
            error,
            exists
        }

        public string Manage()
        {
            string returnMessage = Message.success.ToString();
            
            Type model = DynamicHelpers.GetTypeFromName(RepositoryConstants.MODEL_ASSEMBLY_NAME, Model);
            dynamic instance = Activator.CreateInstance(model);

            foreach (var item in ColumnsList)
            {
                PropertyInfo pInfo = model.GetProperty(item.Key);

                switch (pInfo.PropertyType.FullName)
                {
                    case "System.Int32":  // int                        
                        pInfo.SetValue(instance,RepositoryUtil.Parse<Int32>(item.Value), null);
                        break;
                    case "System.Int64":  // bigint
                        pInfo.SetValue(instance, RepositoryUtil.Parse<Int64>(item.Value), null);                        
                        break;
                    case "System.Int16":  // smallint
                        pInfo.SetValue(instance, RepositoryUtil.Parse<Int16>(item.Value), null);                        
                        break;
                    case "System.SByte":  // tinyint                        
                        pInfo.SetValue(instance, RepositoryUtil.Parse<int>(item.Value), null);
                        break;
                    case "System.Single": // Edm.Single, in SQL: float
                        pInfo.SetValue(instance, RepositoryUtil.Parse<float>(item.Value), null);                        
                        break;
                    case "System.Double": // float(53), double precision
                        pInfo.SetValue(instance, RepositoryUtil.Parse<double>(item.Value), null);                        
                        break;
                    case "System.Decimal": //numeric(18,2)
                        pInfo.SetValue(instance, RepositoryUtil.Parse<decimal>(item.Value), null);
                        break;
                    case "System.Boolean": // Edm.Boolean, in SQL: bit
                        pInfo.SetValue(instance, RepositoryUtil.Parse<bool>(item.Value), null);
                        break;
                    case "System.Nullable`1[[System.DateTime, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]":
                        pInfo.SetValue(instance, RepositoryUtil.Parse<DateTime>(item.Value), null);
                        break;
                    default:
                        // TODO: Extend to other data types
                        // binary, date, datetimeoffset,
                        // decimal, numeric,
                        // money, smallmoney
                        // and so on
                        if (String.Compare(pInfo.PropertyType.FullName, typeof(DateTime?).FullName, StringComparison.Ordinal) == 0 ||
                            String.Compare(pInfo.PropertyType.FullName, typeof(DateTime).FullName, StringComparison.Ordinal) == 0)
                        {
                            // we use below en-US locale directly
                            pInfo.SetValue(instance, RepositoryUtil.Parse<DateTime>(item.Value), null);
                        }
                        else
                        {
                            pInfo.SetValue(instance, RepositoryUtil.Parse<string>(item.Value), null);
                        }
                        break;
                }                
            }

            KBHAGUnitOfWork uow = new KBHAGUnitOfWork();
            dynamic repo = DynamicHelpers.GetGenericRepository(RepositoryConstants.MODEL_ASSEMBLY_NAME, Model);
            repo.UnitOfWork = uow;

            //Validation for record exists
            bool isValid = true;
                        
            StringBuilder sb = new StringBuilder();
            foreach (var itemForQuery in ValidateColumn)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" AND ");
                }

                sb.Append(String.Concat(itemForQuery, " = ", GetValueforQuery(instance, itemForQuery)));
            }

            if (Action == "e" && !String.IsNullOrEmpty(sb.ToString()))
            {
                sb.Append(String.Concat(" AND ", (PrimaryKeyColumnName), " != ", GetValueforQuery(instance,PrimaryKeyColumnName)));
            }

            if (!String.IsNullOrEmpty(sb.ToString()))
            {
                var data = repo.GetByString(sb.ToString());
                isValid = (data != null) ? false : true;
            }                        

            if (Action == "a")
            {
                if (isValid)
                {
                    repo.Add(instance);    
                }
                else
                {
                    returnMessage = Message.exists.ToString();
                }
                
            }
            else if (Action == "e")
            {
                if (isValid)
                {
                    repo.Update(instance);    
                }
                else
                {
                    returnMessage = Message.exists.ToString();
                }                
            }

            else if (Action == "d")
            {
                repo.Delete(instance);
            }

            else
            {
                //not implemented
            }

            uow.Commit();

            return returnMessage;
        }

        private string GetValueforQuery(dynamic o, string columnName)
        {
            string strValue = string.Empty;

            string dataType = o.GetType().GetProperty(columnName).PropertyType.FullName;

            if (dataType == "System.String")
            {
                strValue = String.Concat("\"" + o.GetType().GetProperty(columnName).GetValue(o, null) + "\"");
            }
            else
            {
                strValue = RepositoryUtil.Parse<string>(o.GetType().GetProperty(columnName).GetValue(o, null));
            }
            return strValue;
        }
    }    
}
