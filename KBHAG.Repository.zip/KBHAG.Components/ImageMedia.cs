﻿using System;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;


namespace KBHAG.Components
{
    public class ImageMedia
    {
        private BitmapSource _source;
        private byte[] _data;
        private string _copyright;

        public int Width { get { return _source.PixelWidth; } }
        public int Height { get { return _source.PixelHeight; } }
        public string Copyright { get { return _copyright; } }

        public ImageMedia Resize(int? width, int? height)
        {
            if (width == null && height == null)
                return this;

            width = width ?? _source.PixelWidth;
            height = height ?? _source.PixelHeight;
            double scale = Math.Min(width.Value / (double)_source.PixelWidth, height.Value / (double)_source.PixelHeight);
            if (scale >= 1)
                return this;

            _source = new TransformedBitmap(_source, new ScaleTransform(scale, scale, 0, 0));
            _data = null;
            return this;
        }

        public ImageMedia Crop(int? width, int? height)
        {
            if ((width == null && height == null) || (width >= _source.PixelWidth && height >= _source.PixelHeight))
                return this;

            width = Math.Min(width ?? _source.PixelWidth, _source.PixelWidth);
            height = Math.Min(_source.PixelHeight, (height ?? _source.PixelHeight));
            double scale = Math.Max(width.Value / (double)_source.PixelWidth, height.Value / (double)_source.PixelHeight);
            if (scale < 1)
                _source = new TransformedBitmap(_source, new ScaleTransform(scale, scale, 0, 0));

            double marginX = (_source.PixelWidth - width.Value) / 2;
            double marginY = (_source.PixelHeight - height.Value) / 2;

            _source = new CroppedBitmap(_source, new System.Windows.Int32Rect((int)marginX, (int)marginY, width.Value, height.Value));
            _data = null;
            return this;
        }

        public byte[] ToByteArray()
        {
            return ToByteArray("jpg");
        }

        public byte[] ToByteArray(string format)
        {
            //if image not altered return orig data
            if (_data != null)
                return _data;

            //placed in a thread set to STA to overcome 0xC0000005 thrown in encoder.Save
            if (!String.IsNullOrEmpty(Copyright))
            {
                byte[] data = null;
                System.Threading.Thread worker = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(delegate(object obj)
                {
                    BitmapEncoder encoder = GetEncoder(format);
                    try
                    {
                        BitmapMetadata meta = new BitmapMetadata(format);
                        meta.Copyright = Copyright;
                        encoder.Frames.Insert(0, BitmapFrame.Create(_source, null, meta, null)); //using insert because we're getting error about IList not containing Add method
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            encoder.Save(memoryStream);
                            data = memoryStream.ToArray();
                        }
                    }
                    catch (NotSupportedException) { } //specified format does not support copyright metadata
                }));
                worker.SetApartmentState(System.Threading.ApartmentState.STA);
                worker.Start();
                worker.Join();
                if (data != null)
                    return data;
            }

            BitmapEncoder targetEncoder = GetEncoder(format);
            targetEncoder.Frames.Add(BitmapFrame.Create(_source));
            using (MemoryStream memoryStream = new MemoryStream())
            {
                targetEncoder.Save(memoryStream);
                return memoryStream.ToArray();
            }
        }

        private BitmapEncoder GetEncoder(string format)
        {
            if (format == "jpg")
            {
                JpegBitmapEncoder res = new JpegBitmapEncoder();
                res.QualityLevel = 85;
                return res;
            }
            if (format == "png")
                return new PngBitmapEncoder();
            if (format == "gif")
                return new GifBitmapEncoder();
            if (format == "tiff")
                return new TiffBitmapEncoder();
            if (format == "jxr")
                return new WmpBitmapEncoder();
            if (format == "bmp")
                return new BmpBitmapEncoder();
            throw new Exception("Unrecognised image format: " + format);
        }

        public static ImageMedia Create(byte[] data)
        {
            ImageMedia result = new ImageMedia();
            result._source = BitmapDecoder.Create(new MemoryStream(data), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.None).Frames[0];
            result._data = data;
            try { result._copyright = ((BitmapMetadata)result._source.Metadata).Copyright; }
            catch (Exception) { }
            return result;
        }
    }
}
