﻿using KBHAG.Data;
using KBHAG.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.UserControls
{
    public partial class PageHeaderControl : System.Web.UI.UserControl
    {
        #region Declaration
            public string PageHeading   = string.Empty;
            public string PageDesc      = string.Empty;
                   string redirectURL   = string.Empty;
        #endregion

        #region Method

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            
                using (KBHAGUnitOfWork uow = new KBHAGUnitOfWork())
                {
                    var repo = new GenericRepository<FormPage>();
                    repo.UnitOfWork = uow;

                    var page = repo.GetById(Admin.FormDTO.PageID);

                    if (page != null)
                    {
                        this.PageHeading = page.Title;
                        this.PageDesc = page.Desc;

                        GridControl.GridHeading = page.Title;

                        var grid = JsonConvert.DeserializeObject<dynamic>(page.Grid);
                        if (grid != null)
                        {
                            GridControl.GridModel           = grid.Model;
                            GridControl.GridPKID            = grid.PKID;
                            GridControl.GridColumnName      = grid.ColumnName;
                            GridControl.GridColumnHeading   = grid.ColumnHeading;
                            GridControl.GridColumnModel     = grid.ColumnModel;
                            GridControl.GridJoinQuery       = (grid.JoinTableQuery != null) ? grid.JoinTableQuery : string.Empty;
                            if (grid.RedirectURL != null)
                            {
                                redirectURL = grid.RedirectURL;
                                GridControl.GridRedirectURL = Page.ResolveClientUrl("~/" + grid.RedirectURL + "e&id=");
                            }
                            else
                            {
                                GridControl.GridRedirectURL = Page.ResolveClientUrl("~/administrator/index.aspx?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=e&id=");
                            }                            
                        }
                        else
                        {
                            GridControl.GridModel           = string.Empty;
                            GridControl.GridPKID            = string.Empty;
                            GridControl.GridColumnName      = "[]";
                            GridControl.GridColumnHeading   = "[]";
                            GridControl.GridColumnModel     = "[]";
                            GridControl.GridJoinQuery       = string.Empty;
                        }

                        var submit = JsonConvert.DeserializeObject<dynamic>(page.Callback);
                        if (submit != null)
                        {
                            if (submit.AllowSubmit != null)
                            {
                                bool isSubmitAllow = KBHAG.Components.Util.Parse<bool>(submit.AllowSubmit.Submit);
                                if (!isSubmitAllow)
                                {
                                    this.lnkNew.Visible = false;
                                }
                            }

                            if (submit.InsertURL != null)
                            {
                                string url = submit.InsertURL;
                                redirectURL = Page.ResolveUrl("~/" + url + "?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=a");
                            }

                        }
                    }
                }

            }
            
        }

        protected void AddClickHandler(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(redirectURL))
            {
                Response.Redirect(redirectURL);
            }
            else
            {
                Response.Redirect(String.Concat("index.aspx?section=", Admin.FormDTO.Section, "&page=", Admin.FormDTO.PageAllias) + "&action=a");
            }            
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}