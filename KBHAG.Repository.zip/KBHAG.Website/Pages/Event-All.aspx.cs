﻿using KBHAG.Components;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using KBHAG.Repository;
using System.Data.Objects;


namespace KBHAG.Website
{
    public partial class Event_All : System.Web.UI.Page
    {
        
        #region Declaration
        string EventType = "";
        string EventTense = "";
        #endregion

        #region Method
        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.AddEvent.Visible = true;
                this.AddEvent.HRef = Page.ResolveUrl("~/administrator/index.aspx?section=applications&page=event&action=a");
                this.lnkFeatured.Visible = true;
                
            }
        }

        public string ChangeDate(string cdate, string dtype)
        {
            DateTime dt = DateTime.Parse(cdate);
            return WebsiteHelpers.SubScriptDate(dt, dtype);
        }

        private void ShowFeatured()
        {
            var repo = new ApplicationRepository();
            var feat = repo.GetFeaturedEventByAlias(EventType);
            if (feat != null)
            {
                h2Title.InnerText = Convert.ToString(feat.Title);
                h3SubTitle.InnerText = Convert.ToString(feat.SubTitle);
                if (feat.StartDate.Date == feat.EndDate.Date)
                    lblFeaturedDate.Text = WebsiteHelpers.SubScriptDate(feat.StartDate, "DF");
                else
                    lblFeaturedDate.Text = WebsiteHelpers.SubScriptDate(feat.StartDate, "DF") + " to " + WebsiteHelpers.SubScriptDate(feat.EndDate, "DF");

                if (!string.IsNullOrEmpty(feat.TimeDesc))
                    lblFeaturedDate.Text += " at " + Convert.ToString(feat.TimeDesc); 

                if (string.IsNullOrEmpty(feat.ShortContent))
                    lblFeaturedDescription.Text = Convert.ToString(feat.MetaDesc);
                else
                    lblFeaturedDescription.Text = Convert.ToString(feat.ShortContent);

                string eventurl = RoutingHelpers.GetEventSingleRouteURL(feat.EventTypeAlias, feat.EventID, WebsiteHelpers.SanitizeUrl(feat.Title)); ;
                lnkTitle.NavigateUrl = eventurl;
                lnkImage.NavigateUrl = eventurl;
                lnkReadMore.NavigateUrl = eventurl;

                FeaturedLeft.Visible = true;
                imgFeatured.ImageUrl = Page.ResolveUrl("~/media/images/content/" + feat.FeaturedImage);
                lnkImage.Visible = true;
                this.lnkFeatured.NavigateUrl = Page.ResolveUrl("~/administrator/index.aspx?page=featured&action=e&section=applications&id=1");
            }
            else
            {
                this.lnkFeatured.NavigateUrl = Page.ResolveUrl("~/administrator/index.aspx?action=a&section=applications&page=featured");
                this.lnkFeatured.Text = "Add Featured Event";
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var repo = new ApplicationRepository();
                WebsiteHelpers.GenerateMetaTags(repo.GetApplicationByName(Constants.APP_TESTIMONIAL), this.MetaPlaceHolder);

                EventType = (Page.RouteData.Values["type"] != null) ? Convert.ToString(Page.RouteData.Values["type"]) : "";
                EventTense = (Page.RouteData.Values["tense"] != null) ? Convert.ToString(Page.RouteData.Values["tense"]) : "";

                if (EventTense == Constants.EVENT_FEATURED)
                {
                    EventTense = repo.GetEventFinalTense(EventType);
                }

                lnkPast.NavigateUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_PAST);
                lnkUpcoming.NavigateUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_UPCOMING);
                if (EventTense == Constants.EVENT_UPCOMING)
                    lnkUpcoming.CssClass += " active";
                else
                    lnkPast.CssClass += " active";

                EventDataSource.SelectParameters.Add("type", EventType);
                EventDataSource.SelectParameters.Add("tense", EventTense);

                this.EventFeatured.Attributes.Add("class", EventType.ToLower());
                if (EventType.ToLower() == "all")
                {
                    litTitle.Text = "Events Calendar";
                    this.linkAbout.Visible = false;
                }
                else
                {                    
                    litTitle.Text = repo.GetEventNameByAlias(EventType);
                    ShowFeatured();
                    this.linkAbout.Visible = true;
                    string linkText = "Click here to know about the specifications and facilities of the Kamalnayan Bajaj ";
                    string lnkURL = "#";

                    switch (EventType)
                    {
                        case "multi-use-hall":
                            linkText += " Hall";
                            lnkURL = "facilities/kamalnayan-bajaj-hall";
                            break;
                        case "art-gallery":
                            linkText += " Art Gallery";
                            lnkURL = "facilities/kamalnayan-bajaj-art-gallery";
                            break;
                        case "workshops":
                            linkText += " Workshop Studio";
                            lnkURL = "facilities/kamalnayan-bajaj-workshop-studio";
                            break;
                        default:
                            this.linkAbout.Visible = false;
                            break;
                    }

                    this.linkAbout.NavigateUrl = WebsiteHelpers.GetAbsolutePath(lnkURL);
                    this.linkAbout.Text = linkText;

                }

                string strEventName = "";
                switch (EventTense)
                {
                    case Constants.EVENT_PAST:
                        strEventName = "Past Events";
                        break;
                    case Constants.EVENT_UPCOMING:
                        strEventName = "Upcoming Events";
                        break;
                }

                BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.AddToEnd = new List<BreadCrumbDTO>();
                bc.AddToEnd.Add(new BreadCrumbDTO
                {
                    LinkName = strEventName,
                    LinkUrl = Request.Url.AbsolutePath
                });

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_Events, "events/" + EventType + "/featured");

                Authorized();
            }
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}