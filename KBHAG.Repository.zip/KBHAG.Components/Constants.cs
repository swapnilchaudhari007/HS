﻿
namespace KBHAG.Components
{
    public static class Constants
    {

        #region Url
        public const string WEBSITE_NAME        = "Kamalnayan Bajaj Hall & Art Gallery";
        public const string COMPANY_NAME        = "Kamalnayan Bajaj Hall & Art Gallery";
        public const string ABSOLUTE_PATH       = "~/";
        #endregion

        #region Message
        public const string DROPDOWN_SELECTED   = "---- Select ----";
        public const string REQUIRED_MESSAGE    = "Required field cannot be left blank";
        public const string INSERT_MESSAGE      = "Record inserted successfully";
        public const string UPDATE_MESSAGE      = "Record updated successfully";
        public const string DELETE_MESSAGE      = "Record deleted successfully";
        public const string EXISTS_LONG_MESSAGE = "Record already exists";
        public const string ERROR_LONG_MESSAGE  = "There was an error processing your request.";
        public const string NUMBER_MESSAGE      = "Please enter a valid number";
        public const string EMAIL_MESSAGE       = "Please enter a valid email";
        public const string INVALID_PARAMETERS  = "Invalid Parameters";
        public const string PROCESS_MESSAGE     = "Processing your request, please wait";

        public const string SUCCESS_MESSAGE     = "success";
        public const string ERROR_MESSAGE       = "error";
        public const string EXISTS_MESSAGE      = "exists";

        #endregion

        #region Admin
        public const string ADMIN_DEFAULT_PAGE  = "~/administrator/index.aspx";
        public const string ADMIN_LOGIN_PAGE    = "~/administrator/default.aspx";

        public const string ADMIN_LOGIN_COOKIE  = "KBHAG_Admin_LOGIN";
        public const string ADMIN_LOGIN_VALID   = "KBHAG_Admin_AUTHORIZE";
        #endregion

        #region Encrypt
        public const string TAMPERPROOFKEY      = "$m@rt2285kBhAg";
        #endregion

        #region Global Setting

        public const string MODEL_ASSEMBLY_NAME = "KBHAG.Model";

        public const int GLOBAL_ITEM_PER_PAGE   = 10;
        public const string AJAX_ASPX_PATH      = "ajax/ajaxCall.aspx";
        public const string PROCESS_ASHX_PATH   = "ajax/ProcessImage.ashx";

        public const string APP_CMS     = "CMS";
        public const string APP_VIDEOS  = "Videos";
        public const string APP_Albums  = "Albums";
        public const string APP_Events  = "Events";
        public const string APP_PRESS   = "Press";
        public const string APP_INQUIRY = "Inquiry";
        public const string APP_TESTIMONIAL = "Testimonial";
        public const string APP_NEWS    = "News";

        public const string EVENT_FEATURED  = "featured";
        public const string EVENT_PAST      = "past";
        public const string EVENT_UPCOMING  = "upcoming";

        #endregion

        #region Image Crop Control

        public const string MEDIA_TYPE_IMAGE    = "I";
        public const string MEDIA_TYPE_FILE     = "P";
        public const string MEDIA_TYPE_VIDEO    = "V";

        public const int ALBUM_THUMB_WIDTH      = 120;
        public const int ALBUM_THUMB_HEIGHT     = 52;
        public const int ALBUM_IMAGE_WIDTH      = 930;
        public const int ALBUM_IMAGE_HEIGHT     = 400;

        public const string SLIDESHOW_TARGET_ALBUM = "album";
        public const string SLIDESHOW_TARGET_PAGE = "page";
        public const string SLIDESHOW_TARGET_EVENT = "event";


        public const string MEDIA_MANAGE_AJAX           = "Manage/AjaxMediaManage.aspx";
        public const string MEDIA_MANAGE_PROCESS        = "Manage/ProcessImage.ashx";
        public const string MEDIA_MANAGE_PHOTOUPLOAD    = "Manage/photoupload.aspx";

        public const string IMAGE_CONTENT_FOLDER_PATH   = "media/images/content/";
        public const string IMAGE_HTML_FOLDER_PATH      = "media/images/html/";
        
        //Local Setting        
        public const string TEMP_IMAGE_FOLDER_PATH      = "media/images/temp/";
        public const string IMAGE_FOLDER_PATH           = "media/images/content/";                
        public const string FILE_FOLDER_PATH            = "media/pdf/";
        public const string VIDEO_FOLDER_PATH           = "media/video/";
        public const string SWF_FOLDER_PATH             = "media/swf";      

        #endregion

        #region SMP Mail Settings
        public static string SMTP_SERVER = "smtp.gmail.com";
        public static string SMTP_USERNAME = "noreply@somaiya.edu";
        public static string SMTP_PASSWORD = "noreply@123";

        public static string DEFAULT_FROM_ADDRESS = "postmaster@somaiya.edu";
        public const string ADMISSION_SUPPORT_EMAIL = "techsupport@somaiya.edu";
        #endregion

        #region Enum

        public enum MESSAGE_TYPE
        {
            block,
            error,
            success,
            info
        }

        public enum SORT_ORDER
        {
            Asc,
            Desc
        }

        #endregion
    }
}
