﻿using System.Data.Entity;
using KBHAG.Model;

namespace KBHAG.Data
{
    public interface IKBHAGContext
    {
        IDbSet<FormPage>                FormPages               { get; set; }
        IDbSet<AdminMenu>               AdminMenus              { get; set; }
        IDbSet<ViewAdminMenu>           ViewAdminMenus          { get; set; }
        IDbSet<FormStructure>           FormStructures          { get; set; }
        IDbSet<User>                    Users                   { get; set; }

        IDbSet<Application>             Applications            { get; set; }
        IDbSet<Layout>                  Layouts                 { get; set; }
        IDbSet<CMSMenu>                 Menus                   { get; set; }
        IDbSet<ViewMenu>                ViewMenus               { get; set; }
        IDbSet<PageStructure>           PageStructures          { get; set; }
        IDbSet<CMSPage>                 CMSPages                { get; set; }
        IDbSet<ViewPage>                ViewPages               { get; set; }
        IDbSet<PageData>                PageDatas               { get; set; }
        IDbSet<ViewPageData>            ViewPageDatas           { get; set; }
        IDbSet<PagePublish>             PagePublishs            { get; set; }
        IDbSet<ViewPagePublish>         ViewPagePublishs        { get; set; }
        IDbSet<MapLayoutStructure>      MapLayoutStructures     { get; set; }
        IDbSet<ViewMapLayoutStructure>  ViewMapLayoutStructures { get; set; }

        IDbSet<HomePage>                HomePages               { get; set; }

        IDbSet<EventType>               EventTypes              { get; set; }
        IDbSet<Event>                   Events                  { get; set; }
        IDbSet<Featured>                Featureds               { get; set; }
        IDbSet<ViewFeatured>            ViewFeatureds           { get; set; }
        IDbSet<ViewEvent>               ViewEvents              { get; set; }
        IDbSet<SlideShow>               SlideShows              { get; set; }
        IDbSet<SlideShowMedia>          SlideShowMedias         { get; set; }
        IDbSet<Press>                   Presss                  { get; set; }
        IDbSet<Video>                   Videos                  { get; set; }

        IDbSet<Inquiry>                 Inquirys                { get; set; }
        IDbSet<Testimonial>             Testimonials            { get; set; }
        IDbSet<News>                    Newss                    { get; set; }
    }
}
