﻿using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;


namespace KBHAG.Repository
{
    public class MenuRepository:IMenuRepository
    {

        public int GetMenuIDByAlliasName(string parent, string allias)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                var query = repo.Get(i => i.ParentAllias == parent  && i.Allias == allias && i.Active == "Y");
                return (query != null) ? query.MenuID : 0;
            } 
        }

        public int GetMenuIDForApp(string app, string allias = "")
        {
            int ret = 0;
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                if (!string.IsNullOrEmpty(allias))
                {
                    var data = repo.Get(i => i.AppName == app && i.Allias.Contains(allias) && i.Active == "Y");
                    if (data != null)
                        ret = data.MenuID;
                }
                else
                {
                    var data2 = repo.Get(i => i.AppName == app && i.Active == "Y");
                    if (data2 != null)
                        ret = data2.MenuID;
                }
            }

            return ret;
        }

        public ViewMenu GetMenuByAlliasName(string parent, string allias)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                return repo.Get(i => i.ParentAllias == parent && i.Allias == allias && i.Active == "Y");
            }
        }


        public List<ViewMenu> GetLevel1Menu(int ParentMenu)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo        = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.ParentID == ParentMenu && i.Active == "Y").OrderBy(o => o.Index).ToList();
            }
        }

        public List<ViewMenu> GetMenuTree()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.Active == "Y").OrderBy(i=> i.ParentID).ThenBy(o => o.Index).ToList();
            }
        }

        public List<ViewMenu> GetMenuByParentID(int parentid)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<ViewMenu>();
                repo.UnitOfWork = uow;
                return repo.GetMany(i => i.ParentID == parentid && i.Active == "Y").OrderBy(o => o.Index).ToList();
            }
        }


        public int GetPublishPageID(int menuid)
        {
            int returnId = 0;
            int id = menuid;

            //if (level2 != 0)
            //{
            //    id = level2;
            //}
            //else if (level1 != 0)
            //{
            //    id = level1;
            //}
            //else
            //{
            //    id = menuid;
            //}

            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<PagePublish>();
                repo.UnitOfWork = uow;
                var query = repo.Get(i => i.MenuID == id);
                if (query != null)
                {
                    returnId = query.PageID;
                }
                //else
                //{
                //    if (level1 != 0 && level2 == 0)
                //    {
                //        foreach (var item in GetMenuByParentID(level1))
                //        {
                //            var tempQuery = repo.Get(i => i.MenuID == item.MenuID);
                //            if (tempQuery != null)
                //            {
                //                returnId = tempQuery.PageID;
                //                break;
                //            }
                //        }
                //    }
                //}
            }
            return returnId;
        }
    }
}
