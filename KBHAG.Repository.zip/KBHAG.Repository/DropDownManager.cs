﻿using Newtonsoft.Json.Linq;
using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace KBHAG.Repository
{
    public class DropDownManager
    {
        public DropDownList ddl         { get; set; }
        public string type              { get; set; }
        public string selectedValue     { get; set; }
        public int id                   { get; set; }
        public string selectedText      { get; set; }
        public bool isDefaultRequired   { get; set; }
        public JObject genericJsonObject { get; set; }

        public DropDownManager(DropDownList ddl, string type, string selectedValue,JObject jsonObject, int id = 0, string selectedText = "", bool isDefaultRequired = true)
        {
            this.ddl = ddl;
            this.type = type;
            this.selectedValue = selectedValue;
            this.id = id;
            this.selectedText = selectedText;
            this.isDefaultRequired = isDefaultRequired;
            this.genericJsonObject = jsonObject;
        }

        public DropDownList FillDropDownList()
        {

            bool allowDefaultDropdownItem = true;//For ---Selecte-- text in DropdownList

            var uow = new KBHAGUnitOfWork();

            switch (type)
            {
                case "Generic":
                    if (genericJsonObject["ModelName"] != null && genericJsonObject["DataTextField"] != null && genericJsonObject["DataValueField"] != null)
                    {
                        string model        = string.Empty;
                        string textField    = string.Empty;
                        string valueField   = string.Empty;                    
                    
                        model           = (string)genericJsonObject["ModelName"];
                        textField       = (string)genericJsonObject["DataTextField"];
                        valueField      = (string)genericJsonObject["DataValueField"];
                                                
                        dynamic repo    = DynamicHelpers.GetGenericRepository(RepositoryConstants.MODEL_ASSEMBLY_NAME, model);
                        repo.UnitOfWork = uow;
                        dynamic data    = repo.GetAll();

                        ddl.DataSource      = data;
                        ddl.DataTextField   = textField;
                        ddl.DataValueField  = valueField;
                    }

                    break;
                

                case "ParentAdminMenu":
                    var repoAdminMenu = new GenericRepository<AdminMenu>();
                    repoAdminMenu.UnitOfWork = uow;

                    ddl.DataSource      = repoAdminMenu.GetMany(i => i.ParentMenuID == 0);
                    ddl.DataTextField   = "Name";
                    ddl.DataValueField  = "MenuID";

                    break;                

                case "ParentMenu":

                     var repoMenu = new GenericRepository<KBHAG.Model.CMSMenu>();
                     repoMenu.UnitOfWork = uow;

                     ddl.DataSource     = repoMenu.GetMany(i => i.ParentID == 0);
                     ddl.DataTextField  = "Title";
                    ddl.DataValueField  = "MenuID";

                    isDefaultRequired = false;
                    selectedText = "---- Select ----";
                    break;

                default:
                    break;
            }

            ddl.DataBind();

            if (isDefaultRequired == true)
            {
                if (selectedText != string.Empty)
                {
                    ddl.Items.Insert(0, selectedText);
                }
                else
                {
                    if (allowDefaultDropdownItem)
                    {
                        ddl.Items.Insert(0, "---- Select ----");
                    }
                }

                if (allowDefaultDropdownItem)
                {
                    ddl.Items[0].Value = "";
                }
            }
            else
            {
                ddl.Items.Insert(0, selectedText);
                ddl.Items[0].Value = "0";
            }

            ddl.SelectedValue = (selectedValue != string.Empty) ? selectedValue : "0";
            return ddl;
        }
    }
}
