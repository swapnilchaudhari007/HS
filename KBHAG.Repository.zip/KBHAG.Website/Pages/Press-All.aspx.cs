﻿using KBHAG.Components;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class Press_All : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method
        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.AddPress.Visible = true;
                this.AddPress.NavigateUrl = Page.ResolveUrl("~/administrator/index.aspx?action=a&section=applications&page=press");
            }
        }

        public string CheckDisplay(string data)
        {
            if (string.IsNullOrEmpty(data))
                return "displaynone";
            else
                return "";
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var repo = new ApplicationRepository();
                WebsiteHelpers.GenerateMetaTags(repo.GetApplicationByName(Constants.APP_PRESS), this.MetaPlaceHolder);

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_PRESS);

                Authorized();
            }
        }
        #endregion

        #region WebMethod

        #endregion
    }
}