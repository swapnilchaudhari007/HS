﻿using CKEditor.NET;
using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator
{
    public partial class Index : System.Web.UI.Page
    {
        #region Declaration

        #endregion

        #region Method

        protected void viewForm()
        {
            switch (Admin.FormDTO.Action)
            {
                case "v":                   
                    this.GridHolder.Visible = true;
                    this.FormHolder.Visible = false;
                    break;

                case "a":
                    this.GridHolder.Visible = false;
                    this.FormHolder.Visible = true;
                    break;

                case "e":
                    this.GridHolder.Visible = false;
                    this.FormHolder.Visible = true;
                    break;
            }

            if (Admin.FormDTO.Action == "v")
            {
                DynamicForm dynamicPage = new DynamicForm 
                { 
                    FormDTO = Admin.FormDTO
                };

                dynamicPage.ShowGrowlMessage();
            }

            if (Admin.FormDTO.Action != "v")
            {
                //renderControls();
                DynamicForm dynamicPage = new DynamicForm {                     
                    FormHolder              = this.FormHolder,
                    ControlHolder           = this.ControlHolder,                    
                    ControlUniqueID         = "ctl00$MainPlaceHolder$",
                    HiddenCallBackFunction  = this.hidden_CallBackFunction,
                    FormDTO                 = Admin.FormDTO,
                    SubmitButton            = this.btnSave
                    
                };
                dynamicPage.CreateForm();
            }
                
        }        

        #endregion

        #region Event

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            viewForm();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SubmitHandler(object sender, EventArgs e)
        {
            DynamicForm dynamicPageForSubmit = new DynamicForm
            {
                FormDTO         = Admin.FormDTO,
                ControlHolder   = this.ControlHolder
            };

            try
            {
                Dictionary<string, string> ModelStructureList = ModelStructureList = dynamicPageForSubmit.GetModelStructureList();                

                string primaryKeyName = UserControls.GridControl.GridPKID;
                if (Admin.FormDTO.Action == "e")
                {
                    //Assign Value to Primary Key Column                     
                    int cnt = primaryKeyName.Select(s => s).Where(s => s == '.').ToArray().Length;

                    if (cnt > 0)
                    {
                        primaryKeyName = Convert.ToString(primaryKeyName.Split('.')[1]);
                    }

                    ModelStructureList.Add(primaryKeyName, Util.Parse<string>(Admin.FormDTO.ReferenceID));
                }

                DataManager manager = new DataManager
                {
                    ID                      = Admin.FormDTO.ReferenceID,
                    Action                  = Admin.FormDTO.Action,
                    Model                   = Admin.FormDTO.Model,
                    ColumnsList             = ModelStructureList,
                    PrimaryKeyColumnName    = primaryKeyName
                };

                if (!String.IsNullOrEmpty(this.hidden_CallBackFunction.Value))
                {
                    var validateData = JsonConvert.DeserializeObject<dynamic>(this.hidden_CallBackFunction.Value);
                    if (validateData != null)
                    {
                        if (validateData.SubmitValidation != null)
                        {
                            string columnName       = validateData.SubmitValidation.Columns.Value;
                            manager.ValidateColumn  = columnName.Split(',').ToList<string>();
                        }
                    }
                }
                else
                {
                    manager.ValidateColumn = new List<string>();
                }
                

                if (manager.Manage() == Constants.SUCCESS_MESSAGE)
                {
                    string msg = (Admin.FormDTO.Action == "a") ? "a" : "u";                    
                    Response.Redirect(Page.ResolveUrl(Constants.ADMIN_DEFAULT_PAGE + "?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=v&message=" + msg));
                }
                else
                {
                    dynamicPageForSubmit.ShowResponseMessage(Constants.MESSAGE_TYPE.block, Constants.EXISTS_LONG_MESSAGE);
                }

            }
            catch (Exception ex)
            {
                dynamicPageForSubmit.ShowResponseMessage(Constants.MESSAGE_TYPE.error, "<br/>" + ex.ToString());
            }
        }

        protected void CancelHandler(object sender, EventArgs e)
        {
            Response.Redirect("~/administrator/index.aspx?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=v");
        }

        protected void DeleteHandler(object sender, EventArgs e) {

            

        }

        #endregion

        #region WebMethod

        #endregion
    }
}