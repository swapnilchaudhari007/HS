﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;

namespace KBHAG.Components
{
    public class RoutingHelpers
    {
        public static string GetMenuRouteURL(string level0, string level1, string application, string level2 = "")
        {
            string returnURL = string.Empty;
            var page = HttpContext.Current.Handler as Page;

            switch (application)
            {
                case Constants.APP_VIDEOS:
                    returnURL = GetVideosAllURL();
                    break;

                case Constants.APP_Albums:
                    returnURL = GetPhotoAllURL();
                    break;

                case Constants.APP_Events:
                    if (!string.IsNullOrEmpty(level2))
                        returnURL = GetEventAllURL(level2);
                    else if (!string.IsNullOrEmpty(level1))
                        returnURL = GetEventAllURL(level1);
                    else if (!string.IsNullOrEmpty(level0))
                        returnURL = GetEventAllURL(level0);
                    break;

                case Constants.APP_PRESS:
                    returnURL = GetPressURL();
                    break;

                case Constants.APP_INQUIRY:
                    returnURL = GetFormURL("inquiry");
                    break;

                case Constants.APP_TESTIMONIAL:
                    returnURL = GetTestimonialURL();
                    break;

                case Constants.APP_NEWS:
                    returnURL = GetNewsURL();
                    break;

                default:
                    if (!string.IsNullOrEmpty(level2))
                    {
                        returnURL = Get2LevelRouteURL(level0, level1, level2);
                    }
                    else if (!string.IsNullOrEmpty(level1))
                    {
                        returnURL = Get1LevelRouteURL(level0, level1);
                    }
                    else
                    {
                        returnURL = Get0LevelRouteURL(level0);
                    }

                    break;
            }
            return returnURL;
        }                    

        public static string Get2LevelRouteURL(string level0, string level1, string level2)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("CMS-Two-Level", new { level0 = level0.ToLower(), level1 = level1, level2 = level2 });
        }

        public static string Get1LevelRouteURL(string level0, string level1)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("CMS-One-Level", new { level0 = level0.ToLower(), level1 = level1 });
        }

        public static string Get0LevelRouteURL(string level0)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("CMS-Zero-Level", new { level0 = level0.ToLower() });
        }        

        public static string GetPhotoAllURL()
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Album-All", new { });
        }

        public static string GetAlbumSingleURL(string id, string title)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Album-Single", new { id = id, title = title.ToLower() });
        }

        public static string GetVideosAllURL()
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Video-All", new { });
        }

        public static string GetVideoSingleURL(string id, string title)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Video-Single", new { id = id, title = title.ToLower() });
        }

        public static string GetPressURL()
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Press-All", new { });
        }

        public static string GetEventAllURL(string etype = "all", string tense = "featured")
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Event-All", new { type = etype, tense = tense });
        }

        public static string GetEventSingleRouteURL(string etype,int eventid, string allias)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Events-Single", new { type = etype, id = eventid, allias = allias });
        }

        public static string GetFormURL(string type)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("form", new { type = type });
        }

        private static string GetTestimonialURL()
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("Testimonial", new { });
        }

        public static string GetNewsURL()
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("News-All", new { });
        }

        public static string GetNewsSingleRouteURL(int id, string allias)
        {
            var page = HttpContext.Current.Handler as Page;
            return page.GetRouteUrl("News-Single", new { id = id, allias = allias });
        }

    }
}
