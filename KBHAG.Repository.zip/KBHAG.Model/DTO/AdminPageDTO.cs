﻿namespace KBHAG.Model
{
    public class FormDTO
    {
        public int      PageID      { get; set; }
        public string   PageAllias  { get; set; }
        public string   Action      { get; set; }
        public string   Section     { get; set; }        
        public string   Message     { get; set; }
        public int      ReferenceID { get; set; }
        public string   Model       { get; set; }
    }

    public class RowCollection
    {
        public string ColumnName    { get; set; }
        public string ColumnValue   { get; set; }
    }
}
