﻿using KBHAG.Components;
using KBHAG.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class NotFound : System.Web.UI.Page
    {
        public  int level0id = 0;                
        public  int currentMenuID = 0;

        public string level0 = string.Empty;
        public string level1 = string.Empty;
        public string level2 = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            var repoMenu = new MenuRepository();

            level0      = (Request.QueryString["level0"] != null) ? (Request.QueryString["level0"] as string) : string.Empty;           
            level1      = (Request.QueryString["level1"] != null) ? (Request.QueryString["level1"] as string).ToLower() : string.Empty;           
            level2      = (Request.QueryString["level2"] != null) ? (Request.QueryString["level2"] as string).ToLower() : string.Empty;

            if (!string.IsNullOrEmpty(level2))
                currentMenuID = repoMenu.GetMenuIDByAlliasName(level1, level2);
            else if (!string.IsNullOrEmpty(level1))
                currentMenuID = repoMenu.GetMenuIDByAlliasName(level0, level1);
            else if (!string.IsNullOrEmpty(level0))
                currentMenuID = repoMenu.GetMenuIDByAlliasName("", level0);
            else
            {
                currentMenuID = 0;
            }
            this.hidden_currentmenuid.Value = currentMenuID.ToString();
            this.hidden_url.Value = Request.Url.AbsolutePath;

        }
    }
}