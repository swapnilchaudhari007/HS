﻿
namespace KBHAG.Repository
{
    public static class RepositoryConstants
    {
        #region Global Setting

        public const string MODEL_ASSEMBLY_NAME = "KBHAG.Model";

        public const string EVENT_FEATURED = "featured";
        public const string EVENT_PAST = "past";
        public const string EVENT_UPCOMING = "upcoming";


        public const string SLIDESHOW_TARGET_ALBUM = "album";
        public const string SLIDESHOW_TARGET_PAGE = "page";
        public const string SLIDESHOW_TARGET_EVENT = "event";

        #endregion
    }
}
