﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KBHAG.Model;

namespace KBHAG.Model
{

    public class PageDTO
    {
        public int      MenuID      { get; set; }
        public int      PageID      { get; set; }
        public int      Level1ID    { get; set; }
        public int      Level2ID    { get; set; }
        public string   Level1      { get; set; }
        public string   Level2      { get; set; }
    }

    public class PageDataDTO
    {
        public string   Type        { get; set; }
        public string   Tag         { get; set; }
        public string   ID          { get; set; }
        public string   Text        { get; set; }
    }

    public class PageEditDTO
    {
        public int      PageDataID  { get; set; }
        public string   RenderTag   { get; set; }
        public string   RenderName  { get; set; }
        public string   Validation  { get; set; }
        public string   Control     { get; set; }
    }

    public class PageContentDTO
    {
        public int PageID           { get; set; }
        public int LayoutID         { get; set; }
    }

    public class CommonDTO
    {   
        public string   DTO1    { get; set; }        
        public string   DTO2    { get; set; }        
        public string   DTO3    { get; set; }        
        public int      DTO4    { get; set; }
    }
    public class BreadCrumbDTO
    {
        public string LinkName  { get; set; }
        public string LinkUrl   { get; set; }
    }
}
