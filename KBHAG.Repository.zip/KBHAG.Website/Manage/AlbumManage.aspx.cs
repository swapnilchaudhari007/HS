﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Website.Administrator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Manage
{
    public partial class AlbumManage : System.Web.UI.Page
    {
        #region Declaration

        #endregion


        #region Methods
        protected void viewForm()
        {
            switch (Admin.FormDTO.Action)
            {
                case "v":
                    ShowMessage();//Show Notification Message
                    this.GridHolder.Visible = true;
                    this.FormHolder.Visible = false;
                    break;

                case "a":
                case "p":
                case "e":
                    this.GridHolder.Visible = false;
                    this.FormHolder.Visible = true;
                    break;
            }

        }

        private void ShowMessage()
        {
            if (!String.IsNullOrEmpty(Admin.FormDTO.Message))
            {
                string messageText = string.Empty;

                if (Admin.FormDTO.Message == "a")
                {
                    messageText = Constants.INSERT_MESSAGE;
                }
                else if (Admin.FormDTO.Message == "u")
                {
                    messageText = Constants.UPDATE_MESSAGE;
                }
                else if (Admin.FormDTO.Message == "d")
                {
                    messageText = Constants.DELETE_MESSAGE;
                }

                runjQueryCode("$.msgGrowl ({type: 'success', title: 'Success', text: '" + messageText + "'})");

            }
        }

        private void runjQueryCode(string jsCodetoRun)
        {

            ScriptManager requestSM = ScriptManager.GetCurrent(this);
            if (requestSM != null && requestSM.IsInAsyncPostBack)
            {
                ScriptManager.RegisterClientScriptBlock(this,
                                                        typeof(Page),
                                                        Guid.NewGuid().ToString(),
                                                        WebsiteHelpers.GetjQueryCode(jsCodetoRun),
                                                        true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(typeof(Page),
                                                       Guid.NewGuid().ToString(),
                                                       WebsiteHelpers.GetjQueryCode(jsCodetoRun),
                                                       true);
            }
        }

        #endregion

        #region Event
        //protected override void OnInit(EventArgs e)
        //{
        //    base.OnInit(e);

        //    viewForm();
        //}
        protected void Page_Load(object sender, EventArgs e)
        {
            ucMediaManage.AlbumId       = Admin.FormDTO.ReferenceID;
            ucMediaManage.MediaAction   = Admin.FormDTO.Action;
            ucMediaManage.TargetId      = (!String.IsNullOrEmpty(Request.QueryString["targetid"])) ? Util.Parse<int>(Request.QueryString["targetid"]) : 0; 
            ucMediaManage.Target        = (!String.IsNullOrEmpty(Request.QueryString["target"])) ? Convert.ToString(Request.QueryString["target"]) :"";
            ucMediaManage.CoverHeight   = Constants.ALBUM_THUMB_HEIGHT;
            ucMediaManage.CoverWidth    = Constants.ALBUM_THUMB_WIDTH;
            ucMediaManage.IMAGEWIDTH    = (!String.IsNullOrEmpty(Request.QueryString["imagewidth"])) ? Util.Parse<int>(Request.QueryString["imagewidth"]) : 0;
            ucMediaManage.IMAGEHEIGHT   = (!String.IsNullOrEmpty(Request.QueryString["imageheight"])) ? Util.Parse<int>(Request.QueryString["imageheight"]) : 0;
            ucMediaManage.GRIDHEIGHT    = 600;
            ucMediaManage.GRIDWIDTH     = 1000;
            viewForm();

            //tblAlbumData.Visible = true; // change as per handler
            //if (MediaAction != "e")
            //    trAlbumData.Visible = false;
        }
        #endregion


    }
}