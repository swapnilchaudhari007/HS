﻿using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Drawing.Imaging;
using System.Web.UI.WebControls;
using KBHAG.Repository;

namespace KBHAG.Components
{
    public class WebsiteHelpers
    {
        public static String GetAbsolutePath(string path)
        {
            string retval = "";

            try
            {
                if (path.Substring(0, 2) == "~/")
                    retval = path;
                else if (path.Substring(0, 1) == "/")
                    retval = "~" + path;
                else if (path.Substring(0, 2) != "~/")
                    retval = "~/" + path;
            }
            catch (Exception)
            {
                retval = path;
            }            

            Page page = HttpContext.Current.Handler as Page;

            return page.ResolveUrl(retval);
        }

        public static String RemoveCData(string HtmlText)
        {
            return HtmlText.Replace("<![CDATA[", "").Replace("]]>", "");
        }

        public static PageDataDTO GetPageSlideShowId(List<PageDataDTO> data)
        {
            //string slideShowRenderID = String.Empty;
            PageDataDTO DTO = null;

            var slideShowQuery = data.FirstOrDefault(i => i.Type == "SlideShow");
            if (slideShowQuery != null)
            {
                //slideShowRenderID = slideShowQuery.Text;
                DTO = slideShowQuery;
            }

            return DTO;
            //return slideShowRenderID;
        }

        public static string GenerateSlideShow(int id, string AddClass = "", bool ShowShareUrl = false)
        {
            StringBuilder sbImages = new StringBuilder();
            var albumRepo = new ApplicationRepository();
            int cnt = 0;
            foreach (var itemImages in albumRepo.GetMediaByAlbumID(id))
            {
                string newImage = "image_" + cnt.ToString();
                sbImages.Append("<div");
                if(!string.IsNullOrEmpty(AddClass))
                    sbImages.Append(" class='" + AddClass + "'");

                if (cnt > 0)
                    sbImages.Append(" style='display:none;'");

                string imageTitle = (string.IsNullOrEmpty(itemImages.Caption)) ? WebsiteHelpers.SanitizeUrl(itemImages.FileName) : WebsiteHelpers.SanitizeUrl(itemImages.Caption);

                //sbImages.Append("id='div_" + newImage + "' share-url='" + itemImages.MediaID.ToString() + "/" + imageTitle + "'><img src='" + WebsiteHelpers.GetValidFilePath(itemImages.FileName, "IMAGE", false)
                //    + "' id='" + newImage + "' alt = '" + itemImages.Caption.Replace("'", "&apos;").Replace("\"", "&quot;") + "' />");
                sbImages.Append(" id='div_" + newImage + "'");

                if (ShowShareUrl)
                    sbImages.Append(" share-url='" + itemImages.MediaID.ToString() + "/" + imageTitle + "' ");

                sbImages.Append("><img src='" + WebsiteHelpers.GetValidFilePath(itemImages.FileName, "IMAGE", false)
                    + "' id='" + newImage + "' alt = '" + itemImages.Caption.Replace("'", "&apos;").Replace("\"", "&quot;") + "' />");

                sbImages.Append("</div>");

                cnt++;
            }
            return sbImages.ToString();
        }

        public static string RenderHtml(string layoutHTML, List<PageDataDTO> pageDataList)
        {
            string returnString = string.Empty;

            try
            {
                layoutHTML = "<root>" + layoutHTML + "</root>";

                foreach (var item in pageDataList)
                {
                    //string htmlControlName = (item.Type == "Text") ? "div" : item.Type;
                    layoutHTML = ModifyHtmlTagById(layoutHTML, item.Tag, item.ID, item.Text);
                }

                return layoutHTML;

            }
            catch (Exception ex)
            {
                returnString = ex.ToString();
            }

            return returnString;
        }

        public static String ModifyHtmlTagById(string HtmlText, string HtmlTag, string HtmlTagId, string HtmlToReplace)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(HtmlText);

                XmlNodeList nodeList =   doc.GetElementsByTagName(HtmlTag);
                foreach (XmlNode xNode in nodeList)
                {
                    Boolean foundDiv = false;

                    foreach (XmlAttribute xattr in xNode.Attributes)
                    {
                        if (xattr.Name == "id" && xattr.Value == HtmlTagId)
                        {
                            switch (HtmlTag)
                            {
                                case "img":
                                    xNode.Attributes["src"].Value = WebsiteHelpers.GetAbsolutePath(Constants.IMAGE_CONTENT_FOLDER_PATH + HtmlToReplace);
                                    if (xNode.Attributes["alt"] != null)
                                        xNode.Attributes["alt"].Value = Path.GetFileNameWithoutExtension(HtmlToReplace);
                                    break;
                                case "a":
                                    xNode.Attributes["href"].Value = HtmlToReplace;
                                    break;
                                default:
                                    xNode.InnerXml = "<![CDATA[" + HtmlToReplace + "]]>";
                                    break;
                            }
                            foundDiv = true;
                            break;
                        }
                    }

                    if (foundDiv)
                        break;
                }

                return doc.InnerXml;
            }
            catch (Exception E)
            {
                return "error" + "|" + E.Message + "|" + E.InnerException;
            }
        }

        public static HtmlMeta GetHtmlMeta(string metaName, string metaContent)
        {
            HtmlMeta meta   = new HtmlMeta();
            meta.Name       = metaName;
            meta.Content    = metaContent;
            return meta;
        }       

        public static string GetPageTitle(string menu)
        {
            if (string.IsNullOrEmpty(menu))
                return "";
            else
                return String.Concat(ToTitleCase(ChangeReplaceSpace(menu)), " | ", Constants.WEBSITE_NAME);
        }

        public static string ToTitleCase(string text)
        {
            TextInfo ti = new CultureInfo("en-US", false).TextInfo;
            return ti.ToTitleCase(text.ToLower());
        }

        public static string ChangeReplaceSpace(string text)
        {
            return text.Replace("_", " ");
        }

        public static string GetjQueryCode(string jsCodetoRun)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("$(document).ready(function() {");
            sb.AppendLine(jsCodetoRun);
            sb.AppendLine(" });");

            return sb.ToString();
        }

        public static string GetAdminUrl(string menu, string pageallias, string url)
        {
            var page = HttpContext.Current.Handler as Page;
            string returnUrl = string.Empty;

            if (!String.IsNullOrEmpty(url) && !url.Contains("#"))
            {
                returnUrl = page.ResolveUrl(url);
            }
            else
            {
                returnUrl = page.ResolveUrl(string.Concat(Constants.ADMIN_DEFAULT_PAGE, "?section=" + menu + "&page=" + pageallias + "&action=v"));
            }

            return returnUrl;
        }

        public static DateTime GetMMDDYYYY(string date, string format)
        {
            date = GetTempDate(date, format);
            DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
            dtfi.ShortDatePattern = format;
            DateTime dt = DateTime.ParseExact(date, format, CultureInfo.InvariantCulture);
            return dt;
        }

        public static String NumericMMYY(string date, string format)
        {
            date = GetTempDate(date, format);
            System.Globalization.DateTimeFormatInfo dtfi = new System.Globalization.DateTimeFormatInfo();
            dtfi.ShortDatePattern = format;
            DateTime dt = DateTime.ParseExact(date, "d", dtfi);
            return String.Format("{0:M/d/yyyy}", dt);
        }

        public static String NumericddMM(string date, string format)
        {
            date = GetTempDate(date, format);
            System.Globalization.DateTimeFormatInfo dtfi = new System.Globalization.DateTimeFormatInfo();
            dtfi.ShortDatePattern = format;
            DateTime dt = DateTime.ParseExact(date, "d", dtfi);
            return String.Format("{0:dd/MM/yyyy}", dt);
        }

        public static String NumericMMdd(DateTime Helpers)
        {
            return String.Format("{0:MM/dd/yyyy}", Helpers);
        }

        public static String NumericDate(DateTime Helpers)
        {
            return String.Format("{0:d/M/yyyy}", Helpers);
        }

        public static String CharDate(DateTime Helpers)
        {
            return String.Format("{0:MMM d, yyyy}", Helpers);
        }

        public static String SubScriptDate(DateTime cdate, string dtype)
        {
            string ret = "";

            string month = cdate.ToString("MMMM");

            //convert date to formatted string with subscript
            string date = cdate.Day.ToString();
            switch (cdate.Day)
            {
                case 1:
                    date += "st";
                    break;
                case 21:
                    date += "st";
                    break;
                case 31:
                    date += "st";
                    break;
                case 2:
                    date += "nd";
                    break;
                case 22:
                    date += "nd";
                    break;
                case 3:
                    date += "rd";
                    break;
                case 23:
                    date += "rd";
                    break;
                default:
                    date += "th";
                    break;
            }

            string year = cdate.ToString("yyyy");

            switch (dtype.ToUpper())
            {
                case "M":
                    ret = month;
                    break;
                case "D":
                    ret = date;
                    break;
                case "Y":
                    ret = year;
                    break;
                case "DF":
                    ret = date + " " + month + " " + year;
                    break;
                case "MF":
                    ret = month + " " + date + " " + year;
                    break;
            }

            return ret;
        }

        public static String StringCharDate(String Helpers, String format)
        {
            return String.Format("{0:MMM d, yyyy}", GetMMDDYYYY(Helpers, format));
        }

        public static String CharFullDate(DateTime Helpers)
        {
            return String.Format("{0:MMMM d, yyyy}", Helpers);
        }

        public static String CharDayDate(DateTime Helpers)
        {
            return String.Format("{0:ddd, MMM d, yyyy}", Helpers);
        }

        public static string GetTempDate(string date, string format)
        {
            String str = date;
            String[] arrlisttemp = str.Split(new char[] { Convert.ToChar(" ") });
            str = arrlisttemp[0];
            String[] arrlist = str.Split(new char[] { Convert.ToChar("/") });

            string TempDate = "01/01/1900";

            int intday = 0;
            int intMonth = 0;

            if (arrlist.Length == 3)
            {
                if (numeric(arrlist[0].ToString()) && numeric(arrlist[1].ToString()) && numeric(arrlist[2].ToString()))
                {
                    if (format == "dd/MM/yyyy")
                    {
                        intday = int.Parse(arrlist[0].ToString());
                        intMonth = int.Parse(arrlist[1].ToString());
                    }
                    else
                    {
                        intday = int.Parse(arrlist[1].ToString());
                        intMonth = int.Parse(arrlist[0].ToString());
                    }

                    if (intday > 0 && intday < 32)
                    {
                        if (intMonth > 0 && intMonth < 13)
                        {
                            string TempDay = (intday.ToString().Length == 1) ? "0" + intday.ToString() : intday.ToString();
                            string TempMonth = (intMonth.ToString().Length == 1) ? "0" + intMonth.ToString() : intMonth.ToString();
                            string TempYear = (arrlist[2].ToString().Length == 2) ? "20" + arrlist[2].ToString() : arrlist[2].ToString();

                            if (format == "dd/MM/yyyy")
                            {
                                TempDate = TempDay + "/" + TempMonth + "/" + TempYear;
                            }
                            else
                            {
                                TempDate = TempMonth + "/" + TempDay + "/" + TempYear;
                            }
                        }
                    }
                }
            }

            return TempDate;
        }

        public static Boolean numeric(String alphane)
        {
            System.Text.Encoding ascii = System.Text.Encoding.ASCII;
            Byte[] encodedBytes = ascii.GetBytes(alphane);
            foreach (Byte hh in encodedBytes)
            {
                if (hh > 47 && hh < 58)
                {
                    //return true;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        public static string Validation(string rules)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("var rules = " + rules + ";");
            sb.Append("var validationObj = $.extend(rules, Application.validationRules);");            
            sb.Append("$('#form1').validate(validationObj);");

            return sb.ToString();
        }

        public static string DateField(string renderID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("$('[id$=\"_" + renderID + "\"]').datepicker({ dateFormat: 'dd/mm/yy' });");
            return sb.ToString();
        }

        public static string ImageUploadControlScript(string renderID, string url)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("$('[id$=btn_" + renderID + "]').click(function () {");
                sb.Append("$.fancybox.open({");
                    sb.Append("href: '" + url + "',");
                    sb.Append("type: 'ajax',");
                    sb.Append("padding: 5");
                sb.Append("});");
            sb.Append(" });");
            return sb.ToString();
        }

        public static string ClearControl(string renderID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("$('[id$=\"_" + renderID + "\"]').parent().append(\"<a id='btnUploadClear' class='cropzoom_upload button' href='#'>Clear Photo</a>\");");
            sb.Append("$('[id$=btnUploadClear]').on('click', function (e) { $('[id$=\"_" + renderID + "\"]').val(''); $('[id$=resultImg]').attr('src',' '); });");
            return sb.ToString();
        }

        public static string AcceptNumber(string renderID, string messageControlID, string message)
        {
            StringBuilder sb = new StringBuilder();

            message = (message == string.Empty) ? Constants.NUMBER_MESSAGE : message;

            sb.Append("$('[id$=\"_" + renderID + "\"]').keypress(function (e) {");
            sb.Append("if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {");
            sb.Append("$('#" + messageControlID + "').html('" + message + "');");
            sb.Append("return false;");
            sb.Append("} else {");
            sb.Append("$('#" + messageControlID + "').html(' ');");
            sb.Append("return true;");
            sb.Append("}});");

            return sb.ToString();
        }

        public static string UniqueFilename(string filename, string foldername)
        {
            string newfilename = filename;
            string FileImageFolder = foldername;

            for (int i = 1; File.Exists(FileImageFolder + newfilename); i++)
            {
                newfilename = filename.Insert(filename.LastIndexOf('.'), "(" + i + ")");
            }

            return newfilename;
        }

        public static string croppedImageUpload(string _TempFolderPath, string _ActualImgPath, string imageName, string newName = "")
        {

            imageName = HttpUtility.UrlDecode(imageName);
            string strImgName = imageName.Substring(imageName.LastIndexOf('/') + 1, imageName.Length - (imageName.LastIndexOf('/') + 1));
            String uniqueFile = strImgName;

            if (strImgName != "")
            {
                if (strImgName.Substring(0, 4).ToLower() == "crop")
                {
                    newName = strImgName.Replace("crop", "");
                }
                else
                {
                    newName = strImgName;
                }

                string strFileNameWithPath = HttpContext.Current.Server.MapPath(_TempFolderPath + strImgName);
                string strDirectoryPath = HttpContext.Current.Server.MapPath(_ActualImgPath);

                if (!System.IO.Directory.Exists(strDirectoryPath))
                {
                    Directory.CreateDirectory(strDirectoryPath);
                }

                uniqueFile = UniqueFilename(newName, strDirectoryPath);
                FileInfo theFile = new FileInfo(strDirectoryPath + "\\" + uniqueFile);

                if (theFile.Exists)
                {
                    File.Delete(strDirectoryPath + uniqueFile);
                }

                File.Copy(strFileNameWithPath, strDirectoryPath + "\\" + uniqueFile);

                FileInfo theNewFile = new FileInfo(strFileNameWithPath);
                if (theNewFile.Exists)
                {
                    File.Delete(strFileNameWithPath);
                }
            }

            return uniqueFile;
        }

        public static void SaveJpeg(string path, Bitmap img, long quality)
        {            
            EncoderParameter qualityParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
            ImageCodecInfo jpegCodec = GetEncoderInfo("image/jpeg");

            if (jpegCodec == null)
                return;

            EncoderParameters encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = qualityParam;

            img.Save(path, jpegCodec, encoderParams);
        }

        private static ImageCodecInfo GetEncoderInfo(string mimeType)
        {   
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();         
            for (int i = 0; i < codecs.Length; i++)
                if (codecs[i].MimeType == mimeType)
                    return codecs[i];
            return null;
        }

        public static void ResizeImage(int ResizeWidth, int ResizeHeight, string imageSource)
        {
            int width   = ResizeWidth;
            int height  = ResizeHeight;

            ImageMedia img = ImageMedia.Create(File.ReadAllBytes(imageSource));
            img.Resize(width, height);
            File.Delete(imageSource);
            File.WriteAllBytes(imageSource, img.ToByteArray());
        }

        public static string GetValidFilePath(string imagePath, string pagename, bool useThumb)
        {
            Page page = (Page)HttpContext.Current.Handler;
            string retPath = "";
            string defImage = "";
            string mainpath = "";

            switch (pagename.ToUpper())
            {
                case "PDF":
                    mainpath = "~/media/pdf/";
                    defImage = "#";
                    break;
                case "VIDEO":
                    if (useThumb)
                        mainpath = "~/media/video/";
                    else
                        mainpath = "~/media/video/";

                    defImage = "#";
                    break;
                case "IMAGE":
                    if (useThumb)
                        mainpath = "~/media/images/content/thumb_";
                    else
                        mainpath = "~/media/images/content/";

                    defImage = "#";
                    break;
            }

            if (!String.IsNullOrEmpty(imagePath))
            {
                retPath = mainpath + imagePath;
                if (File.Exists(HttpContext.Current.Server.MapPath(mainpath + imagePath)))
                    return page.ResolveUrl(retPath);
                else
                    return defImage;
            }
            else
            {
                retPath = defImage;
            }
            return retPath;
        }

        public static String FormatUploadedFile(string fileToTidy)
        {
            String filename = HttpUtility.UrlDecode(fileToTidy);
            filename = FormatURL(Path.GetFileNameWithoutExtension(filename)) + Path.GetExtension(filename);
            return filename;
        }

        public static String FormatURL(string urlToTidy)
        {
            var url = urlToTidy.Trim().ToLower();
            url = url.Replace("  ", " ").Replace(" - ", " ").Replace(" ", "-").Replace(",", "").Replace("...", "").Replace("&", "_n_").Replace(".", "_").Replace("#", "_h_").Replace("?", "_q_").Replace("%", "_");
            return url;
        }

        public static void CopyToStream(Stream input, FileStream output)
        {
            byte[] buffer = new byte[16 * 1024];
            int bytesRead;

            while ((bytesRead = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, bytesRead);
            }

        }

        public static void SaveStreamAsBitmap(Stream input, String filepath)
        {
            Bitmap bmpThumbImage = new Bitmap(input);
            bmpThumbImage.Save(filepath);
        }

        public static string SanitizeUrl(string input)
        {
            return input.Replace(":", "").Replace("&", "-and-").Replace(" ", "-").Replace("/", "").Replace(",", "").ToLower().ToLower().Replace("<br/>", "_").ToLower().Replace("<br>", "_").Replace("'", "").ToLower().Replace("\"", "").ToLower();
        }

        public static string GetStringFromSanitizeURL(string input)
        {
            return input.Replace("-and-", "&").Replace("-", " ").Replace("_", " ");
        }

        public static void GenerateMetaTags(Application application, PlaceHolder placeHolder)
        {
            var page = HttpContext.Current.Handler as Page;

            //Set Page Title
            if (!String.IsNullOrEmpty(application.MetaTitle))
                page.Title = GetPageTitle(application.MetaTitle);            

            //Set Meta Tag Keywords                
            if (!String.IsNullOrEmpty(application.MetaKeyWord))
                placeHolder.Controls.Add(GetHtmlMeta("keywords", application.MetaKeyWord));

            //Set Meta Tag Description               
            if (!String.IsNullOrEmpty(application.MetaDesc))
                placeHolder.Controls.Add(GetHtmlMeta("description", application.MetaDesc));
        }
    }

    public static class Util
    {
        public static T Parse<T>(object value)
        {
            try { return (T)System.ComponentModel.TypeDescriptor.GetConverter(typeof(T)).ConvertFrom(value.ToString()); }
            catch (Exception) { return default(T); }
        }

        //static method to truncate descriptions to a certain size
        public static String truncateDescription(String description, int strLenght)
        {
            if (description == null || description.Equals(""))
                return ""; //return the empty string

            if (description.Length <= strLenght)
                return description;


            //get the first N chars and count the words
            String first_N_Chars = description.Substring(0, strLenght);

            List<String> word_list = SplitIntoWords(first_N_Chars, false);

            int trucateLimit =
                first_N_Chars.LastIndexOf(word_list[word_list.Count - 1], StringComparison.OrdinalIgnoreCase);

            first_N_Chars = first_N_Chars.Substring(0, trucateLimit);

            //add three dots and return the string
            return first_N_Chars + " ... ";
        }

        private static List<String> SplitIntoWords(String compoundWords, bool areKeywords)
        {
            if (String.IsNullOrEmpty(compoundWords))
                return new List<String>();

            //replace all punctuation with spaces
            StringBuilder compoundWordsBuilder = new StringBuilder(compoundWords);
            compoundWordsBuilder.Replace(",", " ");

            if (!areKeywords)
                compoundWords = compoundWords.Replace(";", " ");

            //BUG FIX: stop removing dots to allow keywords such as asp.net
            //compoundWordsBuilder.Replace(".", " ");
            //added in extra to corporate content to remove quatation marks
            compoundWordsBuilder.Replace("\"", "");
            //compoundWordsBuilder.Replace("'", "");
            compoundWordsBuilder.Replace("!", " ");
            compoundWordsBuilder.Replace("?", " ");
            compoundWordsBuilder.Replace("%", " ");
            compoundWordsBuilder.Replace("\t", " ");
            compoundWordsBuilder.Replace("\n", " ");
            compoundWordsBuilder.Replace("\r\n", " ");

            //replace double spaces with singe space
            compoundWordsBuilder.Replace("  ", " ");

            String[] words;
            if (areKeywords)
                words = compoundWordsBuilder.ToString().Split(';');
            else
                words = compoundWordsBuilder.ToString().Split(' ');

            List<String> word_list = new List<String>();

            //eliminate the empty words
            foreach (String word in words)
            {
                if (!word.Trim().Equals(""))
                {
                    //verify that the word is not already present in the list
                    if (!word_list.Contains(word.Trim().ToLower()))
                    {
                        //append the word
                        word_list.Add(word.Trim().ToLower());
                    }
                }
            }

            return word_list;
        }

        public static String GetAlliasString(string input)
        {
            return input.Replace(" ", "-").Replace("/", "-").ToLower().Replace("&", "_and_");
        }

        

    }
}
