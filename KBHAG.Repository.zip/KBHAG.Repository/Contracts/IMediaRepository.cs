﻿using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;


namespace KBHAG.Repository
{
    public interface IMediaRepository
    {
        SlideShow GetSlideShowByID(int id);
    }
}
