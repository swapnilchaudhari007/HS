﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class VideoView : System.Web.UI.Page
    {
        #region Declaration
        int VideoID = 0;
        #endregion

        #region Method
        private void GetEventData()
        {
            var repo = new ApplicationRepository();
            var videoData = repo.GetVideoByID(VideoID);
            if (videoData != null)
            {
                this.lblTitle.Text = videoData.Title;
                this.lblDesc.Text = videoData.Desc;
                this.lblEmbedCode.Text = videoData.EmbedCode;
            }
        }

        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.EditVideo.Visible = true;
                this.EditVideo.HRef = Page.ResolveUrl("~/administrator/index.aspx?page=video&action=e&section=applications&id=" + VideoID);
            }
            else
            {
                this.EditVideo.Visible = true;
                this.EditVideo.HRef = "#";
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                VideoID = (Page.RouteData.Values["id"] != null) ? int.Parse((Page.RouteData.Values["id"] as string)) : 0;

                GetEventData();

                //Current Menu Id for Header
                var menu = new MenuRepository();
                BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.AddToEnd = new List<BreadCrumbDTO>();
                bc.AddToEnd.Add(new BreadCrumbDTO
                {
                    LinkName = this.lblTitle.Text,
                    LinkUrl = Request.Url.AbsolutePath
                });                

                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_VIDEOS);

                Authorized();
            }
        }

        #endregion

        #region WebMethod

        #endregion
                
    }
}