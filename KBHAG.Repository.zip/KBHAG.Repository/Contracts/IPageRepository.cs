﻿using KBHAG.Model;
using System.Collections.Generic;

namespace KBHAG.Repository
{
    public interface IPageRepository
    {
        FormPage GetFormPageByAllias(string allias);

        List<Layout> GetLayout();
        string GetLayoutHTML(int layoutid);
        
        CMSPage GetPageByPageID(int pageid);
        int AddPage(CMSPage PageDTO);
        void UpdatePage(CMSPage PageDTO);
        void UpdateJavaScript(int pageid, string javascript);
        List<CommonDTO> GetPagesByMenuID(int menuid);

        PageData GetPageDataByID(int id);
        List<ViewPageData> GetPageContentByPageID(int pageid);
        void AddPageData(PageData PageDataDTO);
        void UpdatePageData(PageData PageDataDTO);
        void UpdatePageImage(int pageDataId, string imageFileName);
        
        List<ViewMapLayoutStructure> GetMapLayoutStructureByLayoutID(int layoutid);

        void PublishPage(PagePublish PagePublish);
        PagePublish GetPublishPageByMenuID(int id);

        string GetTitleByIDAndType(int id, string type);
    }
}
