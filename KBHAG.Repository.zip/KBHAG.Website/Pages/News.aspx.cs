﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class News : System.Web.UI.Page
    {
        #region Declaration
            int NewsID = 0;            
        #endregion

        #region Method
        private void GetNewsData()
        {
            var repo = new ApplicationRepository();
            var newsData = repo.GetNewsByID(NewsID);
            if (newsData != null)
            {
                this.lblTitle.Text = newsData.Title;
                this.lblContent.InnerHtml = newsData.Content;                
            }
            this.lnkBack.NavigateUrl = RoutingHelpers.GetNewsURL();

        }

        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.EditNews.Visible = true;
                this.EditNews.HRef = Page.ResolveUrl("~/administrator/index.aspx?action=e&section=applications&page=news&id=" + NewsID);                
            }
            else
            {
                this.EditNews.Visible = false;
                this.EditNews.HRef = "#";                
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                NewsID = (Page.RouteData.Values["id"] != null) ? int.Parse(Page.RouteData.Values["id"] as string) : 0;                
                GetNewsData();
                Authorized();

                BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.AddToEnd = new List<BreadCrumbDTO>();
                bc.AddToEnd.Add(new BreadCrumbDTO
                {
                    LinkName = this.lblTitle.Text,
                    LinkUrl = Request.Url.AbsolutePath
                });
                
                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_NEWS);
            }
        }

        #endregion

        #region WebMethod

        #endregion
    }
}