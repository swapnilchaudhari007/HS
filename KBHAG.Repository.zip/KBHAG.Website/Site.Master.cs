﻿using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


namespace KBHAG.Website
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {

        #region Declaration
            public PageDTO MasterPageDTO { get; set; }
        #endregion

        #region Method
            
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}