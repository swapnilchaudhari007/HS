﻿using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Administrator.Manage
{
    public partial class ManageShowcase : System.Web.UI.Page
    {

        #region Declaration
        public string uploadUrl = "";
        #endregion

        #region Method
        private void GetData()
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<HomePage>();
                repo.UnitOfWork = uow;
                var query = repo.GetMany(i => i.Type == "HomePage").ToList();

                foreach (var item in query)
                {
                    switch (item.Key)
                    {
                        case "SpotLight.Header":
                            this.txtHeader.Text = item.Value;
                            break;
                        case "SpotLight.Text":
                            this.txtText.Text = item.Value;
                            break;
                        case "SpotLight.Image":
                            this.hidden_img_Image.Value = item.Value;
                            this.img_Image.Src = WebsiteHelpers.GetAbsolutePath(item.Value);
                            uploadUrl = Page.ResolveUrl("~/Manage/photoupload.aspx?gridheight=550&gridwidth=1000&imageheight=100&imagewidth=200&mediascript=fnImageUpload&isalbum=n&mediafield=img_Image");
                            break;
                        case "SpotLight.Url":
                            this.txtUrl.Text = item.Value;
                            break;                        
                        default:
                            //Not Implemented
                            break;
                    }
                }
            }
        }

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetData();    
            }            
        }
       
        protected void SubmitHandler(object sender, EventArgs e)
        {
            DynamicForm dynamicPageForSubmit = new DynamicForm
            {
                FormDTO         = Admin.FormDTO,
                ControlHolder   = this.ControlHolder
            };

            try
            {
                using (var uow = new KBHAGUnitOfWork())
                {
                    var repo = new GenericRepository<HomePage>();
                    repo.UnitOfWork = uow;

                    List<string> spotList = new List<string> { "Header", "Text", "Url" };

                    foreach (var item in spotList)
                    {
                        var dataHeader = repo.Get(i => i.Key == "SpotLight." + item);
                        if (dataHeader != null)
                        {
                            TextBox txt = (TextBox)this.ControlHolder.FindControl("txt" + item);
                            dataHeader.Value = txt.Text;
                        }
                        repo.Update(dataHeader);
                    }

                    HiddenField hiddenField = (HiddenField)this.ControlHolder.FindControl("hidden_img_Image");
                    string ImageName = string.Empty;
                    if (hiddenField.Value.ToLower().IndexOf(Constants.TEMP_IMAGE_FOLDER_PATH) > -1)
                    {
                        ImageName = WebsiteHelpers.croppedImageUpload(Page.ResolveUrl("~/" + Constants.TEMP_IMAGE_FOLDER_PATH), Page.ResolveUrl("~/Media/Images/content/"), hiddenField.Value);
                        ImageName = "Media/Images/content/" + ImageName;
                        this.img_Image.Src = WebsiteHelpers.GetAbsolutePath(ImageName);
                    }
                    else
                    {
                        ImageName = hiddenField.Value;
                    }                        

                    var dataImage = repo.Get(i => i.Key == "SpotLight.Image");
                    if (dataImage != null)
                    {
                        dataImage.Value = ImageName;
                    }
                    repo.Update(dataImage);

                    uow.Commit();
                }               

                dynamicPageForSubmit.ShowResponseMessage(Constants.MESSAGE_TYPE.success, Constants.UPDATE_MESSAGE);
            }
            catch (Exception ex)
            {
                dynamicPageForSubmit.ShowResponseMessage(Constants.MESSAGE_TYPE.error, "<br/>" + ex.ToString());
            }
        }

        protected void CancelHandler(object sender, EventArgs e)
        {
            Response.Redirect("~/administrator/manage/ManageShowcase.aspx?section=" + Admin.FormDTO.Section + "&page=" + Admin.FormDTO.PageAllias + "&action=a");
        }
        #endregion

        #region WebMethod

        #endregion
                
    }
}