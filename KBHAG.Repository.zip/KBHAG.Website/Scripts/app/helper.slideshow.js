﻿/* instructions for css for jacarousel
Developed by Rajesh Makhija for Media Fusion
Kindly check before making changes to this script.

Adjust Css with special attention to these
jcarousel-clip-horizontal css computes to item size by division with max no of items on carousel
item width in css should match img width height css name is jcarousel-item-horizontal or vertical as per requirement
css will need to be adjusted as per requirement
img rollover has to be given in css at the following class
.jcarousel-skin-tango .jcarousel-item-horizontal img.highlight or vertical accordingly
script has been adjusted only for horizontal. Will need setup for vertical once

setCarousel({
    Type: 'json',
    Data: strProducts,
    JsonProcess: simpleParser,
    ListObject: "a",
    OnPageId: carOnPageId,
    Direction: 'H',
    Display: 4,
    ScrollSize: 1,
    ShowTooltip: false,
    TipPos: 'Top',
    TipOffset: 2,
    TipDelay: 100,
    OnClick: clickLi
});

setupSlideShow({
    DivImage: 'ImagePlaceHolder',
    DivText: $('#imageText'),
    Type: 'div',
    ShareId: shareid, --optional if share is required
    ShareUrl: shareUrl,
    ShareColumn: 'share-url',
    ImageViewClass: 'image_show_viewer'
});
*/

/*Version 2.-*/

var oData;
var carousel;
var carouselOn = false;
var baseLeft = 140;
var maxsize = 700;
var animtime = 500 * 2;
var timing = 5000;

// repeat these in setup slideshow to ensure page catches these ids after render
var btnLeft = $('#left_arow');
var btnRight = $('#right_arow');
var btnPause = $('#pause_arow');
var divImage = $('#ImagePlaceHolder');
var divText = $('#imageText');
var divShare = "";
var divShareUrl = "";

var type = "xml";
var data = ""
var imgNode = "image";
var imgColumn = "imgfile";
var textColumn = "";
var shareColumn = "";
var textScroll = true;
var redirectUrl = "";
var imageViewClass = "image_show_viewer";

var currentIndex = 0;
var firstShow = true;
var maxIndex = 0;
var rootPath = '/';
var currentImage = "";
var newImage = "";
var loadIndex = 0;
var showOn = true;
var timeoutID;
var api;
var scrollSize = 1;
var instanceExists = "";
var listLo = "";
var HiLo = "";

function mfCarousel(data) {
    $('#loader').show();
    oData = data;
    switch (oData.Type) {
        case "json":
            oData.JsonProcess(oData.Data, startCarousel);
            break;
        case undefined:
            startCarousel();
            break;
    }
}

function startCarousel() {
    //reading data object
    id = oData.OnPageId;
    ctype = oData.Direction;
    carMaxVis = Number(oData.Display);
    toolsOn = oData.ShowTooltip;
    mRight = "10px";

    lo = oData.ListObject;
    listLo = oData.ListObject;
    totalItems = Number($('#' + id).children().size());
    maxWidth = oData.maxWidth;
    itemWidth = oData.itemWidth;
    AutoCenter = oData.AutoCenter;

    if(oData.ScrollSize != null && oData.ScrollSize!=undefined)
        scrollSize = oData.ScrollSize;

    if (oData.MarginRight != undefined)
        mRight = oData.MarginRight;

    //setting tooltip
    if (oData.TipPos == undefined)
        tpos = "Top";
    else
        tpos = oData.TipPos;

    if (oData.TipOffset == undefined)
        toff = 2;
    else
        toff = oData.TipOffset;

    if (oData.TipDelay == undefined)
        tdelay = 2;
    else
        tdelay = oData.TipDelay;


    //this is the image roll over script for hover
    $('#' + id + ' li' + lo).hover(function () {
        $(this).toggleClass('highlight');
    });

    //click function for li
    if (oData.OnClick != undefined) {
        click = oData.OnClick;
        if (click) {
            $('#' + id + ' li ' + lo).click(function () {
                click($(this).parent().index(), $(this).attr('rel'));
            });
        }
    }

    //setting up jcarousel
    carouselOn = true;
    if (totalItems > carMaxVis) {
        if (oData.Direction == "V") {
            $('#' + id).jcarousel({
                vertical: true,
                visible: carMaxVis,
                scroll: scrollSize,
                itemFallbackDimension: itemWidth
            });
        } else {
            $('#' + id).jcarousel({
                visible: carMaxVis,
                scroll: scrollSize,
                itemFallbackDimension: itemWidth
            });
        }
        carousel = $('#' + id).data('jcarousel');
    } else {
        //$('#' + id).css("margin-top", "10px");
        if (oData.Direction != "V") {
            var totalSize = 0;
            for (var i = 0; i < totalItems; i++) {
                var item = $('#' + id).find("li").eq(i);
                totalSize += itemWidth;
                if (i < totalItems - 1) {
                    totalSize += 10;
                    item.css("margin-right", mRight);
                }
            }

            offL = (maxWidth - totalSize) / 2
            if (AutoCenter) {
                $('#' + id).css("position", "relative");
                $('#' + id).css("left", offL.toString() + "px");
            }
        }
    }

    //if lesser than max, this is the thumb centering mechanism
    /*if (totalItems <= carMaxVis) {
        unitWidth = Number($('#' + id + ' li').width()); // width of each li
        clipWidth = Number($('.jcarousel-clip-horizontal').width()); //width of the clip mask of carousel
        unitCount = Number($('#' + id + ' li').length); //No of items on carousel
        difference = (clipWidth - (carMaxVis * unitWidth)) / 2; //difference between carousel width and required with of max items
        actualItemSize = Number($('#' + id + ' li img').width()); //need right offset as acutual image size and unitwidth is different.
        margin = $('.jcarousel-item-horizontal').css('margin-left'); // also need to offset left margin set in css.
        offset = unitWidth - actualItemSize - Number(margin.substr(0, (margin.length - 2)));
        displace = (clipWidth - (unitCount * unitWidth) + offset) / 2; // displace width for centereing.
        displace = displace - difference; // adjusting the displacement with difference to get exact centering.

        carousel.buttonNext.hide();
        carousel.buttonPrev.hide();
        $('#' + id).css('left', displace + 'px');
    }*/

    //this sets up the tooltip
    if (toolsOn) {
        $('#' + id + ' li').tipTip(
        {
            attribute: "title",
            maxWidth: "auto",
            edgeOffset: toff,
            defaultPosition: tpos,
            delay: tdelay
        });
    }

}

function getCarousel() {
    return carousel;
}

function setupSlideShow(sData) {

    restart = true;

    btnLeft = $('#left_arow');
    btnRight = $('#right_arow');
    btnPause = $('#pause_arow');
    //divImage = $('[id$="ImagePlaceHolder"]');
    divImage = $('div[id^="ImagePlaceHolder"]');
    divText = $('#imageText');
    hideController();
    
    if (sData.Data == null && sData.Type != "li" && sData.Type != "div")
        return false;

    if (sData.DivImage != null && sData.DivImage != undefined)
        divImage = $('[id=' + sData.DivImage + ']');

    if (instanceExists != divImage.attr('id')) {
        instanceExists = divImage.attr('id');
    } else {
        restart = false;
        restartInstance(sData.Data);
        return true;
    }

    tempstr = divImage.css('width')
    maxsize = Number(tempstr.substr(0, tempstr.length - 2));

    if (sData.AnimTime != null && sData.AnimTime != undefined)
        animtime = sData.AnimTime;

    if (sData.Timing != null && sData.Timing != undefined)
        timing = sData.Timing;

    if(sData.BtnLeft != null && sData.BtnLeft != undefined)
        btnLeft = sData.BtnLeft;

    if (sData.BtnRight != null && sData.BtnRight != undefined)
        btnRight = sData.BtnRight;

    if (sData.BtnPause != null && sData.BtnPause != undefined)
        btnPause = sData.BtnPause;

    if (sData.DivText != null && sData.DivText != undefined)
        divText = sData.DivText;

    if (sData.ShareId != null && sData.ShareId != undefined && !app.utils.StringIsBlank(sData.ShareId))
        divShare = sData.ShareId;

    if (sData.ShareUrl != null && sData.ShareUrl != undefined && !app.utils.StringIsBlank(sData.ShareUrl))
        divShareUrl = sData.ShareUrl;


    if (sData.TextScroll != null && sData.TextScroll != undefined)
        textScroll = sData.TextScroll;

    if (sData.ImageFolder != null && sData.ImageFolder != undefined)
        rootPath = sData.ImageFolder;

    if (sData.Type == null && sData.Type != undefined)
        type = "li";
    else
        type = sData.Type;

    if (sData.ImageNode != null && sData.ImageNode != undefined)
        imgNode = sData.ImageNode;

    if (sData.ImageColumn != null && sData.ImageColumn != undefined)
        imgColumn = sData.ImageColumn;

    if (sData.TextColumn != null && sData.TextColumn != undefined)
        textColumn = sData.TextColumn;

    if (sData.ShareColumn != null && sData.ShareColumn != undefined)
        shareColumn = sData.ShareColumn;


    if (sData.RedirectAfterFinish != null && sData.RedirectAfterFinish != undefined)
        redirectUrl = sData.RedirectAfterFinish;

    if (sData.ImageViewClass != null && sData.ImageViewClass != undefined)
        imageViewClass = sData.ImageViewClass;

//    divImage.load(function () {
//        if($(this).attr('id') == 'div_' + newImage)
//            $(this).fadeIn('slow', 'swing');
//    });

    if (btnLeft.length > 0) {

        btnLeft.click(function () {
            if ($(this).hasClass('prevInActive'))
                return false;

            stopShow();
            if (currentIndex > 0) {
                currentIndex--;
                loadItem();
            }

        });

        btnRight.click(function () {
            if ($(this).hasClass('nextInActive'))
                return false;

            stopShow();
            if (currentIndex < (maxIndex - 1)) {
                currentIndex++;
                loadItem();
            }

        });

        btnPause.click(function () {
            if ($(this).hasClass('pauseInActive'))
                return false;

            if ($(this).hasClass('pause')) {
                stopShow();
            } else {
                startShow();
            }
        });
    }

    if (divText.length > 0) {

        scr = divText.parent();
        if (scr.data('jsp') == undefined) {
            scr.jScrollPane({ showArrows: true, scrollbarWidth: 13, horizontalGutter: 10, arrowSize: 16 });
        }

        api = scr.data('jsp');
    }

    if (restart)
        restartInstance(sData.Data);
}

function GetAlbumHeight() {
    tempstr = divImage.css('height')
    return Number(tempstr.substr(0, tempstr.length - 2));
}

function GetAlbumWidth() {
    tempstr = divImage.css('width')
    return Number(tempstr.substr(0, tempstr.length - 2));
}

function GetAlbumMainDiv() {
    return divImage;
}

function restartInstance(dataObj) {
    window.clearTimeout(timeoutID);
    data = dataObj;

    switch (type) {
        case "xml":
            maxIndex = $(data).find(imgNode).length;
            divImage.html('');
            break;
        case "json":
            maxIndex = data.length;
            divImage.html('');
            break;
        case "li":
            maxIndex = $("#" + id).find('li').size();
            divImage.html('');
            break;
        case "div":
            maxIndex = divImage.find('div').size();
            break;
    }

    if (maxIndex == 0)
        return false;

    if (maxIndex < 2) {
        resetController();
        deActivateController();
        showOn = false;
    } else {
        showOn = true;
        resetController();
    }

    currentIndex = 0;
    startSlideShow();
}

function clickShow(no) {
    stopShow();
    currentIndex = Number(no);
    setHighLight();
    loadItem();
}

function checkButtons() {
    if (!showOn) {
        if (currentIndex == (maxIndex - 1))
            btnRight.removeClass('next').addClass('nextInActive');
        else
            btnRight.addClass('next').removeClass('nextInActive');

        if (currentIndex == 0)
            btnLeft.removeClass('prev').addClass('prevInActive');
        else
            btnLeft.addClass('prev').removeClass('prevInActive');
    }
}

function deActivateController() {
    btnLeft.removeClass('prev').addClass('prevInActive');
    btnRight.removeClass('next').addClass('nextInActive');
    if (btnPause.hasClass('pause'))
        btnPause.removeClass('pause').addClass('pauseInActive');
}

function hideController() {
    btnLeft.hide();
    btnRight.hide();
    btnPause.hide();
}

function playController() {
    btnLeft.removeClass('prev').addClass('prevInActive');
    btnRight.removeClass('next').addClass('nextInActive');
    if (btnPause.hasClass('play'))
        btnPause.removeClass('play').addClass('pause');

    btnPause.show();
    checkButtons();
}

function stopController() {
    btnLeft.removeClass('prevInActive').addClass('prev');
    btnRight.removeClass('nextInActive').addClass('next');

    if (btnPause.hasClass('pause'))
        btnPause.removeClass('pause').addClass('play');

    if (maxIndex > 1)
        btnPause.show();

    checkButtons();
}

function showController() {
    btnLeft.show();
    btnRight.show();
    btnPause.show();
}

function resetController() {
    btnLeft.show();
    btnRight.show();
    btnPause.show();
    if (btnLeft.hasClass('prevInActive'))
        btnLeft.removeClass('prevInActive').addClass('prev');

    if (btnRight.hasClass('nextInActive'))
        btnRight.removeClass('nextInActive').addClass('next');

    if (btnPause.hasClass('pauseInActive'))
        btnPause.removeClass('pauseInActive').addClass('pause');
}

function loadItem() {
    index = currentIndex;
    t_newImage = "image_" + currentIndex;
    if ($('#div_' + t_newImage).length > 0) {
        newImage = t_newImage;

        //change the text
        txt = $('#' + t_newImage).attr('alt');        
        if (divText.length > 0) {
            divText.fadeOut('slow', function () {
                divText.html(txt);
                divText.fadeIn('slow', function () {
                    api.reinitialise();
                });
            });
        }

        if (!app.utils.StringIsBlank(divShare) && !app.utils.StringIsBlank(divShareUrl)) {
            var ashare = "<a href='" + divShareUrl + $('#div_' + t_newImage).attr(shareColumn) + "'>Share this picture</a>";
            $('#' + divShare).html(ashare);
        }

        //now change the image
        showNewImage();

    } else {
        switch (type) {
            case 'xml':
                img = rootPath + $(data).find(imgNode).eq(index).attr(imgColumn);

                if ($.trim(textColumn) > 0)
                    txt = $(data).find(imgNode).eq(index).attr(textColumn)
                else
                    txt = $(data).find(imgNode).eq(index).text();

                if (!app.utils.StringIsBlank(divShare) && !app.utils.StringIsBlank(divShareUrl) && !app.utils.StringIsBlank(shareColumn)) {
                    shareurl = data[index][textColumn];
                    var ashare = "<a href='" + divShareUrl + shareurl + "'>Share this picture</a>";
                    $('#' + divShare).html(ashare);
                }

                break;
            case 'json':
                img = rootPath + data[index][imgColumn];
                txt = data[index][textColumn];
                if (!app.utils.StringIsBlank(divShare) && !app.utils.StringIsBlank(divShareUrl) && !app.utils.StringIsBlank(shareColumn)) {
                    shareurl = data[index][textColumn];
                    var ashare = "<a href='" + divShareUrl + shareurl + "'>Share this picture</a>";
                    $('#' + divShare).html(ashare);
                }

                break;
            case 'li':
                txt = $('#' + id).find("li").eq(index).attr(textColumn);
                img = $('#' + id).find("li").eq(index).attr(imgColumn);
                if (!app.utils.StringIsBlank(divShare) && !app.utils.StringIsBlank(divShareUrl) && !app.utils.StringIsBlank(shareColumn)) {
                    shareurl = $('#' + id).find("li").eq(index).attr(shareColumn);
                    var ashare = "<a href='" + divShareUrl + shareurl + "'>Share this picture</a>";
                    $('#' + divShare).html(ashare);
                }

                break;
        }

        if (divText.length > 0) {
            divText.fadeOut('slow', function () {
                divText.html(txt);
                divText.fadeIn('slow', function () {
                    api.reinitialise();
                });
            });
        }

        //divText.html(txt);
        newImage = "image_" + currentIndex;
        //loadIndex++;
        strImg = '<div class="' + imageViewClass + '" style="display:none;" id="div_' + newImage + '"><img src="' + img + '" id="' + newImage + '" alt = "' + txt + '" /></div>';
        divImage.append(strImg);


        //$('#' + newImage).bind('load', showNewImage);
        $('#' + newImage).bind('load', function () {
            var img = new Image();
            img.src = $(this).attr('src');
            //mysize = this.height;
            mysize = img.height;
            maxHeight = divImage.height();
            var offSet = 0;

            if (mysize < maxHeight) {
                offSet = (maxHeight - mysize) / 2;
                $('#' + newImage).attr('style', "margin-top:" + offSet.toString() + "px;");
            }

            //$('#div_' + id).attr('style', "z-index:" + loadIndex);
            //$('#div_' + currentIndex).addClass('loaded');
            showNewImage()
        });
    }

    if (carousel != null || carousel!= undefined)
        carousel.scroll($.jcarousel.intval(currentIndex));
}

function setHighLight() {
    if (carouselOn) {
        $('#' + id + ' li ' + listLo).removeClass('selected');
        $('#' + id + ' li ' + listLo).eq(currentIndex).removeClass('highlight');
        $('#' + id + ' li ' + listLo).eq(currentIndex).addClass('selected');
    }
}

function showNewImage() {
    //setHighLight();
    //checkButtons();
    var showImage = "image_" + currentIndex;

////    if ($('#' + showImage).length > 0 && !$('#div_' + showImage).hasClass('loaded')) {
////        getCenter();

//    } else {
        setHighLight();

        if (firstShow) {
            $('#div_' + showImage).addClass('ss_currentShow');
            firstShow = false;
            $('#div_' + showImage).fadeIn(animtime, function () {
            });

        } else {

            if (!showOn)
                deActivateController();

            $('.ss_currentShow').each(function () {
                $(this).stop(true, true).fadeOut(animtime, function () {
                    $(this).hide();
                });
                $(this).removeClass('ss_currentShow')
            });
                //        $('#div_' + currentImage).fadeOut(animtime, function () {
            //            $(this).hide();
            //        });

            $('#div_' + showImage).addClass('ss_currentShow');

            $('#div_' + showImage).stop(true, true).fadeIn(animtime, function () {
                if (!showOn)
                    stopController();

                checkButtons();
                //currentImage = newImage;
            });
        }

        if (showOn)
            timeoutID = window.setTimeout(nextImage, timing);
    //}
}

function getCenter() {
    var id = "image_" + currentIndex;
    window.setTimeout(function () {
        mysize = $('#' + id).height();
        maxHeight = divImage.height();
        var offSet = 0;

        if (mysize < maxHeight) {
            offSet = (maxHeight - mysize) / 2;
            $('#' + id).attr('style', "margin-top:" + offSet.toString() + "px;");
        }

        //$('#div_' + id).attr('style', "z-index:" + loadIndex);
        $('#div_' + id).addClass('loaded');
        showNewImage()

    }, 500);
}

function stopAndChange(ind) {
    stopShow();
    currentIndex = Number(ind);
    setHighLight();
    loadItem();
}

function nextImage() {
    window.clearTimeout(timeoutID);
    if (currentIndex < (maxIndex - 1)) {
        currentIndex++;
    } else {
        if (redirectUrl=="")
            currentIndex = 0;
        else
            window.location = redirectUrl;

    }
    loadItem();
}

function stopShow() {
    showOn = false;
    stopController();
    btnPause.removeClass('pause').addClass('play');
    window.clearTimeout(timeoutID);
}

function startShow() {
    showOn = true;
    btnPause.addClass('pause').removeClass('play');
    nextImage();
    playController();
}

function startSlideShow() {
    if (maxIndex > 1) {
        if (showOn)
            playController();
        else
            stopController();
    }

    loadItem();
}
