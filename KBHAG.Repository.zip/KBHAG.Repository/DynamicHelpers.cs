﻿using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;

namespace KBHAG.Repository
{
    public class DynamicHelpers
    {
        public static object GetClassFromString(string assemblyName, string typeName)
        {
            Type type = GetTypeFromName(assemblyName,typeName);

            return System.Activator.CreateInstance(type);
        }

        public static object GetGenericRepository(string assemblyName, string typeName)
        {            
            Type type = GetTypeFromName(assemblyName, typeName);

            Type repositoryOpenType = typeof(GenericRepository<>);
            Type repositoryClosedType = repositoryOpenType.MakeGenericType(type);

            return System.Activator.CreateInstance(repositoryClosedType);
        }

        public static System.Type GetTypeFromName(string assemblyName, string typeName)
        {
            Type type = Type.GetType(typeName, false);

            if (type == null)
            {

                Assembly assembly = Assembly.Load(assemblyName);                
                var types = from assemblyType in assembly.GetTypes()
                            where assemblyType.Name == typeName
                            select assemblyType;

                type = types.FirstOrDefault();
            }

            return type;
        }

        public static List<RowCollection> GetRowCollectionList(string model, int id)
        {
            List<RowCollection> rowCollection = new List<RowCollection>();
            KBHAGUnitOfWork uow = new KBHAGUnitOfWork();
            dynamic repo = GetGenericRepository(RepositoryConstants.MODEL_ASSEMBLY_NAME, model);
            repo.UnitOfWork = uow;
            dynamic data = repo.GetById(id);

            foreach (PropertyInfo info in data.GetType().GetProperties())
            {
                if (info.CanRead)
                {
                    RowCollection collection = new RowCollection
                    {
                        ColumnName = info.Name,
                        ColumnValue = RepositoryUtil.Parse<string>(info.GetValue(data, null))
                    };

                    rowCollection.Add(collection);
                }               
            }
            return rowCollection;
        }
    }
}
