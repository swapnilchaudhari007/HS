﻿using CKEditor.NET;
using KBHAG.Components;
using KBHAG.Data;
using KBHAG.Model;
using KBHAG.Repository;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class Form : System.Web.UI.Page
    {
        #region Declaration
            string FormType = string.Empty;
            int PageID = 0;
            string Model = string.Empty;
            string CallBackJSON = string.Empty;
            public string retUrl = string.Empty;
            string SuccessMessage = string.Empty;
        #endregion
        
        #region Method
            protected void RenderControls()
            {
                StringBuilder sbjQueryCode = new StringBuilder();

                KBHAGUnitOfWork uow = new KBHAGUnitOfWork();

                var repo = new GenericRepository<FormPage>();
                repo.UnitOfWork = uow;

                var page = repo.Get(i => i.Title == FormType);

                if (page == null)
                {
                    this.FormHolder.Visible = false;

                    DynamicForm dynamicForm = new DynamicForm();

                    dynamicForm.ShowResponseMessage
                    (
                        this.MessageHolder,
                        this.messageBox,
                        this.lblMessageHeading,
                        this.lblMessage,
                        Constants.MESSAGE_TYPE.error,
                        "Page does not exists!"
                    );
                    
                    return;
                }

                this.lblHeading.Text    = page.Title;
                PageID                  = page.PageID;
                Model                   = page.Model;
                CallBackJSON            = page.Callback;

                FormDTO DTO = new FormDTO 
                { 
                    Action  = "a",
                    Model   = page.Model,
                    PageID  = page.PageID                    
                };

                DynamicForm dynamicFormRender = new DynamicForm 
                { 
                    ControlHolder   = this.ControlHolder,
                    FormDTO         = DTO,
                    CallbackString  = page.Callback,
                    ControlUniqueID = "ctl00$ContentPlaceHolder1$"
                };

                var repoAdminStructure = new GenericRepository<FormStructure>();
                repoAdminStructure.UnitOfWork = uow;
                var pageStructure = repoAdminStructure.GetMany(i => i.PageID == page.PageID && i.Active == "Y").OrderBy(o => o.Index);

                dynamicFormRender.RenderControl(pageStructure.ToList());


            }            

            private void AfterSubmitHandler()
            {
                var json = JsonConvert.DeserializeObject<dynamic>(CallBackJSON);

                if (json != null)
                {
                    if (json.AfterSubmit != null)
                    {
                        if (json.AfterSubmit.Mail != null)
                        {
                            if (json.AfterSubmit.Mail == "Inquiry")
                            {
                                SendEnquiryMail();
                            }
                        }

                        if (json.AfterSubmit.Success != null)
                        {
                            SuccessMessage = json.AfterSubmit.Success;
                        }
                    }    
                }

            }

            private void SendEnquiryMail()
            {
                var repo = new ApplicationRepository();
                int referenceid = repo.GetLastestInquiryID();
                var enquiry = repo.GetInquiryById(referenceid);

                SendMail sendMail = new SendMail();

                //Send Thank you mail
                sendMail.ToName     = enquiry.ApplicantName;
                sendMail.ToEmail    = enquiry.EmailID;
                sendMail.InquiryThanksMail();


                SendMail sendMailAdmin = new SendMail();
                Dictionary<string, string> enquiryDataList = new Dictionary<string, string>();

                enquiryDataList.Add("#Type#", enquiry.TypeName);
                enquiryDataList.Add("#PartyName#", enquiry.PartyName);
                enquiryDataList.Add("#ApplicantName#", enquiry.ApplicantName);
                enquiryDataList.Add("#MobileNo#", enquiry.MobileNo);
                enquiryDataList.Add("#ContactNo#", enquiry.ContactNo);
                enquiryDataList.Add("#Email#", enquiry.EmailID);
                enquiryDataList.Add("#Address#", enquiry.Address);
                enquiryDataList.Add("#City#", enquiry.City);
                enquiryDataList.Add("#EventDate#", enquiry.EventDate);
                enquiryDataList.Add("#Message#", enquiry.Message);

                sendMailAdmin.InquiryAdminMail(enquiryDataList, enquiry.TypeName);

            }

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            FormType = (Page.RouteData.Values["type"] != null) ? Convert.ToString(Page.RouteData.Values["type"]) : "";

            RenderControls();
            if (Request.UrlReferrer == null)
                btnCancel.Visible = false;
            else
                retUrl = Request.UrlReferrer.ToString();

        }

        protected void SubmitHandler(object sender, EventArgs e)
        {
            FormDTO DTO = new FormDTO 
            { 
                PageID = PageID                
            };

            DynamicForm dynamicPageForSubmit = new DynamicForm
            {
                FormDTO         = DTO,
                ControlHolder   = this.ControlHolder
            };

            try
            {
                Dictionary<string, string> ModelStructureList = ModelStructureList = dynamicPageForSubmit.GetModelStructureList();        

                DataManager manager = new DataManager
                {
                    ID                      = 0,
                    Action                  = "a",
                    Model                   = Model,
                    ColumnsList             = ModelStructureList,
                    PrimaryKeyColumnName    = string.Empty,
                    ValidateColumn          = new List<string>()
                };

                if (manager.Manage() == Constants.SUCCESS_MESSAGE)
                {
                    AfterSubmitHandler();

                    SuccessMessage = (String.IsNullOrEmpty(SuccessMessage)) ? Constants.INSERT_MESSAGE : SuccessMessage;

                    dynamicPageForSubmit.ShowResponseMessage
                        (
                            this.MessageHolder,
                            this.messageBox,
                            this.lblMessageHeading,
                            this.lblMessage,
                            Constants.MESSAGE_TYPE.success, 
                            SuccessMessage
                        );
                    dynamicPageForSubmit.ClearControl();
                }
                else
                {
                    dynamicPageForSubmit.ShowResponseMessage
                        (
                            this.MessageHolder,
                            this.messageBox,
                            this.lblMessageHeading,
                            this.lblMessage,
                            Constants.MESSAGE_TYPE.block, 
                            Constants.EXISTS_LONG_MESSAGE
                        );
                }

            }
            catch (Exception ex)
            {
                dynamicPageForSubmit.ShowResponseMessage
                    (
                        this.MessageHolder,
                        this.messageBox,
                        this.lblMessageHeading,
                        this.lblMessage,
                        Constants.MESSAGE_TYPE.error, 
                        "<br/>" + ex.ToString()
                    );
            }
        }

        protected void ResetHandler(object sender, EventArgs e)
        {
            Response.Redirect(Request.Url.AbsolutePath);
        }
        
        #endregion

        #region WebMethod

        #endregion
                
    }
}