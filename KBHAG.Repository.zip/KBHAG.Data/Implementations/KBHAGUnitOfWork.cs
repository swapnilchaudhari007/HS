﻿namespace KBHAG.Data
{
    public class KBHAGUnitOfWork:UnitOfWork
    {
        public KBHAGUnitOfWork()
        {
            Context = new KBHAGContext();
        }
    }
}
