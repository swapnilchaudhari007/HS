﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace KBHAG.Website
{
    public partial class AlbumView : System.Web.UI.Page
    {
        #region Declaration
        public int albumid = 0;
        string allias = string.Empty;
        public string redirectUrl = string.Empty;
        public string showmsg = string.Empty;
        public string albumName = string.Empty;
        #endregion

        #region Method
        private void CreateAlbum()
        {
            var repo        = new ApplicationRepository();
            var albumData   = repo.GetSlideShowByID(albumid);

            if (albumData == null)
                Response.Redirect(Page.ResolveUrl("~/notfound.aspx"));

            //Page Meta tags
            this.Page.Title = WebsiteHelpers.GetPageTitle(albumData.Title);

            if (!String.IsNullOrEmpty(albumData.MetaKeyWord))
                this.MetaPlaceHolder.Controls.Add(WebsiteHelpers.GetHtmlMeta("keywords", albumData.MetaKeyWord));

            if (!String.IsNullOrEmpty(albumData.Desc))
                this.MetaPlaceHolder.Controls.Add(WebsiteHelpers.GetHtmlMeta("description", albumData.Desc));

            // Page Data
            if (albumData.Target.ToUpper() == "PROJECT")
                redirectUrl = Page.ResolveUrl("~/manage/AlbumManage.aspx?section=applications&page=slide-show&target=album&targetid=0&action=e&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT + "&id=" + albumid.ToString());
            else
                redirectUrl = Page.ResolveUrl("~/manage/AlbumManage.aspx?section=applications&page=slide-show&target=album&targetid=0&action=e&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT + "&id=" + albumid.ToString());

            this.lblAlbumTitle.Text = albumData.Title;

            //Album Media
            int cnt = 0;
            foreach (var item in repo.GetMediaByAlbumID(albumid))
            {
                HtmlGenericControl  li  = new HtmlGenericControl("li");
                HtmlImage           img = new HtmlImage();
                HtmlGenericControl  div = new HtmlGenericControl("div");

                if (cnt == 0)
                {
                    FirstImage.ImageUrl = WebsiteHelpers.GetAbsolutePath(Constants.IMAGE_FOLDER_PATH + item.FileName);
                    FirstImage.AlternateText = item.Caption;
                }

                li.Attributes.Add("rel", WebsiteHelpers.GetAbsolutePath(Constants.IMAGE_FOLDER_PATH + item.FileName));
                li.Attributes.Add("title", item.Caption);

                img.Src = WebsiteHelpers.GetAbsolutePath(Constants.IMAGE_FOLDER_PATH + "thumb_" + item.FileName);
                img.Alt = item.Caption;

                div.Controls.Add(img);

                li.Controls.Add(div);
                mycarousel.Controls.Add(li);
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                albumid     = (Page.RouteData.Values["id"] != null) ? int.Parse((Page.RouteData.Values["id"] as string)) : 0;
                allias      = (Page.RouteData.Values["albumname"] != null) ? Page.RouteData.Values["albumname"] as string : string.Empty;
                albumName   = WebsiteHelpers.ToTitleCase(WebsiteHelpers.ChangeReplaceSpace(allias));
                showmsg     = (!String.IsNullOrEmpty(Request.QueryString["message"])) ? "Y" : "N";

                //Event Data
                CreateAlbum();

                BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.AddToEnd = new List<BreadCrumbDTO>();
                bc.AddToEnd.Add(new BreadCrumbDTO
                {
                    LinkName = this.lblAlbumTitle.Text,
                    LinkUrl = Request.Url.AbsolutePath
                });

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_Albums);

                if (Request.UrlReferrer == null)
                    btnBack.NavigateUrl = Page.ResolveUrl("~/");
                else
                    btnBack.NavigateUrl = Request.UrlReferrer.ToString();

                if (CookieHandler.IsAuthorized() == false)
                    btnEdit.Visible = false;
                else
                    btnEdit.NavigateUrl = redirectUrl;

            }
        }
        #endregion
    }
}