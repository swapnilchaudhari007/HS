﻿using KBHAG.Components;
using KBHAG.Repository;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KBHAG.Website.Pages
{
    public partial class Events : System.Web.UI.Page
    {
        #region Declaration
        int EventID = 0;
        string EventType = "";
        #endregion

        #region Method
        private void GetEventData()
        {
            var repo = new ApplicationRepository();
            var eventData = repo.GetEventByID(EventID);
            if (eventData != null)
            {
                this.lblTitle.Text = eventData.Title;
                this.lblSubTitle.Text = eventData.SubTitle;
                this.lblType.Text = eventData.EventTypeName;

                if (eventData.StartDate.Date == eventData.EndDate.Date)
                    lblStartDate.Text = WebsiteHelpers.SubScriptDate(eventData.StartDate, "DF");
                else
                    lblStartDate.Text = WebsiteHelpers.SubScriptDate(eventData.StartDate, "DF") + " to " + WebsiteHelpers.SubScriptDate(eventData.EndDate, "DF");                

                if (!string.IsNullOrEmpty(eventData.TimeDesc))
                    this.lblTime.Text = "(" + eventData.TimeDesc + ")";
                else
                    this.lblTime.Visible = false;

                this.lblContent.InnerHtml = eventData.Content;
                this.lnkSection.Text = "Back to " + eventData.EventTypeName;

                BreadCrumb bc = this.Master.FindControl("BreadCrumb") as BreadCrumb;
                bc.AddToEnd = new List<BreadCrumbDTO>();
                if (eventData.EndDate.Date >= DateTime.Today)
                {
                    this.lnkSection.NavigateUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_UPCOMING);
                    this.lnkBack.NavigateUrl = RoutingHelpers.GetEventAllURL("all", Constants.EVENT_UPCOMING);
                    bc.AddToEnd.Add(new BreadCrumbDTO
                    {
                        LinkName = "Upcoming Events",
                        LinkUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_UPCOMING)
                    });
                }
                else
                {
                    this.lnkSection.NavigateUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_PAST);
                    this.lnkBack.NavigateUrl = RoutingHelpers.GetEventAllURL("all", Constants.EVENT_PAST);
                    bc.AddToEnd.Add(new BreadCrumbDTO
                    {
                        LinkName = "Past Events",
                        LinkUrl = RoutingHelpers.GetEventAllURL(EventType, Constants.EVENT_PAST)
                    });
                }
                
                bc.AddToEnd.Add(new BreadCrumbDTO
                {
                    LinkName = this.lblTitle.Text,
                    LinkUrl = Request.Url.AbsolutePath
                });

                int showid = repo.GetEventSlideShowId(EventID);

                if (showid > 0)
                    litSlideShowImages.Text = WebsiteHelpers.GenerateSlideShow(showid, "image_show_viewer");
                
            }

            this.EventFeatured.Attributes.Add("class", EventType.ToLower());
            //this.page_content.Attributes.Add("class", EventType.ToLower());
            
        }

        private void Authorized()
        {
            //Verify Edit is Authorized
            var user = CookieHandler.GetAdminUser();
            if (user != null && user.UserID != 0)
            {
                this.EditEvent.Visible = true;
                this.EditEvent.HRef = Page.ResolveUrl("~/administrator/index.aspx?action=e&section=applications&page=event&id=" + EventID);

                this.manageGallery.Visible = true;
                var repo = new ApplicationRepository();
                var eventData = repo.GetSlideShowByTargetAndTargetID("event", EventID);
                if (eventData == null)
                {
                    this.manageGallery.InnerText = "Add Gallery";
                    this.manageGallery.HRef = Page.ResolveUrl("~/manage/AlbumManage.aspx?section=applications&page=slide-show&target=event&targetid=" + EventID + "&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT + "&action=a");
                }
                else
                {
                    this.manageGallery.InnerText = "Edit Gallery";
                    this.manageGallery.HRef = Page.ResolveUrl("~/manage/AlbumManage.aspx?section=applications&page=slide-show&target=event&targetid=" + EventID + "&imagewidth=" + Constants.ALBUM_IMAGE_WIDTH + "&imageheight=" + Constants.ALBUM_IMAGE_HEIGHT + "&action=e&id=" + eventData.ID);
                }
            }
            else
            {
                this.EditEvent.Visible = false;
                this.EditEvent.HRef = "#";
                this.manageGallery.Visible = false;
            }
        }
        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                EventID = (Page.RouteData.Values["id"] != null) ? int.Parse(Page.RouteData.Values["id"] as string) : 0;
                EventType = (Page.RouteData.Values["type"] != null) ? Convert.ToString(Page.RouteData.Values["type"]) : "";
                GetEventData();
                Authorized();

                //Current Menu Id for Header
                var menu = new MenuRepository();
                Header hdr = this.Master.FindControl("Header") as Header;
                hdr.MenuId = menu.GetMenuIDForApp(Constants.APP_Events, EventType);
            }
        }
        
        #endregion

        #region WebMethod

        #endregion
                
    }
}