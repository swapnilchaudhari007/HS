﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using KBHAG.Components;

namespace KBHAG.Website
{
    public partial class EventControl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.lnkhead.HRef = RoutingHelpers.GetEventAllURL();
            this.lnkViewAll.HRef = RoutingHelpers.GetEventAllURL();
        }

        public string GetTitle(string sTitle, string sSub)
        {
            string ret = "";
            if (sTitle.Length < 60)
            {
                int bal = 59 - sTitle.Length;
                if (bal > 15)
                {
                    if (sSub.Length > bal)
                        ret = sTitle + " <i>" + sSub.Substring(0, bal) + "</i>...";
                    else
                        ret = sTitle + " <i>" + sSub + "</i>";
                }
                else
                {
                    ret = sTitle;
                }

            }
            else
            {
                if (sTitle.Length == 60)
                    ret = sTitle;
                else
                    ret = sTitle.Substring(0, 60) + "...";
            }

            return ret;
            //<%# Util.truncateDescription(Util.Parse<string>(Eval("Title")) + " <i>" + Util.Parse<string>(Eval("SubTitle")) + "</i>",60) %><
        }
    }
}