﻿//Document.Get Ready
/*
$(function () {

    var obj;

    //-------------------------Content Editor---------------------------------------------------
    $('#EditContainer_Cancel').click(function (e) {
        $('[id$=layoutPlaceHonder]').show();
        $('[id$=ContentEditorlayoutPlaceHonder]').hide();
    });

    $('.btnContentEditor').on('click', function (e) {
        e.preventDefault();
        $('[id$=layoutPlaceHonder]').hide();
        $('[id$=ContentEditorlayoutPlaceHonder]').show();

        var instance = CKEDITOR.instances['EditContainerContent'];
        if (instance) {
            instance.destroy();
        }

        var param = $(this).prop('rel').split("|");
        CKEDITOR.replace('EditContainerContent',
        {
            width: param[0],
            height: param[1],
            toolbar: param[2]
        });

        control = param[3];
        $('[id$=hidden_ContentEditorControlID]').val(control);
        $('[id$=hidden_ContentEditorPageDataID]').val(param[4]);

        obj = $('#' + control).find('#' + control.split('_', 1) + '_More');
        $(obj).remove();

        CKEDITOR.instances.EditContainerContent.setData($('#' + control).html());
    });    

    $('#EditContainer_Save').click(function (e) {
        e.preventDefault();
        var control = $('[id$=hidden_ContentEditorControlID]').val();
        $('#' + control).html(CKEDITOR.instances.EditContainerContent.getData());
        if (IS_DEFAULT_PAGE === true) {
            $('#' + control).find('p:last').append(obj);
        }
        ReadyToCommunicate(CKEDITOR.instances.EditContainerContent.getData(), $('[id$=hidden_ContentEditorPageDataID]').val(), null);
        $('[id$=layoutPlaceHonder]').show();
        $('[id$=ContentEditorlayoutPlaceHonder]').hide();
    });
    //-------------------------Content Editor---------------------------------------------------
});
*/
//Document.Get Ready
