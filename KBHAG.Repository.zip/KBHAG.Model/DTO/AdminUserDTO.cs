﻿namespace KBHAG.Model
{
    public class AdminUserDTO
    {
        public int      UserID      { get; set; }
        public string   UserName    { get; set; }
        public string   Email       { get; set; }  
    }
}
