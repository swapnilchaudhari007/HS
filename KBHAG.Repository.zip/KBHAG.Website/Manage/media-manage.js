﻿var GlobalRowIndex = 0;
var ImageRow;

$(function () {

    $('[id$=chkIsGallery]').change(function () {
        if ($(this).is(':checked')) {            
            $('[id$=ShowInGalleryHolder]').show();
        } else {            
            $('[id$=ShowInGalleryHolder]').hide();
        }
    });


    imgCoverId = $('[id$=imgAlbumCover]').attr('id');

    Display.CreateCropControl({
        Control: $('[id$=imgAlbumCover]'),
        Style: 'margin-top: 0px; text-decoration: none;',
        ControlClass: 'btn btn-tertiary',
        WrapHtml: 'p',
        ImageWidth: coverWidth,
        ImageHeight: coverHeight,
        IsAlbum:false
    });
    
    $('[id$=btnAddImage]').click(function () {
        var strURL = app.utils.ResolveUrl('~/photoupload.aspx?gridheight=' + GridHeight + '&gridwidth=' + GridWidth + '&imageheight=' + ImageHeight + '&imagewidth=' + ImageWidth + "&mediascript=AddRow&isalbum=y");
        $.fancybox.open({
            href: strURL,
            type: 'ajax',
            padding: 5
        });
    });

    if (MediaAction == "e") {
        $('#btnimageSubmit').hide();
        $('[id$=btnimageCancel]').val('Close');
    }
    else {
        $('#btnimageSubmit').show();
    }

    GlobalRowIndex = $('#tblAlbumImages >tbody tr').size();

    $('#AlbumDataHandler').click(function (e) {
        e.preventDefault();

        // Album validation for include in album flag
        if ($('[id$=chkIsGallery]').is(':checked')) {
            if (app.utils.StringIsBlank($('[id$=txtAlbumName]').val())) {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Album Name Required');
                return;
            }

            if (app.utils.StringIsBlank($('[id$=imgAlbumCover]').attr('src'))) {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Album Thumb is required');
                return;
            }
        }        

        var strActive = "";
        if ($('[id$=txtAlbumActive]').prop('checked'))
            strActive = "Y";
        else
            strActive = "N";

        var DTO = {}, url = app.utils.ResolveUrl("~/AjaxMediaManage.aspx/AlbumData");

        DTO.ID              = Id;
        DTO.Index           = $('[id$=txtAlbumIndex]').val();
        DTO.Title           = $('[id$=txtAlbumName]').val();
        DTO.Desc            = $('[id$=txtAlbumDesc]').val();
        DTO.MetaTitle       = $('[id$=txtAlbumMetaTitle]').val();
        DTO.MetaKeyWord     = $('[id$=txtAlbumMetaKeyword]').val();
        DTO.MetaDesc        = $('[id$=txtAlbumMetaDesc]').val();
        DTO.Active          = strActive;
        DTO.Target          = Target;
        DTO.TargetID        = TargetId;
        DTO.ThumbImage      = $('[id$=imgAlbumCover]').prop('src');
        DTO.ShowInGallery   = ($('[id$=chkIsGallery]').prop('checked')) ? "Y" : "N";

        var sDTO = { album: DTO };

        $.ajax({
            type: 'POST',
            url: url,
            data: JSON.stringify(sDTO),
            contentType: 'application/json; charset=utf-8',
            dataType: "json",
            beforeSend: function () {
                app.utils.ShowResponsiveProcessMessage('MessageHolder');
            },
            success: function (data) {                
                if (data.d == "success") {
                    app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'Album Data Updated.');
                } else {
                    app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Update Failed, Error occur while processing your request. Please try again after sometime...');
                }
            }
        });

    });


    $('#btnimageSubmit').click(function (e) {
        e.preventDefault();

        $('[id$=MessageHolder]').html('');
        
        if ($('[id$=chkIsGallery]').is(':checked')) {
            // Album validation for include in album flag                   
            if (app.utils.StringIsBlank($('[id$=txtAlbumName]').val())) {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Alert', 'Name Required');
                return;
            }

            if (app.utils.StringIsBlank($('[id$=imgAlbumCover]').attr('src'))) {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Alert', 'Cover Image is required');
                return;
            }
            // end album validation
        }       

        if ($('#tblAlbumImages >tbody tr').length === 0) {
            app.utils.ShowResponsiveMessage('MessageHolder', 'Alert', 'At least one image for album has to be uploaded in order to save the album.');
            return;
        }

        var ImageMedia = [];

        $('#tblAlbumImages >tbody tr').each(function (index) {
            var currentMedia = {};
            if (!app.utils.StringIsBlank($(this).find("img").prop("src"))) {
                currentMedia.FileName   = $(this).find("img").prop("src");
                currentMedia.Caption    = $(this).find("[id^=txtImageCaption]").val();
                currentMedia.Index      = (app.utils.StringIsBlank($(this).find("[id^=txtIndex]").val())) ? "0" : $(this).find("[id^=txtIndex]").val();
                currentMedia.Active     = 'Y';
                ImageMedia.push(currentMedia);
            }
        });

        var albumDTO    = {};
        albumDTO.Title = $('[id$=txtAlbumName]').val();

        if (app.utils.StringIsBlank($('[id$=txtAlbumIndex]').val()))
            albumDTO.Index = 0;
        else
            albumDTO.Index = $('[id$=txtAlbumIndex]').val();

        albumDTO.Desc         = $('[id$=txtAlbumDesc]').val();
        albumDTO.MetaTitle    = $('[id$=txtAlbumMetaTitle]').val();
        albumDTO.MetaKeyWord  = $('[id$=txtAlbumMetaKeyword]').val();
        albumDTO.MetaDesc     = $('[id$=txtAlbumMetaDesc]').val();
        albumDTO.ThumbImage   = $('[id$=imgAlbumCover]').prop('src');
        albumDTO.Target       = Target;
        albumDTO.TargetID     = TargetId;
        albumDTO.ShowInGallery = ($('[id$=chkIsGallery]').prop('checked')) ? "Y" : "N";
        albumDTO.Active     = ($('[id$=txtAlbumActive]').prop('checked')) ? "Y" : "N";
        

        var DTO = { 'AlbumDTO': albumDTO, 'ImageMediaDTO': ImageMedia };

        $.ajax({
            type: 'POST',
            url: app.utils.ResolveUrl("~/AjaxMediaManage.aspx/ImageSubmitHandler"),
            data: JSON.stringify(DTO),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            beforeSend: function () {
                app.utils.ShowResponsiveProcessMessage('MessageHolder');
            },
            success: function (response) {
                $('[id$=MessageHolder]').html('');
                var content = response.d.split("|");                
                if (content[0] == "success") {
                    if (RedirectURL != "") {
                        window.location = RedirectURL;
                    }
                    else {
                        window.location = content[1];
                    }
                } else {                    
                    app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Error occur while processing your request.<br/>' +  content[1]);
                }
            }
        });

    });

    //click event to delete a row    
    $('.btnRemoveImageRow').click(function (e) {
        if (MediaAction == "e") {
            cid = $(this).closest("tr").prop('id')
            ImageRow = $(this).closest("tr");
            DeleteImageHandler(cid);
        }
        else {
            $(this).closest('tr').remove();
        }
    });

    //Image Caption Edit
    $('.ImageCaptionEdit').click(function (e) {
        cid = $(this).closest("tr").prop('id');
        par = $(this).parent();
        if (par.find('textarea').prop("readonly") == true) {
            par.find("textarea").prop("readonly", false);
            $(this).html('Save Caption');
        }
        else {
            par.find("textarea").prop("readonly", true);
            UpdateImageCaption(cid, par.find("textarea").val());
            $(this).html('Edit Caption');
        }
    });

    //Image URL Edit
    $(".URLEdit").click(function (e) {
        e.preventDefault();
        cid = $(this).closest("tr").prop('id');
        par = $(this).parent();
        if (par.find('input').prop("readonly") == true) {
            par.find("input").prop("readonly", false);
            $(this).html('Save URL');
        }
        else {
            par.find("input").prop("readonly", true);
            UpdateImageURL(cid, par.find("input").val());
            $(this).html('Edit URL');
        }
    });

    $('.ImageIndexEdit').click(function (e) {
        cid = $(this).closest("tr").prop('id');
        par = $(this).parent();
        if (par.find('input').prop("readonly") == true) {
            par.find("input").prop("readonly", false);
            $(this).html('Save Index');
        }
        else {
            UpdateImageIndex(cid, par.find("input").val());
            par.find("input").prop("readonly", true);
            $(this).html('Edit Index');
        }
    });


    $('.acceptNumber').keypress(function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            $(this).siblings().find('.error').show().fadeOut("slow");            
            return false;
        }
    });

});

function DeleteImageHandler(id) {
    var DTO = { 'id': cid }, url = app.utils.ResolveUrl("~/AjaxMediaManage.aspx/DeleteImage");

    $.ajax({
        type: "POST",
        url: url,
        data: JSON.stringify(DTO),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        beforeSend: function () {
            app.utils.ShowResponsiveProcessMessage('MessageHolder');
        },
        success: function (data) {
            if (data.d == "success") {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'Image Successfully Deleted.');
                ImageRow.remove();
            } else {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Image Delete Failed, Error occur while processing your request. Please try again after sometime...');
            }
        }
    });
}

function UpdateImageCaption(id, caption) {
    var DTO = { 'id': id, 'caption': caption};

    $.ajax({
        type: "POST",
        url: app.utils.ResolveUrl("~/AjaxMediaManage.aspx/UpdateImageCaption"),
        data: JSON.stringify(DTO),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            app.utils.ShowResponsiveProcessMessage('MessageHolder');
        },
        success: function (response) {
            if (response.d == "success") {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'Caption Updated.');
            }
            else {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Caption Update Fail, Error occur while processing your request. Error occur while processing your request.');
            }
        }
    });
}

function UpdateImageURL(id, url) {
    var DTO = { 'id': id, 'url': url };

    $.ajax({
        type: "POST",
        url: app.utils.ResolveUrl("~/AjaxMediaManage.aspx/UpdateImageURL"),
        data: JSON.stringify(DTO),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            app.utils.ShowResponsiveProcessMessage('MessageHolder');
        },
        success: function (response) {
            if (response.d == "success") {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'URL Updated.');
            }
            else {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'URL Update Fail, Error occur while processing your request. Error occur while processing your request.');
            }
        }
    });
}

function UpdateImageIndex(id, iindex) {
    var DTO = { 'id': id, 'index': iindex };    
    $.ajax({
        type: "POST",
        url: app.utils.ResolveUrl("~/AjaxMediaManage.aspx/UpdateImageIndex"),
        data: JSON.stringify(DTO),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            app.utils.ShowResponsiveProcessMessage('MessageHolder');
        },
        success: function (response) {
            if (response.d == "success") {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'Index Updated.');
            } else {
                app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Update Index Failed, Error occur while processing your request.');
            }
        }
    });
}

function AddRow(mediaid, src, iindex, caption) {
    if (MediaAction == "e") {
        var currentMedia = {};
        currentMedia.FileName       = src;
        currentMedia.Caption        = caption;
        currentMedia.Index          = iindex;
        currentMedia.SlideShowID    = Id;
        currentMedia.Active         = "Y";

        var DTO = { mDTO: currentMedia };

        $.ajax({
            type: "POST",
            url: app.utils.ResolveUrl("~/AjaxMediaManage.aspx/AddImage"),
            data: JSON.stringify(DTO),
            contentType: 'application/json; charset=utf-8',
            dataType: "json",
            beforeSend: function () {
                app.utils.ShowResponsiveProcessMessage('MessageHolder');
            },
            success: function (response) {
                var data = response.d;                
                mess = data.split("|");
                if (mess[0] == "success") {
                    app.utils.ShowResponsiveMessage('MessageHolder', 'Success', 'Image Added successfully to album.');
                    src = "/media/images/content/thumb_" + mess[1];
                    addRowToTable(mediaid, src, iindex, caption, true)
                } else {
                    app.utils.ShowResponsiveMessage('MessageHolder', 'Error', 'Add Row Failed, Error occur while processing your request.' + mess[1]);
                }
            }
        });
        
    } else {
        addRowToTable(mediaid, src, iindex, caption, false)
    }


}

function addRowToTable(mediaid, src, iindex, caption) {
    var newRow = '';
    GlobalRowIndex++;
    newRow += '<tr id="trImage_' + GlobalRowIndex + '_' + mediaid + '">';

    newRow += '<td><img src="' + src + '" alt="' + caption + '" width="120px" height="90px" id="imgAlbum_' + GlobalRowIndex + '"></img></td>';
    newRow += '<td><textarea class="input-xxlarge" id="txtImageCaption_' + GlobalRowIndex + '" rows="3" cols="100"';
    if (MediaAction == 'e')
        newRow += 'readonly="readonly" ';
    newRow += '>' + caption + '</textarea><br/><br/>';

    if (MediaAction == 'e') {
        newRow += '<div class="btn btn-danger ImageCaptionEdit">Edit Caption</div>';
    }
    newRow += '</td>';

    newRow += '<td style="vertical-align:bottom"><input type="text" class="input-mini acceptNumber" id="txtIndex_' + GlobalRowIndex + '" value="' + iindex + '" ';
    if (MediaAction == 'e')
        newRow += 'readonly="readonly" ';
    newRow += ' /><div><span class="error display-none">Digits Only</span></div> <br/><br/>';
    if (MediaAction == 'e') {
        newRow += '<div class="btn btn-secondary ImageIndexEdit">Edit Index</div>';
    }
    newRow += '</td>';

    newRow += '<td style="vertical-align:bottom"><div class="btn btn-danger btnRemoveImageRow" id="btnRowDelete_' + GlobalRowIndex + '">Delete</div></td>';

    newRow += '</tr>';

    $('#tblAlbumImages').append(newRow);
    app.utils.hideErrorDiv('MessageHolder');
}
