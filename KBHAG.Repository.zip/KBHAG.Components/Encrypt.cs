﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Web;

namespace KBHAG.Components
{
    public class Encrypt
    {
        public static string EncryptID(int unencryptedID)
        {
            try
            {
                string encryptedID = null;
                byte[] bKey = new byte[8];
                byte[] IV = { 18, 52, 86, 120, 144, 171, 205, 239 };
                bKey = System.Text.Encoding.UTF8.GetBytes("!#$a56?3");
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray = System.Text.Encoding.UTF8.GetBytes(unencryptedID.ToString());
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(bKey, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                encryptedID = Convert.ToBase64String(ms.ToArray());
                return (encryptedID);
            }
            catch
            {
                throw new ApplicationException("An invalid ID was received.");
            }
        }

        public static int DecryptID(string encryptedID)
        {
            try
            {
                byte[] key = System.Text.Encoding.UTF8.GetBytes("!#$a56?3");
                byte[] IV = { 18, 52, 86, 120, 144, 171, 205, 239 };
                byte[] inputByteArray = new byte[encryptedID.Length];

                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(encryptedID);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return int.Parse(encoding.GetString(ms.ToArray()));
            }
            catch
            {
                throw new ApplicationException("An invalid ID was received.");
            }
        }

        public static string Encryptstr(string unencryptedstr)
        {
            try
            {
                string encryptedStr = null;
                byte[] bKey = new byte[8];
                byte[] IV = { 13, 26, 39, 52, 65, 78, 91, 104 };
                bKey = System.Text.Encoding.UTF8.GetBytes("~l?o*k!m");
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray = System.Text.Encoding.UTF8.GetBytes(unencryptedstr.ToString());
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(bKey, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                encryptedStr = Convert.ToBase64String(ms.ToArray());
                return (encryptedStr);
            }
            catch
            {
                throw new ApplicationException("An invalid String was received.");
            }
        }

        public static string DecryptStr(string encryptedStr)
        {
            try
            {
                byte[] key = System.Text.Encoding.UTF8.GetBytes("~l?o*k!m");
                byte[] IV = { 13, 26, 39, 52, 65, 78, 91, 104 };
                byte[] inputByteArray = new byte[encryptedStr.Length];
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(encryptedStr);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch
            {
                throw new ApplicationException("An invalid String was received.");
            }
        }

        public static string TamperProofStringEncode(string value, string key)
        {
            System.Security.Cryptography.MACTripleDES mac3des = new System.Security.Cryptography.MACTripleDES();
            System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            mac3des.Key = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(key));
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(value)) + '-' + Convert.ToBase64String(mac3des.ComputeHash(System.Text.Encoding.UTF8.GetBytes(value)));
        }

        public static string TamperProofKey = Constants.TAMPERPROOFKEY;

        public static string QueryStringEncode(string value)
        {
            return HttpUtility.UrlEncode(TamperProofStringEncode(value, TamperProofKey));
        }

        public static string TamperProofStringDecode(string value, string key)
        {
            string dataValue = "";
            string calcHash = "";
            string storedHash = "";

            System.Security.Cryptography.MACTripleDES mac3des = new System.Security.Cryptography.MACTripleDES();
            System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            mac3des.Key = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(key));

            try
            {

                dataValue = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value.Split(new char[] { Convert.ToChar("-") })[0]));
                storedHash = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value.Split(new char[] { Convert.ToChar("-") })[1]));
                calcHash = System.Text.Encoding.UTF8.GetString(mac3des.ComputeHash(System.Text.Encoding.UTF8.GetBytes(dataValue)));

                if (storedHash != calcHash)
                {
                    throw new ArgumentException("Hash value does not match");
                }
            }
            catch (Exception)
            {
                throw new ArgumentException("Invalid TamperProofString");
            }
            return dataValue;
        }

        public static string QueryStringDecode(string value)
        {
            return TamperProofStringDecode(value, TamperProofKey);
        }

    }
}
