﻿using System.Data;
using System.Data.Entity;
using KBHAG.Model;

namespace KBHAG.Data
{
    public class KBHAGContext:BaseContext<KBHAGContext>,IKBHAGContext
    {
        public IDbSet<FormPage>                 FormPages                   { get; set; }
        public IDbSet<AdminMenu>                AdminMenus                  { get; set; }
        public IDbSet<ViewAdminMenu>            ViewAdminMenus              { get; set; }
        public IDbSet<FormStructure>            FormStructures              { get; set; }
        public IDbSet<User>                     Users                       { get; set; }

        public IDbSet<Application>              Applications                { get; set; }
        public IDbSet<Layout>                   Layouts                     { get; set; }
        public IDbSet<CMSMenu>                  Menus                       { get; set; }
        public IDbSet<ViewMenu>                 ViewMenus                   { get; set; }
        public IDbSet<PageStructure>            PageStructures              { get; set; }
        public IDbSet<CMSPage>                  CMSPages                    { get; set; }
        public IDbSet<ViewPage>                 ViewPages                   { get; set; }
        public IDbSet<PageData>                 PageDatas                   { get; set; }
        public IDbSet<ViewPageData>             ViewPageDatas               { get; set; }
        public IDbSet<PagePublish>              PagePublishs                { get; set; }
        public IDbSet<ViewPagePublish>          ViewPagePublishs            { get; set; }
        public IDbSet<MapLayoutStructure>       MapLayoutStructures         { get; set; }
        public IDbSet<ViewMapLayoutStructure>   ViewMapLayoutStructures     { get; set; }

        public IDbSet<HomePage>                 HomePages                   { get; set; }
        public IDbSet<EventType>                EventTypes                  { get; set; }
        public IDbSet<Event>                    Events                      { get; set; }
        public IDbSet<Featured>                 Featureds                   { get; set; }
        public IDbSet<ViewFeatured>             ViewFeatureds               { get; set; }
        public IDbSet<ViewEvent>                ViewEvents                  { get; set; }
        public IDbSet<SlideShow>                SlideShows                  { get; set; }
        public IDbSet<SlideShowMedia>           SlideShowMedias             { get; set; }
        public IDbSet<Press>                    Presss                      { get; set; }
        public IDbSet<Video>                    Videos                      { get; set; }

        public IDbSet<Inquiry>                  Inquirys                    { get; set; }
        public IDbSet<Testimonial>              Testimonials                { get; set; }
        public IDbSet<News>                     Newss                        { get; set; }
    }
}
