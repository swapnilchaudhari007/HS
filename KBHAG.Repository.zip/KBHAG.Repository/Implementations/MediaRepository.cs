﻿using KBHAG.Data;
using KBHAG.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace KBHAG.Repository
{
    public class MediaRepository:IMediaRepository
    {
        public SlideShow GetSlideShowByID(int id)
        {
            using (var uow = new KBHAGUnitOfWork())
            {
                var repo = new GenericRepository<SlideShow>();
                repo.UnitOfWork = uow;
                return repo.GetById(id);
            }
        }
    }
}
