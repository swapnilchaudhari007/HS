﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace KBHAG.Website.Ajax
{
    public partial class pagePublish : System.Web.UI.Page
    {

        public int PageID = 0;
        public int MenuID = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["pageid"] != null)
                {
                    PageID = int.Parse(Request.QueryString["pageid"].ToString());
                }

                if (Request.QueryString["menuid"] != null)
                {
                    MenuID = int.Parse(Request.QueryString["menuid"].ToString());
                }
            }
        }
    }
}